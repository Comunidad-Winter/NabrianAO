BP-Darkness skin for XenForo 1.5.0 Designed by Bluepearl Skins
##############################################################

For more detailed instructions with screenshots about how to install a XenForo skin, 
change the logo and banner background image read this post on our site:
http://www.bluepearl-skins.com/forums/topic/8222-installing-a-xenforo-skin-and-changing-the-logo/

Installation instructions:

1: Upload the image directory "Darkness" to your server  "*your forums*/xenforo/styles/Darkness/
2: Goto Administration page click the 'appearance tab' and then from the left side menu click 'Import a style'
3: Upload style-darkness.xml from the 'XML Files' folder and selecting (no parent style)


If you find any bugs or need any help please visit www.bluepearl-skins.com.

NOTE: To Download the latest version of BP-brown visit: 
http://www.bluepearl-skins.com/forums/forum/93-free-xenforo-skins-styles/

For latest update news add us to Twitter & Facebook:
http://twitter.com/BluepearlSkins / http://www.facebook.com/pages/Bluepearl-Skins/124332257585952

*** This skin may not be redistributed or released on any other site. ***
*** This skin license is valid on one forum only ***
*** Please purchase branding free from our site to remove the branding 
http://www.bluepearl-skins.com/forums/store/product/2-global-branding-free/ ***

###########
Style History.
-----------
25th August 2015
-- Updated for XenForo 1.5.0
-----------
12th April 2015
-- Updated for XenForo 1.4.6
-----------
29th February 2015
-- Updated for XenForo 1.4.5
-----------
26th September 2014
-- Updated for XenForo 1.4.1
-----------
18th September 2014
-- Updated for XenForo 1.4.0
-----------
19th June 2014
-- Updated for XenForo 1.3.3
-----------
18th May 2014
-- Updated for XenForo 1.3.2
-----------
20th April 2014
-- Updated for XenForo 1.3.1
-----------
22nd March 2014
-- Updated for XenForo 1.3.0
-----------
17th February 2014
-- Updated for XenForo 1.2.5
-----------
19th December 2013
-- Updated for XenForo 1.2.4
-----------
9th November 2013
-- Updated for XenForo 1.2.3
-----------
26th September 2013
-- Updated for XenForo 1.2.2
-----------
26th August 2013
-- Updated for XenForo 1.2.1
-----------
1st August 2013
-- Updated for XenForo 1.2.0
-----------
23rd May 2013
-- Updated for XenForo 1.1.5
-----------
15th April  2013
-- Updated for XenForo 1.1.4
-----------
24th July 2012
-- Updated for XenForo 1.1.3
-----------
23rd Febuary 2012
-- Updated for XenForo 1.1.2
-----------
14th July 2011
-- Updated for XenForo 1.0.4
-----------
6th July 2011
-- Updated for XenForo 1.0.3
-----------
29th June 2011
-- Released for XenForo 1.0.2