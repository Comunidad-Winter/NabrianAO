<?php
class DBTech_Shout_Application
{
	/**
	 * Standard approach to caching other application objects for the lifetime of the application.
	 *
	 * @var array
	 */
	protected static $_applicationCache = array();


	/**
	 * Gets the specified application object from the cache. If it does not exist,
	 * it will be instantiated.
	 *
	 * @param string $class Name of the class to load
	 *
	 * @return XenForo_Model
	 */
	public static function getApplicationFromCache($class)
	{
		if (!isset(self::$_applicationCache[$class]))
		{
			self::$_applicationCache[$class] = self::create($class);
		}

		return self::$_applicationCache[$class];
	}

	/**
	 * Gets the specified model object from the cache. If it does not exist,
	 * it will be instantiated.
	 *
	 * @param string $class Name of the class to load
	 *
	 * @return XenForo_Model
	 */
	public static function getModelFromCache($class)
	{
		return self::getApplicationFromCache('DBTech_Shout_Model_' . $class);
	}

	/**
	* Factory method to get the named application. The class must exist or be autoloadable
	* or an exception will be thrown.
	*
	* @param string     $class Class to load
	*
	* @throws Exception
	*
	* @return mixed
	*/
	public static function create($class)
	{
		$app = DBTech_Shout_Core::getInstance();
		switch ($app->getSystem())
		{
			case 'XenForo':
				$createClass = XenForo_Application::resolveDynamicClass($class, '');
				break;

			case 'vBulletin':
				// Simple
				$createClass = $class;
				break;
		}
		if (!$createClass)
		{
			throw new Exception("Invalid application class '$class' specified");
		}

		return new $createClass();
	}
}
?>