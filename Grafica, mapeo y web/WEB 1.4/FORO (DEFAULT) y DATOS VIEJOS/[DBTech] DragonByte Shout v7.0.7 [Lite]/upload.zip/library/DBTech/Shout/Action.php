<?php
abstract class DBTech_Shout_Action
{
	protected $app;
	protected $cache;

	public function __construct()
	{
		// Get the instance
		$this->app = DBTech_Shout_Core::getInstance();
		$this->cache = DBTech_Shout_Cache::getInstance();
	}

	public function actionIndex() {}

	protected function assertCanView()
	{
		if (!$this->app->option('dbtech_vbshout_active'))
		{
			// No permission to buy
			throw new DBTech_Shout_Application_ResponseErrorException($this->app->option('dbtech_vbshout_closedreason'));
		}

		/*
		$userInfo = $this->app->getUserInfo();

		if (
			!$this->app->usergroupPermission('dbtech_creditspermissions', 'canview')
			AND !$this->app->usergroupPermission('dbtech_creditspermissions', 'ismanager')
		)
		{
			// No permission to buy
			throw new DBTech_Shout_Application_ResponseErrorException($this->app->phrase('dbtech_credits_no_permission'));
		}
		*/
	}

	protected function getModelFromCache($class)
	{
		return DBTech_Shout_Application::getModelFromCache($class);
	}

	protected function getApplicationFromCache($class)
	{
		return DBTech_Shout_Application::getApplicationFromCache($class);
	}

	protected function _getDb()
	{
		return DBTech_Shout_Core::getInstance()->_getDb();
	}

	protected function _getTemplate()
	{
		return DBTech_Shout_Template::getInstance();
	}
}
?>