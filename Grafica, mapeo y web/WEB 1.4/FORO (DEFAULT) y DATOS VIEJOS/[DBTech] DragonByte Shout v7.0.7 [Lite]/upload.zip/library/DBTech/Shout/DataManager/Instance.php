<?php
/**
* DataManager for Instances.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Instance extends DBTech_Shout_DataManager
{
	const TABLE_NAME = 'dbtech_vbshout_instance';
	const TABLE_ID = 'instanceid';

	protected $_fields = [
		self::TABLE_ID		=> [
			'type'				=> 'uint',
			'autoIncrement' 	=> true
		],
		'varname' 			=> [
			'type' 				=> 'string',
			'required' 			=> true,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Instance', '_verifyVarname'],
		],
		'name' => [
			'type' 				=> 'string',
			'required' 			=> true,
		],
		'description' => [
			'type' 				=> 'string',
			'required' 			=> false,
		],
		'active' 			=> [
			'type' 				=> 'boolean',
			'required' 			=> false,
		],
		'displayorder' 		=> [
			'type' 				=> 'uint',
			'required' 			=> false,
		],
		'autodisplay' 		=> [
			'type' 				=> 'uint',
			'required' 			=> true,
		],
		'permissions' 		=> [
			'type' 				=> 'serialized',
			'required' 			=> false,
		],
		'bbcodepermissions' => [
			'type' 				=> 'serialized',
			'required' 			=> false,
		],
		'options' 			=> [
			'type' 				=> 'serialized',
			'required' 			=> true,
		],
		'forumids' 			=> [
			'type' 				=> 'serialized',
			'required' 			=> false,
		],
		'sticky' 			=> [
			'type' 				=> 'string',
			'required' 			=> false,
		],
		'sticky_raw' 		=> [
			'type' 				=> 'string',
			'required' 			=> false,
		],
		'notices' 			=> [
			'type' 				=> 'serialized',
			'required' 			=> false,
		],
		'shoutsound' 		=> [
			'type' 				=> 'string',
			'required' 			=> false,
		],
		'invitesound' 		=> [
			'type' 				=> 'string',
			'required' 			=> false,
		],
		'pmsound' 			=> [
			'type' 				=> 'string',
			'required' 			=> false,
		],
	];

	/**
	* Gets the actual existing data out of data that was passed in. See parent for explanation.
	*
	* @param mixed
	*
	* @return array|false
	*/
	protected function _getExistingData($data)
	{
		return $this->_getDb()->fetchRow('SELECT * FROM $' . self::TABLE_NAME . ' WHERE ' . self::TABLE_ID . ' = ' . $this->_getDb()->quote($data));
	}

	/**
	* Gets SQL condition to update the existing record.
	*
	* @return string
	*/
	protected function _getUpdateCondition()
	{
		return 'instanceid = ' . $this->_getDb()->quote($this->getExisting('instanceid'));
	}

	/**
	 * Post-save handling.
	 */
	protected function _postSave()
	{
		$this->cache->build('instance');
	}

	/**
	 * Post-delete handling.
	 */
	protected function _postDelete()
	{
		// remove shouts belonging to this instance
		$this->_getDb()->delete('dbtech_vbshout_shout', '`instanceid` = ' . intval($this->getExisting('instanceid')));

		// Rebuild the cache
		$this->cache->build('instance');

		// Rebuild shout counters
		DBTech_Shout_Shoutbox::getInstance()->buildShoutsCounter();
	}
}