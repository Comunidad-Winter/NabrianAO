<?php
/**
* DataManager for Shouts.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Shout extends DBTech_Shout_DataManager
{
	const TABLE_NAME = 'dbtech_vbshout_shout';
	const TABLE_ID = 'shoutid';

	protected $_fields = [
		self::TABLE_ID	=> [
			'type'				=> 'uint',
			'autoIncrement' 	=> true
		],
		'userid' 		=> [
			'type' 				=> 'int',
			'required' 			=> true,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Shout', '_verifyUserId'],
		],
		'dateline' 		=> [
			'type' 				=> 'uint',
			'required' 			=> false,
		],
		'message' 		=> [
			'type' 				=> 'string',
			'required' 			=> true,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Shout', '_verifyMessage'],
		],
		'message_raw' 	=> [
			'type' 				=> 'string',
			'required' 			=> true,
		],
		'type' 			=> [
			'type' 				=> 'uint',
			'required' 			=> false,
		],
		'id' 			=> [
			'type' 				=> 'int',
			'required' 			=> false,
		],
		'notification' 	=> [
			'type' 				=> 'string',
			'required' 			=> false,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Shout', '_verifyNotification'],
		],
		'forumid' 		=> [
			'type' 				=> 'uint',
			'required' 			=> false,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Shout', '_verifyForum'],
		],
		'instanceid' 	=> [
			'type' 				=> 'uint',
			'required' 			=> false,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Instance', '_verifyInstance'],
		],
		'chatroomid' 	=> [
			'type' 				=> 'uint',
			'required' 			=> false,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Chatroom', '_verifyChatroom'],
		],
	];

	/**
	* Gets the actual existing data out of data that was passed in. See parent for explanation.
	*
	* @param mixed
	*
	* @return array|false
	*/
	protected function _getExistingData($data)
	{
		return $this->_getDb()->fetchRow('SELECT * FROM $' . self::TABLE_NAME . ' WHERE ' . self::TABLE_ID . ' = ' . $this->_getDb()->quote($data));
	}

	/**
	* Gets SQL condition to update the existing record.
	*
	* @return string
	*/
	protected function _getUpdateCondition()
	{
		return 'shoutid = ' . $this->_getDb()->quote($this->getExisting('shoutid'));
	}

	/**
	 * Pre-save handling.
	 */
	protected function _preSave()
	{
		// Init this
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();
		$instanceCache = $this->cache->get('instance');

		$instanceid = $this->get('instanceid');
		if (!$instance = $this->getInfo('instance'))
		{
			$instance = $instanceCache[$instanceid];
			$this->setInfo('instance', $instance);
		}

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				if ($this->isChanged('message'))
				{
					/** @var $taggingModel XenForo_Model_UserTagging */
					$taggingModel = new XenForo_Model_UserTagging();

					$this->_taggedUsers = $taggingModel->getTaggedUsersInMessage(
						$this->get('message'), $newMessage, 'bb'
					);
					$this->set('message', $newMessage);
				}
				break;
		}

		if ($this->isInsert())
		{
			if ($this->get('dateline') === null)
			{
				$this->set('dateline', $this->app->getTime());
			}

			if ($this->get('type') === null)
			{
				$this->set('type', $shoutbox->shouttypes['shout']);
			}

			if ($this->get('userid') === null)
			{
				$this->set('userid', $this->app->getUserInfo('userid'));
			}
		}

		$permissions = NULL;
		if ($instance)
		{
			// Grab userinfo
			$userinfo = (
				($this->get('userid') == $this->app->getUserInfo('userid')) ?
				$this->app->getUserInfo() :
				$this->app->getUserById($this->get('userid'))
			);

			// Initialise Permissions
			$permissions = array(
				'permissions_parsed' 		=> $shoutbox->loadInstancePermissions($instance, $userinfo),
				'bbcodepermissions_parsed' 	=> $shoutbox->loadInstanceBbcodePermissions($instance, $userinfo)
			);

			// Shorthand
			$message = $this->get('message');

			if (!$this->getInfo('is_automated'))
			{
				// Do character count checking
				if ($instance['options']['maxchars'] != 0 AND ($postlength = strlen($message)) > $instance['options']['maxchars'] AND !$this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
				{
					$this->error($this->app->phrase('dbtech_vbshout_charlimit', array('param1' => $postlength, 'param2' => $instance['options']['maxchars'])));
					return false;
				}

				if (!(boolean)call_user_func_array(array('DBTech_Shout_DataManager_Helper_Shout', '_verifyImageCount'), array(&$message, $instance, $this)))
				{
					return false;
				}

				if ($instance['options']['maxsize'])
				{
					// Replace the SIZE BBCode if needed
					$message = preg_replace_callback(array(
						'#\[size=(\d+)\]#i',
						'#\[size=\"(\d+)\"\]#i',
						'#\[size=\'(\d+)\'\]#i'
					), function($match) use ($instance)
					{
						return '[size=' . (intval($match[1]) > $instance['options']['maxsize'] ? $instance['options']['maxsize'] : $match[1]) . ']';
					}, $message);

					// Set raw message
					$this->set('message', $message);
				}
			}

			if ($this->isUpdate())
			{
				// Update
				if ($this->get('userid', true) == $this->app->getUserInfo('userid') AND (!$permissions['permissions_parsed']['caneditown']))
				{
					// We can't edit our own shouts
					$this->error($this->app->phrase('dbtech_vbshout_may_not_edit_own'));
					return false;
				}

				if ($this->get('userid', true) != $this->app->getUserInfo('userid') AND (!$permissions['permissions_parsed']['caneditothers']))
				{
					// We can't edit our own shouts
					$this->error($this->app->phrase('dbtech_vbshout_may_not_edit_others'));
					return false;
				}
			}
			else if (!$permissions['permissions_parsed']['canshout'] AND !$this->getInfo('is_automated'))
			{
				// We aren't allowed to post shouts
				$this->error($this->app->phrase('dbtech_vbshout_may_not_shout'));
				return false;
			}
		}
		else
		{
			if ($this->isUpdate())
			{
				// Update
				if ($this->get('userid', true) == $this->app->getUserInfo('userid'))
				{
					// We can't edit our own shouts
					$this->error($this->app->phrase('dbtech_vbshout_may_not_edit_own'));
					return false;
				}

				if ($this->get('userid', true) != $this->app->getUserInfo('userid'))
				{
					// We can't edit our own shouts
					$this->error($this->app->phrase('dbtech_vbshout_may_not_edit_others'));
					return false;
				}
			}
			else if (!$this->getInfo('is_automated'))
			{
				// We aren't allowed to post shouts
				$this->error($this->app->phrase('dbtech_vbshout_may_not_shout'));
				return false;
			}
		}

		// Set raw message
		$this->set('message_raw', $message);

		// Parse message for /pm command and other on-the-fly messages that's not supposed to return true
		if (!(boolean)call_user_func_array(array('DBTech_Shout_DataManager_Helper_Shout', '_parseActionCodes'), array($this)))
		{
			// We had sum error
			return false;
		}

		// Re-grab this (custom command support pretty much)
		$message = $this->get('message');

		// Parse BBCode
		$shoutbox->parseBbCode($message, (($instance AND !$this->getInfo('is_automated')) ? $instance : NULL), $permissions);

		// Set raw message
		$this->set('message', htmlspecialchars($message));

		return true;
	}

	public function save()
	{
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();

		$this->preSave();

		if ($this->_haveErrorsPreventSave())
		{
			// Set the errors
			$shoutbox->fetched['error'] = implode('<br />', $this->_errors);

			if ($this->_errorHandler == self::ERROR_ARRAY)
			{
				return $this->_errors;
			}
			return false;
		}

		// Go through normal saving
		parent::save();
	}

	/**
	 * Post-save handling.
	 */
	protected function _postSave()
	{
		// Init this
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();
		$instanceCache = $this->cache->get('instance');
		$chatroomCache = $this->cache->get('chatroom');

		// Shorthand
		$instance = $this->getInfo('instance');

		

		if ($this->isUpdate())
		{
			// Log this command
			$shoutbox->logCommand('shoutedit', serialize(array('old' => $this->get('message', true), 'new' => $this->get('message'))));
		}
		else
		{
			if ($this->get('id') > 0)
			{
				// We sent this to someone
				$this->_getDb()->query('
					UPDATE $user
					SET dbtech_vbshout_pm = ?
					WHERE =user:userid= = ?
				', array($this->app->getTime(), $this->get('id')), 'query_write');
			}

			if ($this->get('userid') > 0)
			{
				// increment shouts count
				$this->_getDb()->query('
					UPDATE $user
					SET
						dbtech_vbshout_shouts = dbtech_vbshout_shouts + 1,
						dbtech_vbshout_shouts_lifetime = dbtech_vbshout_shouts_lifetime + 1
					WHERE =user:userid= = ?
				', array($this->get('userid')), 'query_write');

				/*DBTECH_PRO_START*/
				$numShouts = $this->_getDb()->fetchOne('
					SELECT dbtech_vbshout_shouts_lifetime
					FROM $user
					WHERE =user:userid= = ' . intval($this->get('userid'))
				);
				foreach ($instanceCache as $instanceid => $instance)
				{
					if (!$instance['options']['shoutping_interval'])
					{
						// Not having notices here
						continue;
					}

					if ($numShouts % $instance['options']['shoutping_interval'] != 0)
					{
						// We only want matching intervals
						continue;
					}

					$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
						$shoutDm->setInfo('instance', $instance);
						$shoutDm->bulkSet(array(
							'message' => $this->app->phrase('dbtech_vbshout_has_reached_x_shouts', array(
								'param1' => $numShouts
							)),
							'instanceid' => $instanceid,
							'type' => $shoutbox->shouttypes['notif'],
							'userid' => $this->get('userid')
						));
					$shoutDm->save();
					unset($shoutDm);
				}
				/*DBTECH_PRO_START*/
			}
		}

		if ($instance)
		{
			if ($this->get('chatroomid'))
			{
				// Update the AOP
				$shoutbox->setAop('chatroom_' . $this->get('chatroomid') . '_', $chatroomCache[$this->get('chatroomid')]['instanceid']);
			}
			else
			{
				if ($this->get('id'))
				{
					// Update the AOP
					$shoutbox->setAop('pm_' . $this->get('id') . '_', $this->get('instanceid'));
				}

				// Update the AOP
				$shoutbox->setAop('shouts', $this->get('instanceid'));
			}

			switch ($this->get('type'))
			{
				case $shoutbox->shouttypes['notif']:
					// Update the AOP
					$shoutbox->setAop('shoutnotifs', $this->get('instanceid'), false, true);
					break;

				case $shoutbox->shouttypes['system']:
					// Update the AOP
					$shoutbox->setAop('systemmsgs', $this->get('instanceid'), false, true);
					break;
			}
		}
	}

	/**
	 * Pre-delete handling.
	 */
	protected function _preDelete()
	{
		// Init this
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();
		$instanceCache = $this->cache->get('instance');

		$instanceid = $this->get('instanceid');
		if (!$instance = $this->getInfo('instance'))
		{
			$instance = $instanceCache[$instanceid];
			$this->setInfo('instance', $instance);
		}

		if ($this->get('userid', true) == $this->app->getUserInfo('userid') AND (!$instance['permissions_parsed']['caneditown'] AND $this->get('instanceid') > 0))
		{
			// We can't edit our own shouts
			$this->error($this->app->phrase('dbtech_vbshout_may_not_edit_own'));
			return false;
		}

		if ($this->get('userid', true) != $this->app->getUserInfo('userid') AND (!$instance['permissions_parsed']['caneditothers'] AND $this->get('instanceid') > 0))
		{
			// We don't have permission to edit others' shouts
			$this->error($this->app->phrase('dbtech_vbshout_may_not_edit_others'));
			return false;
		}

		return true;
	}

	public function delete()
	{
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();

		$this->preDelete();

		if ($this->_haveErrorsPreventSave())
		{
			// Set the errors
			$shoutbox->fetched['error'] = implode('<br />', $this->_errors);

			if ($this->_errorHandler == self::ERROR_ARRAY)
			{
				return $this->_errors;
			}
			return false;
		}

		// Go through normal saving
		parent::delete();
	}

	/**
	 * Post-delete handling.
	 */
	protected function _postDelete()
	{
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();

		// Decrement shout counters
		$this->_getDb()->query('
			UPDATE $user
			SET dbtech_vbshout_shouts = dbtech_vbshout_shouts - 1
			WHERE =user:userid= = ?
		', array($this->get('userid', true)), 'query_write');

		// Log this command
		$shoutbox->logCommand('shoutdelete', $this->get('message', true));

		// Update the AOP
		$shoutbox->setAop('shouts', $this->get('instanceid', true), false, true);

		if ($this->get('type') == $shoutbox->shouttypes['notif'])
		{
			// Update the AOP
			$shoutbox->setAop('shoutnotifs', $this->get('instanceid', true), false, true);
		}
		else if ($this->get('type') == $shoutbox->shouttypes['system'])
		{
			// Update the AOP
			$shoutbox->setAop('systemmsgs', $this->get('instanceid', true), false, true);
		}

		// Rebuild shout counters
		$shoutbox->buildShoutsCounter();
	}
}