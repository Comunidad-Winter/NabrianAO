<?php
class DBTech_Shout_XenForo_Install_20160406 extends DBTech_Shout_XenForo_Install
{
	protected function _install()
	{
		$db = XenForo_Application::getDb();

		try
		{
			$db->query("
				ALTER TABLE `xf_dbtech_vbshout_chatroom`
					ADD `description` MEDIUMBLOB
					AFTER `title`
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_dbtech_vbshout_chatroom`
					ADD `autojoin` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1'
					AFTER `active`
			");
		}
		catch (Zend_Db_Exception $e) {}
	}
}