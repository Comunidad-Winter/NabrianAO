<?php
abstract class DBTech_Shout_Application_Cache
{
	protected static $_instance;

	// A few constants
	const PREFIX 					= 'dbtech_vbshout_';
	const TTL 						= 3600;

	/**
	* Array of cache fields
	*
	* @public	array
	*/
	public $cache 			= [];
	private $cacheObj 		= NULL;

	/**
	* Array of DB table joins / other commands
	*
	* @protected	array
	*/
	protected $_tables		= [];

	/**
	* Array of defaults
	*
	* @protected	array
	*/
	protected $_defaults		= [];

	/**
	* Array of callbacks
	*
	* @protected	array
	*/
	protected $_loadCallbacks		= [];

	/**
	* Array of cached items
	*
	* @public	array
	*/
	public $unserialize		= [];

	/**
	* Array of items to NOT fetch
	*
	* @protected	array
	*/
	protected $_idColumns	= [];

	protected $app;


	/**
	* Initialises the DataRegistry model in xenForo
	*/
	public function __construct()
	{
		// Get the instance
		$this->app = DBTech_Shout_Application_Core::getInstance();

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$this->cacheObj = XenForo_Model::create('XenForo_Model_DataRegistry');
				break;
		}
	}

	/**
	* Sets a cache item
	*
	* @param	string	Database table we are working with
	* @param	mixed	The data to cache
	* @param	string	(Optional) Key if writing to vB Optimise
	* @param	integer	(Optional) Time-To-Live if writing to vB Optimise
	*/
	public function set($type, $data, $key = '', $ttl = -1)
	{
		switch ($this->app->getSystem())
		{
			case 'vBulletin':
				if (!isset($this->_tables[$type]))
				{
					// Write the cache
					$this->write($data, $type, ($key ? $key : $type), $ttl);
				}
				break;
		}

		// Ensure we're loading the defaults
		$data = array_map(function($data) use ($type) {
			call_user_func_array([$this, 'loadDefaults'], [$type, &$data]);
			return $data;
		}, $data);

		if (isset($this->_loadCallbacks[$type]) AND is_callable([$this, $this->_loadCallbacks[$type]]))
		{
			call_user_func_array([$this, $this->_loadCallbacks[$type]], [&$data]);
		}

		// Set the data
		$this->cache[$type] = $data;
	}

	/**
	* Gets a cache item
	*
	* @param	string	Database table we are working with
	* @param	string	(Optional) Key if reading from vB Optimise
	*/
	public function get($type, $key = '')
	{
		switch ($this->app->getSystem())
		{
			case 'XenForo':
				if (!isset($this->cache[$type]) OR !is_array($this->cache[$type]))
				{
					// We need to fetch from datastore
					$this->fetchFromDatastore();
				}

				// Cache is fine
				return $this->cache[$type];
				break;

			case 'vBulletin':
				if (!isset($this->_tables[$type]))
				{
					// This is a vBO cache read
					return $this->read($type, ($key ? $key : $type));
				}
				else if (!isset($this->cache[$type]) OR !is_array($this->cache[$type]))
				{
					// We need to fetch from datastore
					$this->fetchFromDatastore();
				}

				// Cache is fine
				return $this->cache[$type];
				break;
		}
	}

	public function fetchFromDatastore()
	{
		// Grab the extra cache fields
		$extracache = [];
		foreach ($this->_tables as $table => $val)
		{
			$extracache[] = self::PREFIX . $table;
		}

		if (!count($extracache))
		{
			// We don't need to do this
			return;
		}

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$cache = $this->cacheObj->getMulti($extracache);
				foreach ($cache as $title => $data)
				{
					// Shorthand
					$type = substr($title, strlen(self::PREFIX));

					// Check if the value is set
					if (!is_array($data))
					{
						// Build datastore
						$data = $this->build($type);
					}
					else
					{
						// Set the cache data at last
						$this->set($type, $data);
					}
				}
				break;

			case 'vBulletin':
				// Do fetch from the database
				$GLOBALS['vbulletin']->datastore->fetch($extracache);

				foreach ($extracache as $title)
				{
					// Shorthand
					$type = substr($title, strlen(self::PREFIX));

					// Check if the value is set
					if (!isset($GLOBALS['vbulletin']->$title) OR !is_array($GLOBALS['vbulletin']->$title))
					{
						// Build datastore
						$data = $this->build($type);
					}
					else
					{
						// The data was valid
						$data = $GLOBALS['vbulletin']->$title;

						// Save some memory
						unset($GLOBALS['vbulletin']->title);

						// Set the cache data at last
						$this->set($type, $data);
					}
				}
				break;
		}
	}

	/**
	* Builds the cache in case the datastore has been cleaned out.
	*
	* @param	string	Database table we are working with
	*/
	public function build($type)
	{
		// Premove the prefix
		$dbtype = self::PREFIX . $type;

		// Initialise the some arrays so we can add to them quicker
		$data = [];
		$index = (isset($this->_idColumns[$type]) ? $this->_idColumns[$type] : $type . 'id');

		$query = $this->_getDb()->fetchAll('
			SELECT ' . $dbtype . '.*
			FROM $' . $dbtype . ' AS ' . $dbtype . '
			' . ((isset($this->_tables[$type]) AND $this->_tables[$type]) ? $this->_tables[$type] : '')
		);
		foreach ($query as $result)
		{
			// Store data
			$data[$result[$index]] = $result;

			foreach ($result as $key => $value)
			{
				if (
					isset($this->unserialize[$type])
					AND is_array($this->unserialize[$type])
					AND in_array($key, $this->unserialize[$type])
				)
				{
					// Do unserialize
					$data[$result[$index]][$key] = @unserialize(stripslashes($value));
					$data[$result[$index]][$key] = is_array($data[$result[$index]][$key]) ? $data[$result[$index]][$key] : [];
				}
			}
		}

		if (!is_array($data))
		{
			// Avoid corrupting the cache this way
			return;
		}

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$this->cacheObj->set($dbtype, $data);
				break;

			case 'vBulletin':
				// Finally update the datastore with the new value
				build_datastore($dbtype, serialize($data), 1);
				break;
		}

		// Set the data
		$this->set($type, $data);

		return $data;
	}

	/**
	* Builds the cache for all available tables.
	*/
	public function buildAll()
	{
		foreach ($this->_tables as $type => $clauses)
		{
			// Build this cache
			$this->build($type);
		}
	}

	public function loadDefaults($type, array &$data = array())
	{
		if (isset($this->_defaults[$type]))
		{
			// Merge the defaults and this
			$data = array_replace_recursive($this->_defaults[$type], $data);
		}

		return $data;
	}

	/**
	* Reads from the vB Optimise cache
	*
	* @param	string	Referencing the vB Optimise option varname
	* @param	string	The cache key to read from
	*/
	public function read($cacheType, $key)
	{
		if (!$this->_canCache($cacheType))
		{
			// We can't cache this
			return -1;
		}

		// Fetch the vBO data
		$_data = vb_optimise::$cache->get(str_replace('_', '.', $this->prefix) . '.' . $key);

		if (is_array($_data) AND TIMENOW < $_data['time'])
		{
			// We saved some queries
			vb_optimise::stat(1);
			vb_optimise::report('Fetched ' . str_replace('_', '.', $this->prefix) . '.' . $key . ' from cache successfully.');

			return $_data['cache'];
		}

		return false;
	}

	/**
	* Writes to the vB Optimise cache
	*
	* @param	string	Database table we are working with
	* @param	string	(Optional) Any additional clauses to the query
	*/
	public function write($data, $cacheType, $key, $ttl = -1)
	{
		if (!$this->_canCache($cacheType))
		{
			// We can't cache this
			return false;
		}

		// By default, we want to "null out" the cache
		$_data = false;

		if ($data !== false)
		{
			// Write the vBO data
			$_data = array(
				'time'	=> (
					TIMENOW + (
						isset($GLOBALS['vbulletin']->options['vbo_cache_' . $this->prefix . $cacheType]) ?
							($GLOBALS['vbulletin']->options['vbo_cache_' . $this->prefix . $cacheType] * 3600) :
							($ttl == -1 ? self::TTL : $ttl)
					)
				),
				'cache'	=> $data,
			);
		}

		// Write the cache
		vb_optimise::$cache->set(str_replace('_', '.', $this->prefix) . '.' . $key, $_data);
		vb_optimise::report('Cached ' . str_replace('_', '.', $this->prefix) . '.' . $key . ' successfully.');

		return true;
	}

	/**
	* Writes to the vB Optimise cache
	*/
	public function flush()
	{
		if (!$this->_canCache())
		{
			// We can't cache this
			return false;
		}

		// Flush the cache
		vb_optimise::$cache->flush();

		return true;
	}

	/**
	* Tests whether we can cache something
	*
	* @param	string	Original message
	* @param	string	Overriding
	*/
	protected function _canCache($cacheType = '')
	{
		if (!class_exists('vb_optimise'))
		{
			// We don't have vBO installed
			return false;
		}

		if (!isset($GLOBALS['vbulletin']->options['vbo_online']))
		{
			// vBO is turned off
			return false;
		}

		if (!is_object(vb_optimise::$cache))
		{
			// Not a valid cache object
			return false;
		}

		if (!$cacheType)
		{
			// This will be used for the flush
			return true;
		}

		if (!isset($GLOBALS['vbulletin']->options['vbo_cache_' . $this->prefix . $cacheType]))
		{
			// This cache item has no setting, so we want to cache it
			return true;
		}

		if (!$GLOBALS['vbulletin']->options['vbo_cache_' . $this->prefix . $cacheType])
		{
			// The cache time has been turned off
			return false;
		}

		return true;
	}

	protected function _getDb()
	{
		return DBTech_Shout_Application_Core::getInstance()->_getDb();
	}

	public static final function getInstance()
	{
		if (!self::$_instance)
		{
			self::$_instance = new static();
		}

		return self::$_instance;
	}
}