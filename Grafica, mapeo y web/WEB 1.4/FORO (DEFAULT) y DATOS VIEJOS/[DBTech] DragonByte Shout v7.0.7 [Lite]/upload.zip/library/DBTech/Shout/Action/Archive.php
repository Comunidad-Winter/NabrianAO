<?php
class DBTech_Shout_Action_Archive extends DBTech_Shout_Action
{
	public function actionIndex()
	{
		$cleanedInput = $this->app->filter(array(
			'id' 			=> TYPE_UINT,
			'chatroomid' 	=> TYPE_UINT,
			'page' 			=> TYPE_UINT,
			'perpage' 		=> TYPE_UINT,
			'message' 		=> TYPE_STR,
			
		));

		// Init this
		$instanceCache = $this->cache->get('instance');

		if (!$instance = $instanceCache[$cleanedInput['id']])
		{
			throw new DBTech_Shout_Application_ResponseErrorException($this->app->phrase('vbshout_invalid_instanceid'));
		}

		if (!$instance['active'])
		{
			// Keine permissions
			throw new DBTech_Shout_Application_ResponseErrorException($this->app->phrase('vbshout_invalid_instanceid'));
		}

		if (!$instance['permissions_parsed']['canviewarchive'])
		{
			// Keine permissions
			throw new DBTech_Shout_Application_ResponseErrorException($this->app->phrase('vbshout_invalid_instanceid'));
		}

		// Ensure there's no errors or out of bounds with the page variables
		if ($cleanedInput['page'] < 1)
		{
			$cleanedInput['page'] = 1;
		}
		$page = $cleanedInput['page'];
		$perPage = (!$cleanedInput['perpage']) ? $instance['options']['maxarchiveshouts'] : ($cleanedInput['perpage'] > 250 ? 250 : $cleanedInput['perpage']);
		$startAt = ($page - 1) * $perPage;
		$pageVars = array(
			'instanceid' => $instance['instanceid']
		);
		$args  = array(
			'instanceid' => $instance['instanceid'],
			'archive' => true,
			'startat' => $startAt,
			'perpage' => $perPage
		);

		// Include chatrooms we're a member of (and no chatroom)
		$chatroomMembership = DBTech_Shout_Shoutbox::getInstance()->fetchChatroomMemberships($this->app->getUserInfo(), '1', $instance['instanceid']);
		$chatroomMembership[] = 0;

		if (!$cleanedInput['chatroomid'] OR !in_array($cleanedInput['chatroomid'], $chatroomMembership))
		{
			// @TODO: Re-enable this when we have a way of indicating what chatroom we're viewing a shout from
			//$args['chatroomids'] = $chatroomMembership;
			$cleanedInput['chatroomid'] = 0;
		}
		else
		{
			// Limit by username
			$pageVars['chatroomid'] = $cleanedInput['chatroomid'];
		}

		// Init this
		$searchParams = array();

		if ($instance['permissions_parsed']['cansearcharchive'])
		{
			// Set this straight away as it's pre-validated
			$searchParams['perpage'] = $perPage;

			if ($cleanedInput['message'])
			{
				// Limit by message
				//$hook_query_and .= " AND vbshout.message LIKE '%" . $db->escape_string($cleanedInput['message']) . "%'";
				$pageVars['message'] = $args['message'] = $cleanedInput['message'];
				$searchParams['message'] = htmlspecialchars($cleanedInput['message']);
			}

			
		}

		// Grab all the shouts
		DBTech_Shout_Shoutbox::getInstance()->fetchShouts($instance, array(), $args);

		// By default, we have 10 top shouters
		$maxTopShouters = 10;

		

		// Fetch all the shout info
		$this->_getTemplate()->setParam('dbtech_shout_archive', 'totalshouts', $this->app->numberFormat($this->_getDb()->fetchOne('
			SELECT COUNT(*)
			FROM $dbtech_vbshout_shout
			WHERE userid > 0
				AND instanceid IN(-1, 0, ?)
				' . ($cleanedInput['chatroomid'] ? "AND chatroomid = " . intval($cleanedInput['chatroomid']) : '') . '
		', array($instance['instanceid']))));

		// Fetch last 24 hours
		$this->_getTemplate()->setParam('dbtech_shout_archive', 'last24hrs', $this->app->numberFormat($this->_getDb()->fetchOne('
			SELECT COUNT(*)
			FROM $dbtech_vbshout_shout
			WHERE userid > 0
				AND instanceid IN(-1, 0, ?)
				AND dateline >= ?
				' . ($cleanedInput['chatroomid'] ? "AND chatroomid = " . intval($cleanedInput['chatroomid']) : '') . '
		', array($instance['instanceid'], ($this->app->getTime() - 86400)))));

		if ($this->app->getUserInfo('userid'))
		{
			// Set own shouts
			$this->_getTemplate()->setParam('dbtech_shout_archive', 'ownshouts', array(
				'current' => $this->app->numberFormat($this->app->getUserInfo('dbtech_vbshout_shouts')),
				'lifetime' => $this->app->numberFormat($this->app->getUserInfo('dbtech_vbshout_shouts_lifetime')),
			));
		}

		$topShouters = array(
			'current' => $this->_getDb()->fetchAll('SELECT *, dbtech_vbshout_shouts AS numshouts FROM $user HAVING numshouts > 0 ORDER BY numshouts DESC LIMIT ' . $maxTopShouters),
			'lifetime' => $this->_getDb()->fetchAll('SELECT *, dbtech_vbshout_shouts_lifetime AS numshouts FROM $user HAVING numshouts > 0 ORDER BY numshouts DESC LIMIT ' . $maxTopShouters),
		);

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				// Set top shouters
				$this->_getTemplate()->setParam('dbtech_shout_archive', 'topShouters', $topShouters);

				// Set shouts
				$this->_getTemplate()->setParam('dbtech_shout_archive', 'shouts', (isset(DBTech_Shout_Shoutbox::getInstance()->fetched['shouts']) ? DBTech_Shout_Shoutbox::getInstance()->fetched['shouts'] : array()));

				// Set page nav data
				$this->_getTemplate()->setParam('dbtech_shout_archive', 'page', $page);
				$this->_getTemplate()->setParam('dbtech_shout_archive', 'perPage', $perPage);
				$this->_getTemplate()->setParam('dbtech_shout_archive', 'total', intval(DBTech_Shout_Shoutbox::getInstance()->fetched['totalshouts']));
				break;

			case 'vBulletin':
				$topShouters['current'] = array_map('fetch_muserinfo', $topShouters['current']);
				$topShouters['lifetime'] = array_map('fetch_muserinfo', $topShouters['lifetime']);

				$topShoutersRendered = array(
					'current' => '',
					'lifetime' => ''
				);
				foreach ($topShouters as $key => $shouters)
				{
					foreach ($shouters as $userinfo)
					{
						// Render this template
						$topShoutersRendered[$key] .= $this->_getTemplate()->renderTemplate('dbtech_shout_archive_topshouter_bit', array('userinfo' => $userinfo));
					}
				}

				$shoutsRendered = '';
				foreach (DBTech_Shout_Shoutbox::getInstance()->fetched['shouts'] as $shout)
				{
					// Render this template
					$shoutsRendered .= $this->_getTemplate()->renderTemplate('dbtech_shout_archive_shoutbit', array('userinfo' => $userinfo));
				}

				// Finally register the shouts with the template
				$this->_getTemplate()->setParam('dbtech_shout_archive', 'topShouters', $topShoutersRendered);
				$this->_getTemplate()->setParam('dbtech_shout_archive', 'shouts', $shoutsRendered);
				break;
		}

		$this->_getTemplate()->setOutput(
			$this->_getTemplate()->renderTemplate('dbtech_shout_archive', array(
				'instance' => $instance,
				'searchparams' => $searchParams
			))
		);
	}
}
?>