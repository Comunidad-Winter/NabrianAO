<?php
class DBTech_Shout_Action_Ajax_Invisible extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if ($instance['options']['invis'] OR !$instance['permissions_parsed']['caninvisible'])
		{
			// Git oot
			return false;
		}

		if (!($instance['options']['activitytriggers'] & 2048))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter(array(
			'invisibility' => TYPE_BOOL,
		));

		$invisibleSettings =
			is_array($this->app->getUserInfo('dbtech_vbshout_invisiblesettings')) ?
			$this->app->getUserInfo('dbtech_vbshout_invisiblesettings') :
			@unserialize($this->app->getUserInfo('dbtech_vbshout_invisiblesettings'))
		;
		$invisibleSettings =
			is_array($invisibleSettings) ?
			$invisibleSettings :
			array()
		;

		// Set the new invis setting
		$invisibleSettings[$instance['instanceid']] = intval($cleanedInput['invisibility']);

		// Set it back
		$this->app->setUserInfo('dbtech_vbshout_invisiblesettings', $invisibleSettings);

		// Update the user's editor styles
		$this->_getDb()->update('user', array(
			'dbtech_vbshout_invisiblesettings' => trim(serialize($invisibleSettings))
		), '=user:userid= = ' . intval($this->app->getUserInfo('userid')));

		if ($cleanedInput['invisibility'])
		{
			// We're switching to stealth mode, ensure we don't have any sessions
			$this->_getDb()->delete('dbtech_vbshout_session', 'userid = ' . intval($this->app->getUserInfo('userid')) . ' AND instanceid = ' . intval($instance['instanceid']));
		}
	}
}