<?php
class DBTech_Shout_Application_Charset
{
	public $app = null;

	/**
	 * [__construct description]
	 */
	public function __construct()
	{
		// Get the instance
		$this->app = DBTech_Shout_Application_Core::getInstance();
	}

	/**
	 * Converts a string from one character encoding to another.
	 * If the target encoding is not specified then it will be resolved from the current
	 * language settings.
	 *
	 * @param	string|array	The string/array to convert
	 * @param	string	The source encoding
	 * @return	string	The target encoding
	 */
	public function toCharset($in, $in_encoding, $target_encoding = false)
	{
		if (!$target_encoding)
		{
			if (!($target_encoding = $this->getCharset()))
			{
				return $in;
			}
		}

		if (is_object($in))
		{
			foreach ($in as $key => $val)
			{
				$in->$key = $this->toCharset($val, $in_encoding, $target_encoding);
			}

			return $in;
		}
		else if (is_array($in))
		{
			foreach ($in as $key => $val)
			{
				$in[$key] = $this->toCharset($val, $in_encoding, $target_encoding);
			}

			return $in;
		}
		else if (is_string($in))
		{
			// ISO-8859-1 or other Western charset doesn't support Asian ones so that we need to NCR them
			// Iconv will ignore them
			if (preg_match("/^[ISO|Windows|IBM|MAC|CP]/i", $target_encoding))
			{
				$in = $this->ncrEncode($in, true, true);
			}

			// Try iconv
			if (function_exists('iconv'))
			{
				// Try iconv
				$out = @iconv($in_encoding, $target_encoding . '//IGNORE', $in);
				return $out;
			}

			// Try mbstring
			if (function_exists('mb_convert_encoding'))
			{
				return @mb_convert_encoding($in, $target_encoding, $in_encoding);
			}
		}
		else
		{
			// if it's not a string, array or object, don't modify it
			return $in;
		}
	}

	/**
	 * [getCharset description]
	 * @return [type] [description]
	 */
	public function getCharset()
	{
		static $lang_charset = '';
		if (!empty($lang_charset))
		{
			return $lang_charset;
		}

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$lang_charset = 'utf-8';
				break;

			case 'vBulletin':
				if (intval($GLOBALS['vbulletin']->versionnumber) > 3)
				{
					// vB4
					$lang_charset = vB_Template_Runtime::fetchStyleVar('charset');
				}
				else
				{
					// vB3
					$lang_charset = $GLOBALS['stylevar']['charset'];
				}

				if (!empty($lang_charset))
				{
					return $lang_charset;
				}

				$lang_charset = (!empty($GLOBALS['vbulletin']->userinfo['lang_charset'])) ? $GLOBALS['vbulletin']->userinfo['lang_charset'] : 'utf-8';
				break;
		}

		return $lang_charset;
	}

	/**
	* Converts a UTF-8 string into unicode NCR equivelants.
	*
	* @param	string	String to encode
	* @param	bool	Only ncrencode unicode bytes
	* @param	bool	If true and $skip_ascii is true, it will skip windows-1252 extended chars
	* @return	string	Encoded string
	*/
	public function ncrEncode($str, $skip_ascii = false, $skip_win = false)
	{
		if (!$str)
		{
			return $str;
		}

		if (function_exists('mb_encode_numericentity'))
		{
			if ($skip_ascii)
			{
				if ($skip_win)
				{
					$start = 0xFE;
				}
				else
				{
					$start = 0x80;
				}
			}
			else
			{
				$start = 0x0;
			}
			return mb_encode_numericentity($str, array($start, 0xffff, 0, 0xffff), 'UTF-8');
		}

		if ($this->isPcreUnicode())
		{
			return preg_replace_callback(
				'#\X#u',
				function ($matches) use ($skip_ascii, $skip_win)
				{
					return $this->ncrencodeMatches($matches, (int)$skip_ascii, (int)$skip_win);
				},
				$str
			);
		}

		return $str;
	}

	/**
	 * [isPcreUnicode description]
	 * @return boolean [description]
	 */
	public function isPcreUnicode()
	{
		static $enabled;

		if (NULL !== $enabled)
		{
			return $enabled;
		}

		return $enabled = @preg_match('#\pN#u', '1');
	}

	/**
	 * [ncrencodeMatches description]
	 * @param  [type]  $matches    [description]
	 * @param  boolean $skip_ascii [description]
	 * @param  boolean $skip_win   [description]
	 * @return [type]              [description]
	 */
	public function ncrencodeMatches($matches, $skip_ascii = false, $skip_win = false)
	{
		$ord = ordUni($matches[0]);

		if ($skip_win)
		{
			$start = 254;
		}
		else
		{
			$start = 128;
		}

		if ($skip_ascii AND $ord < $start)
		{
			return $matches[0];
		}

		return '&#' . ordUni($matches[0]) . ';';
	}

	/**
	 * Gets the Unicode Ordinal for a UTF-8 character.
	 *
	 * @param	string	Character to convert
	 * @return	int		Ordinal value or false if invalid
	 */
	public function ordUni($chr)
	{
		// Valid lengths and first byte ranges
		static $check_len = array(
			1 => array(0, 127),
			2 => array(192, 223),
			3 => array(224, 239),
			4 => array(240, 247),
			5 => array(248, 251),
			6 => array(252, 253)
		);

		// Get length
		$blen = strlen($chr);

		// Get single byte ordinals
		$b = array();
		for ($i = 0; $i < $blen; $i++)
		{
			$b[$i] = ord($chr[$i]);
		}

		// Check expected length
		foreach ($check_len AS $len => $range)
		{
			if (($b[0] >= $range[0]) AND ($b[0] <= $range[1]))
			{
				$elen = $len;
			}
		}

		// If no range found, or chr is too short then it's invalid
		if (!isset($elen) OR ($blen < $elen))
		{
			return false;
		}

		// Normalise based on octet-sequence length
		switch ($elen)
		{
			case (1):
				return $b[0];
			case (2):
				return ($b[0] - 192) * 64 + ($b[1] - 128);
			case (3):
				return ($b[0] - 224) * 4096 + ($b[1] - 128) * 64 + ($b[2] - 128);
			case (4):
				return ($b[0] - 240) * 262144 + ($b[1] - 128) * 4096 + ($b[2] - 128) * 64 + ($b[3] - 128);
			case (5):
				return ($b[0] - 248) * 16777216 + ($b[1] - 128) * 262144 + ($b[2] - 128) * 4096 + ($b[3] - 128) * 64 + ($b[4] - 128);
			case (6):
				return ($b[0] - 252) * 1073741824 + ($b[1] - 128) * 16777216 + ($b[2] - 128) * 262144 + ($b[3] - 128) * 4096 + ($b[4] - 128) * 64 + ($b[5] - 128);
		}
	}

	/**
	 * [getInstance description]
	 * @return [type] [description]
	 */
	public static final function getInstance()
	{
		if (!self::$_instance)
		{
			self::$_instance = new static();
		}

		return self::$_instance;
	}

	/**
	 * [destroyInstance description]
	 * @return [type] [description]
	 */
	public static final function destroyInstance()
	{
		if (self::$_instance)
		{
			self::$_instance = NULL;
		}
	}
}
?>