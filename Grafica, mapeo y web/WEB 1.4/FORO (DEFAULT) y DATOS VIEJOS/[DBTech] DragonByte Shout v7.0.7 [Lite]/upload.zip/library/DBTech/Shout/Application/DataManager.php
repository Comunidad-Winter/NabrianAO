<?php
abstract class DBTech_Shout_Application_DataManager
{
	const ERROR_EXCEPTION = 1;
	const ERROR_ARRAY = 2;
	const ERROR_SILENT = 3;
	const ERROR_STANDARD = 4;

	protected $_fields = [];
	protected $_forcedFields = [];
	protected $_newData = [];
	protected $_existingData = [];
	protected $_errors = [];
	protected $_info = [];
	protected $_errorHandler = 0;
	protected $_preSaveCalled = null;
	protected $_preDeleteCalled = null;
	public $app = null;
	public $cache = null;

	/**
	 * [__construct description]
	 * @param [type] $errorHandler [description]
	 */
	public function __construct($errorHandler = self::ERROR_ARRAY)
	{
		// Get the instance
		$this->app = DBTech_Shout_Application_Core::getInstance();
		$this->cache = DBTech_Shout_Cache::getInstance();

		$this->_errorHandler = $errorHandler;

		if (!sizeof($this->_fields))
		{
			$this->error($this->app->phrase('dbtech_vbshout_invalid_field_data'));
		}
	}

	/**
	 * [setExistingData description]
	 * @param [type] $existing [description]
	 */
	public function setExistingData($existing)
	{
		if (!is_array($existing))
		{
			$existing = $this->_getExistingData($existing);
		}

		if (is_array($existing) AND !empty($existing))
		{
			$this->_existingData = $existing;
			return true;
		}
		else
		{
			$this->error($this->app->phrase('dbtech_vbshout_invalid_existing_data'));
			return false;
		}
	}

	/**
	 * [setInfo description]
	 * @param [type] $key [description]
	 * @param [type] $val [description]
	 */
	public function setInfo($key, $val)
	{
		$this->_info[$key] = $val;
	}

	/**
	 * [getInfo description]
	 * @param  [type] $key [description]
	 * @return [type]      [description]
	 */
	public function getInfo($key)
	{
		return isset($this->_info[$key]) ? $this->_info[$key] : NULL;
	}

	/**
	 * [bulkSet description]
	 * @param  array  $fields [description]
	 * @return [type]         [description]
	 */
	public function bulkSet(array $fields)
	{
		foreach ($fields AS $field => $value)
		{
			$this->set($field, $value, '', true);
		}
	}

	/**
	 * [set description]
	 * @param [type]  $field           [description]
	 * @param [type]  $value           [description]
	 * @param string  $tableName       [description]
	 * @param boolean $ignoreUndefined [description]
	 */
	public function set($field, $value, $tableName = '', $ignoreUndefined = false)
	{
		if ($this->_preSaveCalled)
		{
			throw new DBTech_Shout_Application_ResponseErrorException('Set cannot be called after preSave has been called.');
		}

		$definedField = false;
		if (isset($this->_fields[$field]) AND is_array($this->_fields[$field]))
		{
			$definedField = true;

			if ($this->_isFieldValueValid($field, $this->_fields[$field], $value))
			{
				$this->_setInternal($field, $value);
			}
		}

		if (!$definedField AND !$ignoreUndefined)
		{
			$this->error("The field '$field' was not recognised.", $field, false);
		}

		return $definedField;
	}

	/**
	 * [forceSet description]
	 * @param  [type]  $field           [description]
	 * @param  [type]  $value           [description]
	 * @param  string  $tableName       [description]
	 * @param  boolean $ignoreUndefined [description]
	 * @return [type]                   [description]
	 */
	public function forceSet($field, $value, $tableName = '', $ignoreUndefined = false)
	{
		if ($this->_preSaveCalled)
		{
			throw new DBTech_Shout_Application_ResponseErrorException('Set cannot be called after preSave has been called.');
		}

		$definedField = false;
		if (isset($this->_fields[$field]) AND is_array($this->_fields[$field]))
		{
			$definedField = true;

			$this->_forcedFields[] = $field;

			$this->_setInternal($field, $value);
		}

		if (!$definedField AND !$ignoreUndefined)
		{
			$this->error("The field '$field' was not recognised.", $field, false);
		}

		return $definedField;
	}

	/**
	 * [get description]
	 * @param  [type]  $field        [description]
	 * @param  boolean $existingOnly [description]
	 * @return [type]                [description]
	 */
	public function get($field, $existingOnly = false)
	{
		if (array_key_exists($field, $this->_newData) AND !$existingOnly)
		{
			return $this->_newData[$field];
		}
		else if (array_key_exists($field, $this->_existingData))
		{
			return $this->_existingData[$field];
		}

		return null;
	}

	/**
	 * [getExisting description]
	 * @param  [type] $field [description]
	 * @return [type]        [description]
	 */
	public function getExisting($field)
	{
		return $this->get($field, true);
	}

	/**
	* Merges the new and existing data to show a "final" view of the data. This will
	* generally reflect what is in the database.
	*
	* @return array
	*/
	public function getMergedData()
	{
		$output = [];

		if ($this->_newData)
		{
			$output += $this->_newData;
		}

		if ($this->_existingData)
		{
			$output += $this->_existingData;
		}

		return $output;
	}

	/**
	 * [save description]
	 * @return [type] [description]
	 */
	public function save()
	{
		$this->preSave();

		if ($this->_haveErrorsPreventSave())
		{
			if ($this->_errorHandler == self::ERROR_ARRAY)
			{
				return $this->_errors;
			}
			return false;
		}

		if (!$this->_newData)
		{
			if (!$this->_existingData)
			{
				return false;
			}
		}

		$this->_save();

		$this->_postSave();

		return $this->get(static::TABLE_ID);
	}

	/**
	 * [preSave description]
	 * @return [type] [description]
	 */
	public function preSave()
	{
		if ($this->_preSaveCalled)
		{
			return;
		}

		$this->_preSave();

		$this->_checkRequired();

		$this->_preSaveCalled = true;
	}

	/**
	 * [isChanged description]
	 * @param  [type]  $field [description]
	 * @return boolean        [description]
	 */
	public function isChanged($field)
	{
		return $this->isInsert() OR ($this->isUpdate() AND $this->get($field) != $this->getExisting($field));
	}

	/**
	 * Returns true if this DW is updating a record, rather than inserting one.
	 *
	 * @return boolean
	 */
	public function isUpdate()
	{
		return !empty($this->_existingData);
	}

	/**
	 * Returns true if this DW is inserting a record, rather than updating one.
	 *
	 * @return boolean
	 */
	public function isInsert()
	{
		return !$this->isUpdate();
	}

	/**
	 * [_haveErrorsPreventSave description]
	 * @return [type] [description]
	 */
	protected function _haveErrorsPreventSave()
	{
		if ($this->_errors)
		{
			switch ($this->_errorHandler)
			{
				case self::ERROR_SILENT:
				case self::ERROR_ARRAY:
					return true;
					break;

				case self::ERROR_STANDARD:
					throw new DBTech_Shout_Application_ResponseMessageException('<ul><li>' . implode('</li><li>', $this->_errors) . '</li></ul>');
					break;

				case self::ERROR_EXCEPTION:
					throw new DBTech_Shout_Application_ResponseErrorException($this->_errors);
					break;
			}
		}

		return false;
	}

	/**
	 * [_checkRequired description]
	 * @return [type] [description]
	 */
	protected function _checkRequired()
	{
		foreach ($this->_fields AS $field => $fieldData)
		{
			if (!empty($fieldData['required'])
				AND (!array_key_exists($field, $this->_newData)
					OR $this->_newData[$field] === ''
				)
				AND (!array_key_exists($field, $this->_existingData)
					OR $this->_existingData[$field] === ''
				)
			)
			{
				//$this->error($this->app->phrase('dbtech_vbshout_please_enter_value_for_required_field_x', ['param1' => $field]), $field, false);
				$this->error("Missing required field $field", $field, false);
			}
		}
	}

	/**
	 * [getUpdateCondition description]
	 * @return [type] [description]
	 */
	public function getUpdateCondition()
	{
		if (!$this->_existingData)
		{
			return '';
		}
		else
		{
			return $this->_getUpdateCondition();
		}
	}

	/**
	* Internal save handler. Deals with both updates and inserts.
	*/
	protected function _save()
	{
		if ($this->isUpdate())
		{
			$this->_update();
		}
		else
		{
			$this->_insert();
		}
	}

	/**
	 * [_insert description]
	 * @return [type] [description]
	 */
	protected function _insert()
	{
		$insertId = $this->_getDb()->insert(static::TABLE_NAME, $this->_newData, $this->_forcedFields);
		if (isset($this->_fields[static::TABLE_ID]['autoIncrement']) AND $this->_fields[static::TABLE_ID]['autoIncrement'])
		{
			$this->_newData[static::TABLE_ID] = $insertId;
		}

		return $insertId;
	}

	/**
	 * [_update description]
	 * @return [type] [description]
	 */
	protected function _update()
	{
		$condition = $this->getUpdateCondition();
		if (!$condition)
		{
			throw new DBTech_Shout_Application_ResponseErrorException('Cannot update data without a condition');
		}

		if ($this->_newData)
		{
			$this->_getDb()->update(static::TABLE_NAME, $this->_newData, $condition, $this->_forcedFields);
		}
	}

	/**
	 * [delete description]
	 * @return [type] [description]
	 */
	public function delete()
	{
		$this->preDelete();

		if ($this->_haveErrorsPreventSave())
		{
			if ($this->_errorHandler == self::ERROR_ARRAY)
			{
				return $this->_errors;
			}

			return false;
		}

		$this->_delete();

		$this->_postDelete();

		return true;
	}

	/**
	 * [preDelete description]
	 * @return [type] [description]
	 */
	public function preDelete()
	{
		if ($this->_preDeleteCalled)
		{
			return;
		}

		$this->_preDelete();

		$this->_preDeleteCalled = true;
	}

	/**
	 * [_delete description]
	 * @return [type] [description]
	 */
	protected function _delete()
	{
		$condition = $this->getUpdateCondition();
		if (!$condition)
		{
			throw new DBTech_Shout_Application_ResponseErrorException('Cannot delete data without a condition');
		}
		$this->_getDb()->delete(static::TABLE_NAME, $condition);
	}

	/**
	 * [error description]
	 * @param  [type]  $error         [description]
	 * @param  boolean $errorKey      [description]
	 * @param  boolean $specificError [description]
	 * @return [type]                 [description]
	 */
	public function error($error, $errorKey = false, $specificError = true)
	{
		if ($errorKey !== false)
		{
			if ($specificError OR !isset($this->_errors[strval($errorKey)]))
			{
				$this->_errors[strval($errorKey)] = $error;
			}
		}
		else
		{
			$this->_errors[] = $error;
		}

		if ($this->_errorHandler == self::ERROR_EXCEPTION)
		{
			throw new DBTech_Shout_Application_ResponseErrorException($error, true);
		}
	}

	/**
	 * [getErrors description]
	 * @return [type] [description]
	 */
	public function getErrors()
	{
		return $this->_errors;
	}

	/**
	 * [_preSave description]
	 * @return [type] [description]
	 */
	protected function _preSave()
	{
	}

	/**
	 * [_postSave description]
	 * @return [type] [description]
	 */
	protected function _postSave()
	{
	}

	/**
	 * [_preDelete description]
	 * @return [type] [description]
	 */
	protected function _preDelete()
	{
	}

	/**
	 * [_postDelete description]
	 * @return [type] [description]
	 */
	protected function _postDelete()
	{
	}

	/**
	 * [_isFieldValueValid description]
	 * @param  [type]  $fieldName [description]
	 * @param  array   $fieldData [description]
	 * @param  [type]  &$value    [description]
	 * @return boolean            [description]
	 */
	protected function _isFieldValueValid($fieldName, array $fieldData, &$value)
	{
		$fieldType = isset($fieldData['type']) ? $fieldData['type'] : 'binary';
		$value = $this->_castValueToType($fieldType, $value, $fieldName, $fieldData);

		if (!empty($fieldData['verification']))
		{
			if (!$this->_runVerificationCallback($fieldData['verification'], $value, $fieldData, $fieldName))
			{
				// verification callbacks are responsible for throwing errors
				return false;
			}
		}

		$checkLimits = $this->_applyFieldValueLimits($fieldType, $value, $fieldData);

		if ($checkLimits !== true)
		{
			if (!array_key_exists('default', $fieldData))
			{
				$this->error($checkLimits, $fieldName, false);
				return false;
			}
			else
			{
				$value = $fieldData['default'];
			}
		}

		return true;
	}

	/**
	 * [_castValueToType description]
	 * @param  [type] $fieldType [description]
	 * @param  [type] $value     [description]
	 * @param  [type] $fieldName [description]
	 * @param  array  $fieldData [description]
	 * @return [type]            [description]
	 */
	protected function _castValueToType($fieldType, $value, $fieldName, array $fieldData)
	{
		switch ($fieldType)
		{
			case 'string':
				if (isset($fieldData['noTrim']))
				{
					return strval($value);
				}
				else
				{
					return trim(strval($value));
				}

			case 'binary':
				return strval($value);

			case 'uint_forced':
				$value = intval($value);
				return ($value < 0 ? 0 : $value);

			case 'uint':
			case 'int':
				return intval($value);

			case 'float':
				return strval($value) + 0;

			case 'boolean':
				return ($value ? 1 : 0);

			case 'serialized':
				if (!is_string($value))
				{
					return serialize($value);
				}

				if (@unserialize($value) === false AND $value != serialize(false))
				{
					throw new DBTech_Shout_Application_ResponseErrorException('Value is not unserializable');
				}

				return $value;

			case 'unixtime':
				if (is_array($value))
				{
					$value['hour'] 		= isset($value['hour']) 	? intval($value['hour']) 	: 0;
					$value['minute'] 	= isset($value['minute']) 	? intval($value['minute']) 	: 0;
					$value['second'] 	= isset($value['second']) 	? intval($value['second']) 	: 0;
					$value['month'] 	= isset($value['month']) 	? intval($value['month']) 	: 0;
					$value['day'] 		= isset($value['day']) 		? intval($value['day']) 	: 0;
					$value['year'] 		= isset($value['year']) 	? intval($value['year']) 	: 0;

					if ($value['month'] AND $value['day'] AND $value['year'])
					{
						$value = mktime($value['hour'], $value['minute'], $value['second'], $value['month'], $value['day'], $value['year']) + XenForo_Locale::getTimeZoneOffset();
					}
					else
					{
						$value = 0;
					}
				}
				else
				{
					$value = ($value = intval($value)) < 0 ? 0 : $value;
				}

			case 'unknown':
				return $value; // unmodified

			default:
				throw new DBTech_Shout_Application_ResponseErrorException((
					($fieldName === false)
					? "There is no field type '$fieldType'."
					: "The field type specified for '$fieldName' is not valid ($fieldType)."
				));
		}
	}

	/**
	 * [_applyFieldValueLimits description]
	 * @param  [type] $fieldType   [description]
	 * @param  [type] &$value      [description]
	 * @param  array  $extraLimits [description]
	 * @return [type]              [description]
	 */
	protected function _applyFieldValueLimits($fieldType, &$value, array $extraLimits = [])
	{
		// constraints
		switch ($fieldType)
		{
			case 'string':
			case 'binary':
				$strlenFunc = ($fieldType == 'string' ? 'utf8_strlen' : 'strlen');

				if (isset($extraLimits['maxLength']) && $strlenFunc($value) > $extraLimits['maxLength'])
				{
					return $this->app->phrase('dbtech_vbshout_please_enter_value_using_x_characters_or_fewer', ['count' => $extraLimits['maxLength']]);
				}
				break;

			case 'uint_forced':
			case 'uint':
				if ($value < 0)
				{
					return $this->app->phrase('dbtech_vbshout_please_enter_positive_whole_number');
				}
				if (!array_key_exists('max', $extraLimits))
				{
					$extraLimits['max'] = 4294967295;
				}
				break;

			case 'int':
				if (!array_key_exists('min', $extraLimits))
				{
					$extraLimits['min'] = -2147483648;
				}
				if (!array_key_exists('max', $extraLimits))
				{
					$extraLimits['max'] = 2147483647;
				}
				break;
		}

		switch ($fieldType)
		{
			case 'uint_forced':
			case 'uint':
			case 'int':
			case 'float':
				if (isset($extraLimits['min']) && $value < $extraLimits['min'])
				{
					return $this->app->phrase('dbtech_vbshout_please_enter_number_that_is_at_least_x', ['param1' => $extraLimits['min']]);
				}

				if (isset($extraLimits['max']) && $value > $extraLimits['max'])
				{
					return $this->app->phrase('dbtech_vbshout_please_enter_number_that_is_no_more_than_x', ['param1' => $extraLimits['max']]);
				}
				break;
		}

		if (isset($extraLimits['allowedValues']) && is_array($extraLimits['allowedValues']) && !in_array($value, $extraLimits['allowedValues']))
		{
			return $this->app->phrase('dbtech_vbshout_please_enter_valid_value');
		}

		return true;
	}

	/**
	 * [_runVerificationCallback description]
	 * @param  [type]  $callback  [description]
	 * @param  [type]  &$value    [description]
	 * @param  array   $fieldData [description]
	 * @param  boolean $fieldName [description]
	 * @return [type]             [description]
	 */
	protected function _runVerificationCallback($callback, &$value, array $fieldData, $fieldName = false)
	{
		if (is_array($callback) AND isset($callback[0]) AND $callback[0] == '$this')
		{
			$callback[0] = $this;
		}

		return (boolean)call_user_func_array($callback,
			[&$value, $this, $fieldName, $fieldData]
		);
	}

	/**
	 * [_setInternal description]
	 * @param [type]  $field    [description]
	 * @param [type]  $newValue [description]
	 * @param boolean $forceSet [description]
	 */
	protected function _setInternal($field, $newValue, $forceSet = false)
	{
		$existingValue = $this->get($field);
		if ($forceSet
			OR $existingValue === null
			OR !is_scalar($newValue)
			OR !is_scalar($existingValue)
			OR strval($newValue) !== strval($existingValue)
		)
		{
			if ($newValue === $this->getExisting($field))
			{
				unset($this->_newData[$field]);
			}
			else
			{
				$this->_newData[$field] = $newValue;
			}
		}
	}

	/**
	 * [verifyUserId description]
	 * @param  [type]       &$userId   [description]
	 * @param  _DataManager $dm        [description]
	 * @param  boolean      $fieldName [description]
	 * @return [type]                  [description]
	 */
	public static function verifyUserId(&$userId, DBTech_Shout_Application_DataManager $dm, $fieldName = false)
	{
		// Check for existing instance of this name
		if ($existing = $dm->_getDb()->fetchRow('
			SELECT `=user:userid=`
			FROM `$user`
			WHERE `=user:userid=` = ?
		', [
			$userId
		]))
		{
			return true;
		}

		$dm->error($dm->app->phrase('dbtech_vbshout_userid'), $fieldName);
		return false;
	}

	/**
	 * [verifyUserIdOrZero description]
	 * @param  [type]       &$userId   [description]
	 * @param  _DataManager $dm        [description]
	 * @param  boolean      $fieldName [description]
	 * @return [type]                  [description]
	 */
	public static function verifyUserIdOrZero(&$userId, DBTech_Shout_Application_DataManager $dm, $fieldName = false)
	{
		if ($userId == 0)
		{
			return true;
		}

		return self::verifyUserId($userId, $dm, $fieldName);
	}

	/**
	 * [verifyCommaList description]
	 * @param  [type]       &$list     [description]
	 * @param  _DataManager $dm        [description]
	 * @param  boolean      $fieldName [description]
	 * @return [type]                  [description]
	 */
	public static function verifyCommaList(&$list, DBTech_Shout_Application_DataManager $dm, $fieldName = false)
	{
		if ($list === '')
		{
			return true;
		}

		if (is_array($list))
		{
			$list = implode(',', $list);
		}

		$items = explode(',', $list);
		$listNew = implode(',', $items);

		if ($list === $listNew)
		{
			return true;
		}

		// debugging message, no need for phrasing
		$dm->error("Please provide a list of values separated by commas only.", $fieldName);
		return false;
	}

	/**
	 * Verifies that the column is valid.
	 *
	 * @param string $column
	 *
	 * @return boolean
	 */
	public static function verifySqlSafe(&$column, DBTech_Shout_Application_DataManager $dm, $fieldName = false, array $fieldData = [])
	{
		$column = strval($column);
		if ($column === '')
		{
			// Invalid
			return false;
		}

		// Ensure this is valid
		$column = preg_replace('/[^a-zA-Z0-9_]/i', '_', preg_quote($column));

		return true;
	}

	/**
	* Verification callback to check the email address is in a valid form
	*
	* @param string Email Address
	*
	* @return bool
	*/
	public static function verifyEmail(&$email, DBTech_Shout_Application_DataManager $dm, $fieldName = false, array $fieldData = [])
	{
		if ($dm->isUpdate() && $email === $dm->getExisting('email'))
		{
			return true;
		}

		$app = DBTech_Shout_Application_Core::getInstance();
		switch ($app->getSystem())
		{
			case 'XenForo':
				if (!XenForo_Helper_Email::isEmailValid($email))
				{
					$dm->error($app->phrase('please_enter_valid_email'), $fieldName);
					return false;
				}
				break;

			case 'vBulletin':
				if (!is_valid_email($email))
				{
					$dm->error($app->phrase('dbtech_vbshout_please_enter_valid_email'), $fieldName);
					return false;
				}
				break;
		}

		return true;
	}

	/**
	* Gets the actual existing data out of data that was passed in. This data
	* may be a scalar or an array. If it's a scalar, assume that it is the primary
	* key (if there is one); if it is an array, attempt to extract the primary key
	* (or some other unique identifier). Then fetch the correct data from a model.
	*
	* @param mixed Data that can uniquely ID this item
	*
	* @return array|false
	*/
	abstract protected function _getExistingData($data);

	/**
	* Gets SQL condition to update the existing record. Should read from {@link _existingData}.
	*
	* @param string Table name
	*
	* @return string
	*/
	abstract protected function _getUpdateCondition();

	/**
	 * [_getDb description]
	 * @return [type] [description]
	 */
	public function _getDb()
	{
		return DBTech_Shout_Application_Core::getInstance()->_getDb();
	}

	/**
	* Factory method to get the named data writer. The class must exist or be autoloadable
	* or an exception will be thrown.
	*
	* @param string     $class Class to load
	* @param mixed      $errorHandler Error handler. See {@link ERROR_EXCEPTION} and related.
	*
	* @throws Exception
	*
	* @return DBTech_Shout_Application_DataManager
	*/
	public static function create($class, $errorHandler = self::ERROR_ARRAY)
	{
		$app = DBTech_Shout_Application_Core::getInstance();
		switch ($app->getSystem())
		{
			case 'XenForo':
				$createClass = XenForo_Application::resolveDynamicClass($class, 'datawriter');
				break;

			case 'vBulletin':
				// Simple
				$createClass = $class;
				break;
		}
		if (!$createClass)
		{
			throw new DBTech_Shout_Application_ResponseErrorException("Invalid data writer '$class' specified");
		}

		return new $createClass($errorHandler);
	}
}