<?php
class DBTech_Shout_ActionAdmin_Repaircache extends DBTech_Shout_ActionAdmin
{
	public function actionIndex()
	{
		$this->cache->buildAll();

		$this->app->redirect(
			$this->app->phrase('dbtech_vbshout_x_y', array(
				'param1' => $this->app->phrase('dbtech_vbshout_cache'),
				'param2' => $this->app->phrase('dbtech_vbshout_rebuilt')
			)),
			$this->app->link('instance', [
				'success' => 1
			])
		);
	}
}
?>