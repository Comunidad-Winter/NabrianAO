<?php

class DBTech_Shout_XenForo_ControllerPublic_Profile extends XenForo_ControllerPublic_Abstract
{
	/**
	 * Member mini-profile (for popup)
	 *
	 * @return XenForo_ControllerResponse_View
	 */
	public function actionIndex()
	{
		$userId = $this->_input->filterSingle('userid', XenForo_Input::UINT);
		$userFetchOptions = array(
			'join' => XenForo_Model_User::FETCH_LAST_ACTIVITY | XenForo_Model_User::FETCH_USER_PERMISSIONS
		);
		$user = $this->getHelper('UserProfile')->getUserOrError($userId, $userFetchOptions);

		$visitor = XenForo_Visitor::getInstance();
		$userModel = $this->_getUserModel();

		$user = $userModel->prepareUserCard($user);

		// get last activity details
		$user['activity'] = ($user['view_date'] ? $this->getModelFromCache('XenForo_Model_Session')->getSessionActivityDetails($user) : false);

		$user['isFollowingVisitor'] = $userModel->isFollowing($visitor['user_id'], $user);

		$canCleanSpam = (XenForo_Permission::hasPermission($visitor['permissions'], 'general', 'cleanSpam') && $userModel->couldBeSpammer($user));

		$instanceId = $this->_input->filterSingle('instanceid', XenForo_Input::UINT);
		$chatroomId = $this->_input->filterSingle('chatroomid', XenForo_Input::UINT);
		$shoutId = $this->_input->filterSingle('shoutid', XenForo_Input::UINT);

		// Boo.
		$user['userid'] = $user['user_id'];

		// Init this
		$instanceCache = DBTech_Shout_Cache::getInstance()->get('instance');
		$instance = $instanceCache[$instanceId];

		if ($chatroomId)
		{
			// Init this
			$chatroomCache = DBTech_Shout_Cache::getInstance()->get('chatroom');
			$chatroom = $chatroomCache[$chatroomId];
		}

		$isProtected = false;
		try
		{
			DBTech_Shout_Shoutbox::getInstance()->checkProtectedUserGroup($instance, $user);
		}
		catch (Exception $e)
		{
			// Yeah
			$isProtected = true;
		}

		$user['dbtech_vbshout_settings'] = isset($user['dbtech_vbshout_settings']) ? $user['dbtech_vbshout_settings'] : 8191;
		$visitor['dbtech_vbshout_settings'] = isset($visitor['dbtech_vbshout_settings']) ? $visitor['dbtech_vbshout_settings'] : 8191;

		$viewParams = array(
			'user' => $user,

			'canBanUsers' => ($visitor['is_admin'] && $visitor->hasAdminPermission('ban') && $user['user_id'] != $visitor->getUserId() && !$user['is_admin'] && !$user['is_moderator']),
			'canEditUser' => $userModel->canEditUser($user),
			'canViewIps' => $userModel->canViewIps(),
			'canCleanSpam' => $canCleanSpam,
			'canViewOnlineStatus' => $userModel->canViewUserOnlineStatus($user),
			'canViewCurrentActivity' => $userModel->canViewUserCurrentActivity($user),
			'canStartConversation' => $userModel->canStartConversationWithUser($user),
			'canViewWarnings' => $userModel->canViewWarnings(),
			'canWarn' => $userModel->canWarnUser($user),
			'canIgnore' => $this->_getIgnoreModel()->canIgnoreUser($visitor['user_id'], $user),

			'shoutId' => $shoutId,
			'instanceId' => $instanceId,
			'jsUserName' => str_replace('"', '\"', $user['username']),
			'permissions' => array(
				'canShout' => $instance['permissions_parsed']['canshout'],
				'canEditShout' => (
					($user['user_id'] == $visitor['user_id'] AND $instance['permissions_parsed']['caneditown'])
					OR ($user['user_id'] != $visitor['user_id'] AND $instance['permissions_parsed']['caneditothers'])
				),
				'canPm' 		=> !(!($user['dbtech_vbshout_settings'] & 128) OR !($visitor['dbtech_vbshout_settings'] & 128) OR !$instance['options']['enablepms'] OR $user['user_id'] == $visitor['user_id']),
				'isProtected' 	=> ($isProtected OR $user['user_id'] == $visitor['user_id'] OR !$shoutId),
				'canBan' 		=> $instance['permissions_parsed']['canban'],
				'canKick' 		=> (isset($chatroom) AND isset($chatroom['creator']) AND $chatroom['creator'] == $visitor['user_id'] AND $user['user_id'] != $visitor['user_id']),
				
			),
		);

		return $this->responseView('DBTech_Shout_ViewPublic_Member_Card', 'dbtech_shout_member_card', $viewParams);
	}

	/**
	 * @return XenForo_Model_User
	 */
	protected function _getUserModel()
	{
		return $this->getModelFromCache('XenForo_Model_User');
	}

	/**
	 * @return XenForo_Model_UserIgnore
	 */
	protected function _getIgnoreModel()
	{
		return $this->getModelFromCache('XenForo_Model_UserIgnore');
	}
}