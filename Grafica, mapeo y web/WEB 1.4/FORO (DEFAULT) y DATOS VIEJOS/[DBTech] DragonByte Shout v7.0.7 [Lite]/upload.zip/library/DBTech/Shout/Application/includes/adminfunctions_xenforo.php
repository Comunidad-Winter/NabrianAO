<?php
/**
* Starts Gzip encoding and prints out the main control panel page start / header
*
* @param	string	The page title
* @param	string	Javascript functions to be run on page start - for example "alert('moo'); alert('baa');"
* @param	string	Code to be inserted into the <head> of the page
* @param	integer	Width in pixels of page margins (default = 0)
* @param	string	HTML attributes for <body> tag - for example 'bgcolor="red" text="orange"'
*/
function print_cp_header($title = '', $onload = '', $headinsert = '', $marginwidth = 0, $bodyattributes = '')
{
	$app = $GLOBALS['appName']::getInstance();

	$app->_getTemplate()->setParam('output', 'title', $title);
	$app->_getTemplate()->setOutput("
		<script>
		$(function() {
			$('input[name=\"allbox\"]').click(function(){
			    $('input:checkbox').not(this).prop('checked', this.checked);
			});
		});
		</script>
	");
}

/**
* Prints the page footer, finishes Gzip encoding and terminates execution
*/
function print_cp_footer()
{
	$app = $GLOBALS['appName']::getInstance();

	if (isset($_REQUEST['_xfResponseType']) AND $_REQUEST['_xfResponseType'] == 'json')
	{
		$params = [];
		$params['h1'] = $app->_getTemplate()->getParams('output', 'title');
		$params['templateHtml'] = $app->_getTemplate()->getOutput();
		die(json_encode($params));
	}
}

/**
* Halts execution and shows a message based upon a parsed phrase
*
* After the first parameter, this function can take any number of additional
* parameters, in order to replace {1}, {2}, {3},... {n} variable place holders
* within the given phrase text. The parsed phrase is then passed to print_cp_message()
*
* Note that a redirect can be performed if CP_REDIRECT is defined with a URL
*
* @param	string	Name of phrase (from the Error phrase group)
* @param	string	1st variable replacement {1}
* @param	string	2nd variable replacement {2}
* @param	string	Nth variable replacement {n}
*/
function print_stop_message($phrasename)
{
	$app = $GLOBALS['appName']::getInstance();

	$params = func_get_args();
	unset($params[0]);

	$constructedParams = [];
	foreach ($params as $key => $param)
	{
		$constructedParams["param$key"] = $param;
	}

	print_cp_message(
		$app->phrase($phrasename, $constructedParams),
		defined('CP_REDIRECT') ? CP_REDIRECT : NULL
	);
}

/**
* Halts execution and shows the specified message
*
* @param	string	Message to display
* @param	mixed	If specified, a redirect will be performed to the URL in this parameter
* @param	integer	If redirect is specified, this is the time in seconds to delay before redirect
* @param	string	If specified, will provide a specific URL for "Go Back". If empty, no button will be displayed!
* @param bool		If true along with redirect, 'CONTINUE' button will be used instead of automatic redirect
*/
function print_cp_message($text = '', $redirect = NULL, $delay = 1, $backurl = NULL, $continue = false)
{
	$app = $GLOBALS['appName']::getInstance();

	if ($redirect !== NULL)
	{
		if (isset($_REQUEST['_xfResponseType']) AND $_REQUEST['_xfResponseType'] == 'json')
		{
			$redirectParams = [];
			$redirectParams['_redirectTarget'] = $redirect;
			$redirectParams['_redirectMessage'] = $text ? $text : $app->phrase('redirect_changes_saved_successfully');
			die(json_encode($redirectParams));
		}
		else
		{
			$text = $app->_getTemplate()->getOutput() . '<br /><br />' . $text;

			$paths = XenForo_Application::get('requestPaths');
			$app->_getTemplate()->renderOutput(
				$app->_getTemplate()->renderTemplate('dbtech_vbshout_standard_redirect', ['basePath' => $paths['fullBasePath'], 'url' => $redirect, 'message' => $text])
			);
		}
	}
	else if (isset($_REQUEST['_xfResponseType']) AND $_REQUEST['_xfResponseType'] == 'json')
	{
		$params = [];
		$params['error'] = ['title' => 'Error'];
		$params['templateHtml'] = $app->_getTemplate()->renderTemplate('error', ['error' => [$text], 'showHeading' => true]);
		die(json_encode($params));
	}

	$addonModel = XenForo_Model::create('XenForo_Model_AddOn');
	$bridge = $addonModel->getAddOnById('dbtech_integration');

	$app->_getTemplate()->renderOutput($text, [], (($bridge AND !$addonModel->isAddOnDisabled($bridge)) ? 'dbtech' : 'applications'));
}

/**
* Prints the standard form header, setting target script and action to perform
*
* @param	string	PHP script to which the form will submit (ommit file suffix)
* @param	string	'do' action for target script
* @param	boolean	Whether or not to include an encoding type for the form (for file uploads)
* @param	boolean	Whether or not to add a <table> to give the form structure
* @param	string	Name for the form - <form name="$name" ... >
* @param	string	Width for the <table> - default = '90%'
* @param	string	Value for 'target' attribute of form
* @param	boolean	Whether or not to place a <br /> before the opening form tag
* @param	string	Form method (GET / POST)
* @param	integer	CellSpacing for Table
*/
function print_form_header($phpscript = '', $do = '', $uploadform = false, $addtable = true, $name = 'cpform', $width = '90%', $target = '', $echobr = true, $method = 'post', $cellspacing = 0, $border_collapse = false, $formid = '')
{
	$app = $GLOBALS['appName']::getInstance();

	global $formOptions;

	$formOptions = [];
	$formOptions['id'] = $formid ? $formid : $name;
	$formOptions['name'] = $name;
	$formOptions['method'] = $method;
	$formOptions['action'] = $app->link($do);
	$formOptions['upload'] = $uploadform;

	if ($formOptions['name'] == 'cpform' AND !$uploadform)
	{
		// Make sure we're using AJAX form
		$formOptions['class'] = 'AutoValidator';

		if ($method == 'post')
		{
			$formOptions['data-redirect'] = 'yes';
		}
	}
}


/**
* This does nothing as we don't use tables
*/
function print_table_start()
{
}

/**
* This does nothing as we don't use tables
*/
function print_table_break()
{
}

/**
* Adds an entry to the $_HIDDENFIELDS array for later printing as an <input type="hidden" />
*
* @param	string	Name for hidden field
* @param	string	Value for hidden field
* @param	boolean	Whether or not to htmlspecialchars the hidden field value
*/
function construct_hidden_code($name, $value = '', $htmlise = true)
{
	$app = $GLOBALS['appName']::getInstance();

	global $_HIDDENFIELDS;

	$_HIDDENFIELDS[$name] = ($htmlise ? htmlspecialchars($value) : $value);
}


/**
* Makes a column-spanning bar with a named <A> and a title, then  reinitialises the background class counter.
*
* @param	string	Title for the row
* @param	integer	Number of columns to span
* @param	boolean	Whether or not to htmlspecialchars the title
* @param	string	Name for <a name=""> anchor tag
* @param	string	Alignment for the title (center / left / right)
* @param	boolean	Whether or not to show the help button in the row
*/
function print_table_header($title, $colspan = 2, $htmlise = false, $anchor = '', $align = 'right', $helplink = true)
{
	$app = $GLOBALS['appName']::getInstance();

	if (!$anchor)
	{
		$app->_getTemplate()->setOutput(
			"\n<div class=\"heading\" style=\"margin-bottom:0\">$title</div>\n",
			($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table')
		);
	}
	else if ($helplink)
	{
		$app->_getTemplate()->setOutput(
			"<div align=\"$align\">$title</div>",
			'tableSectionFooter'
		);
	}
	else
	{
		if (!isset($GLOBALS['_uniqid']))
		{
			// Hack
			$GLOBALS['_uniqid'] = 0;
		}

		if ($app->_getTemplate()->getOutput('tabheaders'))
		{
			$app->_getTemplate()->setOutput('</ul>', 'tabheaders');
			$app->_getTemplate()->setOutput('</li></ul>', 'tabcontents');

			$app->_getTemplate()->setOutput($app->_getTemplate()->getOutput('tabheaders') . $app->_getTemplate()->getOutput('tabcontents'), 'table');

			$app->_getTemplate()->setOutput('', 'tabheaders', true);
			$app->_getTemplate()->setOutput('', 'tabcontents', true);
		}

		$app->_getTemplate()->setOutput('<ul class="tabs Tabs" data-panes="#xenFormPanes' . $GLOBALS['_uniqid'] . ' > li">', 'tabheaders');
		$app->_getTemplate()->setOutput('<ul id="xenFormPanes' . $GLOBALS['_uniqid'] . '">', 'tabcontents');

		$GLOBALS['_uniqid']++;
	}
}

/**
* Prints a row containing an arbitrary number of cells, each containing arbitrary HTML
*
* @param	array	Each array element contains the HTML code for one cell. If the array contains 4 elements, 4 cells will be printed
* @param	boolean	If true, make all cells' contents bold and use the 'thead' CSS class
* @param	mixed	If specified, override the alternating CSS classes with the specified class
* @param	integer	Cell offset - controls alignment of cells... best to experiment with small +ve and -ve numbers
* @param	string	Vertical alignment for the row
* @param	boolean	Whether or not to treat the cells as part of columns - will alternate classes horizontally instead of vertically
* @param	boolean	Whether or not to use 'smallfont' for cell contents
*/
function print_cells_row($array, $isheaderrow = false, $class = false, $i = 0, $valign = 'top', $column = false, $smallfont = false, $helpname = NULL)
{
	$app = $GLOBALS['appName']::getInstance();

	static $counter;
	if (!is_array($array))
	{
		if ($permissionCell = $app->_getTemplate()->getOutput('permissionCell'))
		{
			$app->_getTemplate()->setOutput($permissionCell . '</table>', ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
			$app->_getTemplate()->setOutput('', 'permissionCell', true);
		}
		else
		{
			$app->_getTemplate()->setOutput("<tr><td class=\"sectionFooter\" colspan=\"$counter\">" . $app->_getTemplate()->getOutput('tableSectionFooter') . "</td></tr>", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
			$app->_getTemplate()->setOutput("</table></div>", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
		}

		$app->_getTemplate()->setOutput('', 'tableSectionFooter', true);
		$app->_getTemplate()->setOutput('', 'permissionCell', true);

		$counter = 0;
		return;
	}

	if ($isheaderrow)
	{
		if ($app->_getTemplate()->getOutput('permissionCell'))
		{
			if (!isset($GLOBALS['_uniqid']))
			{
				// Hack
				$GLOBALS['_uniqid'] = 0;
			}

			$app->_getTemplate()->setOutput("
				<table class=\"permissions\" id=\"dbtech_permissioncell_{$GLOBALS['_uniqid']}\">
					<tr class=\"groupHeading\">
						<th class=\"groupTitle\">{$array[1]}</th>
							<th class=\"option\"><a class=\"CheckAll Tooltip\"
								data-offsetx=\"10\" data-offsety=\"-4\"
								data-target=\"#dbtech_permissioncell_{$GLOBALS['_uniqid']} input:radio[value='-1']\"
								title=\"" . $app->phrase('check_all_x', ['option' => $app->phrase('default')]) . "\">" . $app->phrase('default') . "</a></th>
							<th class=\"option\"><a class=\"CheckAll Tooltip\"
								data-offsetx=\"10\" data-offsety=\"-4\"
								data-target=\"#dbtech_permissioncell_{$GLOBALS['_uniqid']} input:radio[value='1']\"
								title=\"" . $app->phrase('check_all_x', ['option' => $app->phrase('yes')]) . "\">" . $app->phrase('yes') . "</a></th>
							<th class=\"option\"><a class=\"CheckAll Tooltip\"
								data-offsetx=\"10\" data-offsety=\"-4\"
								data-target=\"#dbtech_permissioncell_{$GLOBALS['_uniqid']} input:radio[value='0']\"
								title=\"" . $app->phrase('check_all_x', ['option' => $app->phrase('no')]) . "\">" . $app->phrase('no') . "</a></th>
						<th>&nbsp;</th>
					</tr>
			", 'permissionCell', true);

			$GLOBALS['_uniqid']++;
		}
		else
		{
			$counter = count($array);
			$app->_getTemplate()->setOutput("
				<div class=\"dataTableWrapper\">
				<table class=\"dataTable\" style=\"table-layout: fixed; min-width: 450px; margin-top:0\">
				<tr class=\"dataRow\">
			", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));

			foreach ($array as $val)
			{
				$app->_getTemplate()->setOutput("
						<th>$val</th>
				", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
			}

			$app->_getTemplate()->setOutput("
				</tr>
			", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
		}
	}
	else
	{
		$app->_getTemplate()->setOutput("
			<tr class=\"dataRow\">
		", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));

		foreach ($array as $val)
		{
			$app->_getTemplate()->setOutput("
					<td style=\"font-size:11px;\">$val</td>
			", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
		}

		$app->_getTemplate()->setOutput("
			</tr>
		", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
	}
}

/**
* Prints a row containing a <select> list of forums, complete with displayorder, parenting and depth information
*
* @param	string	text for the left cell of the table row
* @param	string	name of the <select>
* @param	mixed	selected <option>
* @param	string	name given to the -1 <option>
* @param	boolean	display the -1 <option> or not.
* @param	boolean	when true, allows multiple selections to be made. results will be stored in $name's array
* @param	string	Text to be used in sprintf() to indicate a 'category' forum, eg: '%s (Category)'. Leave blank for no category indicator
*/
function print_forum_chooser($title, $name, $selectedid = -1, $topname = null, $displayselectforum = false, $multiple = false, $category_phrase = null)
{
	if ($displayselectforum AND $selectedid < 0)
	{
		$selectedid = 0;
	}

	print_select_row($title, $name, construct_forum_chooser_options($displayselectforum, $topname, $category_phrase), $selectedid, 0, $multiple ? 10 : 0, $multiple);
}

/**
* Returns a list of <option> tags representing the list of forums
*
* @param	boolean	Whether or not to display the 'Select Forum' option
* @param	string	If specified, name for the optional top element - no name, no display
* @param	string	Text to be used in sprintf() to indicate a 'category' forum, eg: '%s (Category)'. Leave blank for no category indicator
*
* @return	string	List of <option> tags
*/
function construct_forum_chooser_options($displayselectforum = false, $topname = null, $category_phrase = null)
{
	$app = $GLOBALS['appName']::getInstance();

	$selectoptions = array();

	if ($displayselectforum)
	{
		$selectoptions[0] = $app->phrase('dbtech_vbshout_select_forum');
	}

	if ($topname)
	{
		$selectoptions['-1'] = $topname;
		$startdepth = '--';
	}
	else
	{
		$startdepth = '';
	}

	if (!$category_phrase)
	{
		$category_phrase = '%s';
	}

	foreach ($app->getForumCache() AS $forumid => $forum)
	{
		if (!$forum['allow_posting'])
		{
			$forum['title'] = sprintf($category_phrase, $forum['title']);
		}

		$selectoptions[$forumid] = construct_depth_mark($forum['depth'] + 1, '--', $startdepth) . ' ' . $forum['title'] . ' ' . (!$forum['allow_posting'] ? ('(' . $app->phrase('dbtech_vbshout_closed_for_posting') . ')') : '');
	}

	return $selectoptions;
}

/**
* Returns a hyperlink
*
* @param	string	Hyperlink text
* @param	string	Hyperlink URL
* @param	boolean	If true, hyperlink target="_blank"
* @param	string	If specified, parameter will be used as title="x" tooltip for link
*
* @param	string
*/
function construct_link_code($text, $url, $newwin = false, $tooltip = '', $smallfont = false)
{
	$app = $GLOBALS['appName']::getInstance();

	if ($newwin === true OR $newwin === 1)
	{
		$newwin = '_blank';
	}

	return " <a href=\"$url\"" . ($newwin ? " target=\"$newwin\"" : '') . (!empty($tooltip) ? " title=\"$tooltip\"" : '') . ($smallfont ? " class=\"OverlayTrigger\"" : '') . '>' . "[$text]</a> ";
}


/**
* Prints submit and reset buttons for the current form, then closes the form and table tags
*
* @param	string	Value for submit button - if left blank, will use $app->phrase('save')
* @param	string	Value for reset button - if left blank, will use $app->phrase('reset')
* @param	integer	Number of table columns the cell containing the buttons should span
* @param	string	Optional value for 'Go Back' button
* @param	string	Optional arbitrary HTML code to add to the table cell
* @param	boolean	If true, reverses the order of the buttons in the cell
*/
function print_submit_row($submitname = '', $resetname = '_default_', $colspan = 2, $goback = '', $extra = '', $alt = false)
{
	$app = $GLOBALS['appName']::getInstance();

	// do submit button
	if ($submitname === '_default_' OR $submitname === '')
	{
		$submitname = $app->phrase('save');
	}

	if ($resetname)
	{
		if ($resetname === '_default_')
		{
			$resetname = $app->phrase('reset');
		}
	}

	print_table_footer($colspan, XenForo_Template_Helper_Admin::submitUnit($extra, ['save' => $submitname, 'reset' => $resetname]));
}


/**
* Prints a closing table tag and closes the form tag if it is open
*
* @param	integer	Column span of the optional table row to be printed
* @param	string	If specified, creates an additional table row with this code as its contents
* @param	string	Tooltip for optional table row
* @param	boolean	Whether or not to close the <form> tag
*/
function print_table_footer($colspan = 2, $rowhtml = '', $tooltip = '', $echoform = true)
{
	$app = $GLOBALS['appName']::getInstance();

	global $_HIDDENFIELDS, $formOptions;

	if ($echoform AND is_array($formOptions) AND sizeof($formOptions))
	{
		if ($app->_getTemplate()->getOutput('tabheaders'))
		{
			$app->_getTemplate()->setOutput('</ul>', 'tabheaders');
			$app->_getTemplate()->setOutput('</li></ul>', 'tabcontents');

			$app->_getTemplate()->setOutput($app->_getTemplate()->getOutput('tabheaders') . $app->_getTemplate()->getOutput('tabcontents'), 'table');

			$app->_getTemplate()->setOutput('', 'tabheaders', true);
			$app->_getTemplate()->setOutput('', 'tabcontents', true);
		}

		$app->_getTemplate()->setOutput($rowhtml, 'table');

		if (is_array($_HIDDENFIELDS))
		{
			//DEVDEBUG("Do hidden fields...");
			foreach($_HIDDENFIELDS AS $name => $value)
			{
				$app->_getTemplate()->setOutput("<input type=\"hidden\" name=\"$name\" value=\"$value\" />\n", 'table');
				//DEVDEBUG("> hidden field: $name='$value'");
			}
		}
		$_HIDDENFIELDS = [];

		$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::form($app->_getTemplate()->getOutput('table'), $formOptions));
		$app->_getTemplate()->setOutput('', 'table', true);
		$app->_getTemplate()->setOutput('', 'tableSectionFooter', true);
	}
	else if ($rowhtml != '  &nbsp;  ' AND $tooltip != '  &nbsp;  ')
	{
		if ($rowhtml)
		{
			$app->_getTemplate()->setOutput("<div class=\"sectionFooter\"$tooltip>$rowhtml</div>\n", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
		}
	}
	else if ($rowhtml)
	{
		$app->_getTemplate()->setOutput($rowhtml, ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
	}
}

/**
* Prints a column-spanning row containing arbitrary HTML
*
* @param	string	HTML contents for row
* @param	boolean	Whether or not to htmlspecialchars the row contents
* @param	integer	Number of columns to span
* @param	string	Optional CSS class to override the alternating classes
* @param	string	Alignment for row contents
* @param	string	Name for help button
*/
function print_description_row($text, $htmlise = false, $colspan = 2, $class = '', $align = '')
{
	$app = $GLOBALS['appName']::getInstance();

	if (isset($_REQUEST['_xfResponseType']) AND $_REQUEST['_xfResponseType'] == 'json')
	{
		$app->_getTemplate()->setOutput($htmlise ? htmlspecialchars($text) : $text, 'table');
	}
	else if ($class == 'optiontitle')
	{
		if (!$align AND $app->_getTemplate()->getOutput('tabheaders'))
		{
			if ($app->_getTemplate()->getOutput('tabcontents'))
			{
				$app->_getTemplate()->setOutput('</li>', 'tabcontents');
			}

			$isFirstTab = strpos('<li', $app->_getTemplate()->getOutput('tabheaders')) === false;
			$app->_getTemplate()->setOutput('<li class="' . ($isFirstTab ? 'active' : '') . '"><a class="' . ($isFirstTab ? 'active' : '') . '">' . ($htmlise ? htmlspecialchars($text) : $text) . '</a></li>', 'tabheaders');
			$app->_getTemplate()->setOutput('<li style="display:' . ($isFirstTab ? 'list-item' : 'none') . ';">', 'tabcontents');
		}
		else
		{
			$app->_getTemplate()->setOutput("<div class=\"subHeading\">" . ($htmlise ? htmlspecialchars($text) : $text) . "</div>\n", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
		}
	}
	else
	{
		$app->_getTemplate()->setOutput("<div class=\"" . ($class ? 'secondaryContent' : 'primaryContent') . "\">" . ($htmlise ? htmlspecialchars($text) : $text) . "</div>\n", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
	}
}

/**
* Prints a column-spanning row containing arbitrary HTML
*
* @param	string	HTML contents for row
* @param	integer	Number of columns to span
*/
function print_notice_row($text, $colspan = 2)
{
	$app = $GLOBALS['appName']::getInstance();

	$app->_getTemplate()->setOutput("<div class=\"importantMessage\">" . $text . "</div>\n", ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function print_title_row($title, $name, $value = '', $titlePhrase = '', $htmlise = true, $size = 35, $maxlength = 0)
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBoxUnit(
		preg_replace('/<dfn>.*<\/dfn>/isU', '', $title),
		$name,
		$value,
		['explain' => (isset($matches[1]) ? $matches[1] : '')],
		[
			'size' => $size,
			'maxlength' => $maxlength,
			'_data' => [
				'livetitletemplate' => $titlePhrase
			]
		]
	), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function print_username_row($title, $name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, ['explain' => isset($matches[1]) ? $matches[1] : ''], ['size' => $size, 'maxlength' => $maxlength, 'inputclass' => 'AutoComplete AcSingle', 'autocomplete' => 'off']), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function print_input_row($title, $name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, ['explain' => isset($matches[1]) ? $matches[1] : ''], ['size' => $size, 'maxlength' => $maxlength]), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing an <input type="file" />
*
* @param	string	Title for row
* @param	string	Name for file upload field
* @param	integer	Max uploaded file size in bytes
* @param	integer	Size of file upload field
*/
function print_upload_row($title, $name, $maxfilesize = 1000000, $size = 35)
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::uploadUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, '', ['explain' => isset($matches[1]) ? $matches[1] : ''], ['size' => $size]), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing a list of <input type="checkbox" />
*
* @param	string	Title for row
* @param	string	Name for checkbox
* @param	array	Values to use
* @param	boolean	Whether or not to check the box
* @param	boolean	Whether or not to htmlspecialchars the title
*/
function print_checkbox_array_row($title, $name, $array, array $selected = array(), $htmlise = false)
{
	$app = $GLOBALS['appName']::getInstance();

	$options = [];
	foreach ($array as $value => $label)
	{
		$checked = in_array($value, $selected);
		$options[] = ['name' => $name, 'label' => $label, 'value' => $value, 'selected' => $checked];

		if ($checked)
		{
			construct_hidden_code('set_' . str_replace('[]', '[' . $value . ']', $name), $value);
		}
	}

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::checkBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), '', $options, ['explain' => isset($matches[1]) ? $matches[1] : '']), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Creates <input type="checkbox" /> from an array (array of checked boxes)
*
* @param	string	Name for checkbox
* @param	array	Values to use
* @param	array	The checked value(s)
* @param	boolean	Whether to htmlise the output
*/
function construct_checkbox_options($name, array $array, array $selected = array(), $htmlise = false)
{
	$app = $GLOBALS['appName']::getInstance();

	$options = [];
	foreach ($array as $value => $label)
	{
		$options[] = ['name' => $name . '[]', 'label' => $label, 'value' => $value, 'selected' => in_array($value, $selected)];
	}

	return XenForo_Template_Helper_Admin::checkBox('', $options);
}

/**
* Creates <input type="checkbox" /> from an array (bitfield of checked boxes)
*
* @param	string	Name for checkbox
* @param	array	Values to use
* @param	integer	The bitfield value
* @param	boolean	Whether to htmlise the output
*/
function construct_checkbox_bitfield_options($name, array $array, $bitfield, $htmlise = false)
{
	$app = $GLOBALS['appName']::getInstance();

	$options = [];
	foreach ($array as $value => $label)
	{
		$options[] = ['name' => $name, 'label' => $label, 'value' => $value, 'selected' => ($bitfield & $value)];
	}

	return XenForo_Template_Helper_Admin::checkBox('', $options);
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function print_spinbox_row($title, $name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::spinBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, ['explain' => isset($matches[1]) ? $matches[1] : ''], ['size' => $size, 'maxlength' => $maxlength]), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing 'yes', 'no' <input type="radio" / > buttons
*
* @param	string	Title for row
* @param	string	Name for radio buttons
* @param	string	Selected button's value
* @param	string	Optional Javascript code to run when radio buttons are clicked - example: ' onclick="do_something()"'
*/
function print_yes_no_row($title, $name, $value = 1, $onclick = '')
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::radioUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, [1 => $app->phrase('yes'), 0 => $app->phrase('no')], ['explain' => isset($matches[1]) ? $matches[1] : '']), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing a number of <input type="radio" /> buttons
*
* @param	string	Title for row
* @param	string	Name for radio buttons
* @param	array	Array of value => text pairs representing '<input type="radio" value="$key" />$value' fields
* @param	string	Selected radio button value
* @param	string	CSS class for <span> surrounding radio buttons
* @param	boolean	Whether or not to htmlspecialchars the text for the buttons
*/
function print_radio_row($title, $name, $array, $checked = '', $class = 'normal', $htmlise = false)
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::radioUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $checked, $array, ['explain' => isset($matches[1]) ? $matches[1] : '']), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing 'yes', 'no' and 'other' <input type="radio" /> buttons
*
* @param	string	Title for row
* @param	string	Name for radio buttons
* @param	string	Text label for third button
* @param	string	Selected button's value
* @param	string	Optional Javascript code to run when radio buttons are clicked - example: ' onclick="do_something()"'
*/
function print_yes_no_other_row($title, $name, $thirdopt, $value = 1, $onclick = '')
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput($app->_getTemplate()->renderTemplate('dbtech_vbshout_yes_no_other', ['title' => $title, 'name' => $name, 'value' => $value, 'description' => isset($matches[1]) ? $matches[1] : '']), 'permissionCell');
}

/**
* Prints a row containing an <input type="checkbox" />
*
* @param	string	Title for row
* @param	string	Name for checkbox
* @param	boolean	Whether or not to check the box
* @param	string	Value for checkbox
* @param	string	Text label for checkbox
* @param	string	Optional Javascript code to run when checkbox is clicked - example: ' onclick="do_something()"'
*/
function print_checkbox_row($title, $name, $checked = true, $value = 1, $labeltext = '', $onclick = '')
{
	$app = $GLOBALS['appName']::getInstance();

	if ($labeltext == '')
	{
		$labeltext = $app->phrase('yes');
	}

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(str_replace('[]', '', XenForo_Template_Helper_Admin::checkBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, [$value => $labeltext], ['explain' => isset($matches[1]) ? $matches[1] : ''], ['inputclass' => ($checked ? '" checked="checked"' : '')])), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing a <select> field
*
* @param	string	Title for row
* @param	string	Name for select field
* @param	array	Array of value => text pairs representing '<option value="$key">$value</option>' fields
* @param	string	Selected option
* @param	boolean	Whether or not to htmlspecialchars the text for the options
* @param	integer	Size of select field (non-zero means multi-line)
* @param	boolean	Whether or not to allow multiple selections
*/
function print_select_row($title, $name, $array, $selected = '', $htmlise = false, $size = 0, $multiple = false)
{
	$app = $GLOBALS['appName']::getInstance();

	if ($multiple)
	{
		// vB wants you to specify this, xF does not
		$name = str_replace('[]', '', $name);
	}

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::selectUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $selected, $array, ['explain' => isset($matches[1]) ? $matches[1] : ''], ['size' => $size, 'multiple' => $multiple]), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing a number of <input type="checkbox" /> fields representing a user's membergroups
*
* @param	string	Title for row
* @param	string	Base name for checkboxes - $name[]
* @param	integer	Number of columns to split checkboxes into
* @param	mixed	Either NULL or a user info array
*/
function print_membergroup_row($title, $name = 'membergroup', $columns = 0, $userarray = NULL)
{
	$app = $GLOBALS['appName']::getInstance();

	// create a blank user array if one is not set
	if (!is_array($userarray))
	{
		$userarray = ['membergroupids' => ''];
	}

	$selected = [];
	if (strpos(",$userarray[membergroupids],", ",-1,") !== false)
	{
		$selected[] = -1;
	}

	$options = [
		-1 => $app->phrase('dbtech_vbshout_all_usergroups')
	];
	foreach ($app->getUserGroupCache() AS $usergroupid => $usergroup)
	{
		// add to the options array
		$options[$usergroupid] = $usergroup['title'];

		if (strpos(",$userarray[membergroupids],", ",$usergroupid,") !== false)
		{
			// This was selected
			$selected[] = $usergroupid;
		}
	}

	print_checkbox_array_row($title, $name . '[]', $options, $selected);
}

/**
* Prints a row containing form elements to input a date & time
*
* Resulting form element names: $name[day], $name[month], $name[year], $name[hour], $name[minute]
*
* @param	string	Title for row
* @param	string	Base name for form elements - $name[day], $name[month], $name[year] etc.
* @param	mixed	Unix timestamp to be represented by the form fields OR SQL date field (yyyy-mm-dd)
* @param	boolean	Whether or not to show the time input components, or only the date
* @param	boolean	If true, expect an SQL date field from the unix timestamp parameter instead (for birthdays)
* @param	string	Vertical alignment for the row
*/
function print_time_row($title, $name = 'date', $unixtime = '', $showtime = true, $birthday = false, $valign = 'middle')
{
	$app = $GLOBALS['appName']::getInstance();

	$month = $day = $year = $hour = $minute = '';

	if ($birthday)
	{
		if ($unixtime == '')
		{
			$month = 0;
			$day = '';
			$year = '';
		}
		else
		{
			$temp = explode('-', $unixtime);
			$month = intval($temp[0]);
			$day = intval($temp[1]);
			if ($temp[2] == '0000')
			{
				$year = '';
			}
			else
			{
				$year = intval($temp[2]);
			}
		}
	}
	else if (is_array($unixtime))
	{
		$month = $unixtime['month'];
		$day = $unixtime['day'];
		$year = $unixtime['year'];
		$hour = isset($unixtime['hour']) ? $unixtime['hour'] : '';
		$minute = isset($unixtime['minute']) ? $unixtime['minute'] : '';
	}
	else if (is_int($unixtime))
	{
		$month = $app->date($unixtime, 'n');
		$day = $app->date($unixtime, 'j');
		$year = $app->date($unixtime, 'Y');
		$hour = $app->date($unixtime, 'G');
		$minute = $app->date($unixtime, 'i');
	}

	$choices = [
		'' => '',
		1 => $app->phrase('month_1'),
		2 => $app->phrase('month_2'),
		3 => $app->phrase('month_3'),
		4 => $app->phrase('month_4'),
		5 => $app->phrase('month_5'),
		6 => $app->phrase('month_6'),
		7 => $app->phrase('month_7'),
		8 => $app->phrase('month_8'),
		9 => $app->phrase('month_9'),
		10 => $app->phrase('month_10'),
		11 => $app->phrase('month_11'),
		12 => $app->phrase('month_12'),
	];

	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::select($name . '[month]', $month, $choices, ['inputclass' => 'autoSize']), 'timerow');
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBox($name . '[day]', $day, ['inputclass' => 'autoSize', 'placeholder' => $app->phrase('day')]), 'timerow');
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBox($name . '[year]', $year, ['inputclass' => 'autoSize', 'placeholder' => $app->phrase('year')]), 'timerow');

	if ($showtime)
	{
		$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBox($name . '[hour]', $hour, ['inputclass' => 'autoSize', 'placeholder' => $app->phrase('hour')]), 'timerow');
		$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBox($name . '[minute]', $minute, ['inputclass' => 'autoSize', 'placeholder' => $app->phrase('minute')]), 'timerow');
	}

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::controlUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), ['html' => $app->_getTemplate()->getOutput('timerow'), 'explain' => isset($matches[1]) ? $matches[1] : '']), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));

	$app->_getTemplate()->setOutput('', 'timerow', true);
}

/**
* Returns a 'depth mark' for use in prefixing items that need to show depth in a hierarchy
*
* @param	integer	Depth of item (0 = no depth, 3 = third level depth)
* @param	string	Character or string to repeat $depth times to build the depth mark
* @param	string	Existing depth mark to append to
*
* @return	string
*/
function construct_depth_mark($depth, $depthchar, $depthmark = '')
{
	$app = $GLOBALS['appName']::getInstance();

	for ($i = 0; $i < $depth; $i++)
	{
		$depthmark .= $depthchar;
	}
	return $depthmark;
}

/**
* Prints a two-cell row with arbitrary contents in each cell
*
* @param	string	HTML contents for first cell
* @param	string	HTML comments for second cell
* @param	string	CSS class for row - if not specified, uses alternating alt1/alt2 classes
* @param	string	Vertical alignment attribute for row (top / bottom etc.)
* @param	string	Name for help button
* @param	boolean	If true, set first cell to 30% width and second to 70%
*/
function print_label_row($title, $value = '&nbsp;', $class = '', $valign = 'top', $helpname = NULL, $dowidth = false)
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::controlUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), ['html' => $value, 'explain' => isset($matches[1]) ? $matches[1] : '']), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
* Prints a row containing a <textarea>
*
* @param	string	Title for row
* @param	string	Name for textarea field
* @param	string	Value for textarea field
* @param	integer	Number of rows for textarea field
* @param	integer	Number of columns for textarea field
* @param	boolean	Whether or not to htmlspecialchars the textarea field value
* @param	boolean	Whether or not to show the 'large edit box' button
* @param	string	Text direction for textarea field
* @param	mixed	If specified, overrides the default CSS class for the textare field
*/
function print_textarea_row($title, $name, $value = '', $rows = 4, $cols = 40, $htmlise = true, $doeditbutton = true, $direction = '', $textareaclass = false)
{
	$app = $GLOBALS['appName']::getInstance();

	preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
	$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::textBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), $name, $value, ['explain' => isset($matches[1]) ? $matches[1] : ''], ['size' => $cols, 'rows' => $rows]), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
 * Constructs a bitfield row
 *
 * @param	string	The label text
 * @param	string	The name of the row for the form
 * @param	string	What bitfields we are using
 * @param	integer	The value of the setting
 */
function print_bitfield_row($title, $name, $bitfield, $value)
{
	$app = $GLOBALS['appName']::getInstance();

	$value = intval($value);
	$HTML = '';
	$bitfielddefs = $app->fetchBitfield($bitfield);

	if ($bitfielddefs === NULL)
	{
		print_label_row($title, "<strong>An error occurred fetching the bitfields</strong>", '', 'top', $name, 40);
	}
	else
	{
		$options = [];
		foreach ($bitfielddefs AS $key => $val)
		{
			// don't show the user's primary group (if set)
			$options[] = ['name' => "{$name}[$val]", 'label' => $app->phrase($key), 'value' => $val, 'selected' => ($value & $val)];
		}

		preg_match('/<dfn>(.*)<\/dfn>/isU', $title, $matches);
		$app->_getTemplate()->setOutput(XenForo_Template_Helper_Admin::checkBoxUnit(preg_replace('/<dfn>.*<\/dfn>/isU', '', $title), '', $options, ['explain' => isset($matches[1]) ? $matches[1] : '']), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
	}
}

/**
* Prints a dialog box asking if the user is sure they want to delete the specified item from the database
*
* @param	string	Name of table from which item will be deleted
* @param	mixed		ID of item to be deleted
* @param	string	PHP script to which the form will submit
* @param	string	'do' action for target script
* @param	string	Word describing item to be deleted - eg: 'forum' or 'user' or 'post' etc.
* @param	mixed		If not empty, an array containing name=>value pairs to be used as hidden input fields
* @param	string	Extra text to be printed in the dialog box
* @param	string	Name of 'title' field in the table in the database
* @param	string	Name of 'idfield' field in the table in the database
*/
function print_delete_confirmation($table, $itemid, $phpscript, $do, $itemname = '', $hiddenfields = 0, $extra = '', $titlename = 'title', $idfield = '')
{
	$app = $GLOBALS['appName']::getInstance();

	$idfield = $idfield ? $idfield : (str_replace('dbtech_vbshout_', '', $table) . 'id');
	$itemname = $itemname ? $itemname : $table;
	$deleteword = 'delete';
	$encodehtml = true;


	$item = $app->_getDb()->fetchRow('
		SELECT ' . $idfield . ', ' . $titlename . ' AS title
		FROM $' . $table . '
		WHERE ' . $idfield . ' = ' . $itemid
	);

	if ($encodehtml
		AND (strcspn($item['title'], '<>"') < strlen($item['title'])
			OR (strpos($item['title'], '&') !== false AND !preg_match('/&(#[0-9]+|amp|lt|gt|quot);/si', $item['title']))
		)
	)
	{
		// title contains html entities that should be encoded
		$item['title'] = htmlspecialchars($item['title']);
	}

	if ($item[$idfield] == $itemid AND !empty($itemid))
	{
		print_form_header($phpscript, $do, 0, 1, '', '75%');
		construct_hidden_code(($idfield == 'styleid' OR $idfield == 'languageid') ? 'do' . $idfield : $idfield, $itemid);
		if (is_array($hiddenfields))
		{
			foreach($hiddenfields AS $varname => $value)
			{
				construct_hidden_code($varname, $value);
			}
		}

		print_table_header($app->phrase('dbtech_vbshout_confirm_deletion_x', ['param1' => $item['title']]), 2, false, ' ');
		print_description_row("
			<blockquote><br />
			" . $app->phrase("are_you_sure_want_to_{$deleteword}_{$itemname}_x", [
				'param1' => $item['title'],
				'param2' => $idfield,
				'param3' => $item["$idfield"],
				'param4' => ($extra ? "$extra<br /><br />" : '')
			]) . "
			<br /></blockquote>\n\t");
		print_submit_row($app->phrase('yes'), 0, 2, $app->phrase('no'));
	}
	else
	{
		print_stop_message('could_not_find', '<b>' . $itemname . '</b>', $idfield, $itemid);
	}
}

/**
* Prints a dialog box asking if the user if they want to continue
*
* @param	string	Phrase that is presented to the user
* @param	string	PHP script to which the form will submit
* @param	string	'do' action for target script
* @param	mixed		If not empty, an array containing name=>value pairs to be used as hidden input fields
*/
function print_confirmation($phrase, $phpscript, $do, array $hiddenfields = [])
{
	$app = $GLOBALS['appName']::getInstance();

	print_form_header($phpscript, $do, 0, 1, '', '75%');
	if (is_array($hiddenfields))
	{
		foreach($hiddenfields AS $varname => $value)
		{
			construct_hidden_code($varname, $value);
		}
	}
	print_table_header($app->phrase('dbtech_vbshout_confirm_action'), 2, false, ' ');
	print_description_row("
		<blockquote><br />
		$phrase
		<br /></blockquote>\n\t");
	print_submit_row($app->phrase('yes'), 0, 2, $app->phrase('no'));

}

/**
* Returns an <input type="button" /> that acts like a hyperlink
*
* @param	string	Value for button
* @param	string	Hyperlink URL; special cases 'submit' and 'reset'
* @param	boolean	If true, hyperlink will open in a new window
* @param	string	If specified, parameter will be used as title="x" tooltip for button
* @param	boolean	If true, the hyperlink URL parameter will be treated as a javascript function call instead
*
* @return	string
*/
function construct_button_code($text = 'Click!', $link = '', $newwindow = false, $tooltip = '', $jsfunction = 0)
{
	$app = $GLOBALS['appName']::getInstance();

	if (preg_match('#^(submit|reset),?(\w+)?$#siU', $link, $matches))
	{
		$name_attribute = ($matches[2] ? " name=\"$matches[2]\"" : '');
		return " <input type=\"$matches[1]\"$name_attribute class=\"button\" value=\"$text\" title=\"$tooltip\" tabindex=\"1\" />";
	}
	else
	{
		return " <input type=\"button\" class=\"button\" value=\"$text\" title=\"$tooltip\" tabindex=\"1\" onclick=\"" . ($jsfunction ? $link : ($newwindow ? "window.open('$link')" : "window.location='$link'")) . ";\"$tooltip/> ";
	}
}

/**
 * Prints a table row but not from a bitfield.
 *
 * @param	string	The label text
 * @param	string	The name of the row for the form
 * @param	string	What bitfields we are using
 * @param	integer	The value of the setting
 */
function print_table_row($text, $name, $array, $value)
{
	$value = intval($value);
	$HTML = '';

	$HTML .= "<div id=\"ctrl_{$name}\" class=\"smallfont\">\r\n";
	foreach ($array AS $key => $val)
	{
		$bit = intval($val['bitfield']);
		$HTML .= "<table style=\"width:175px; float:left\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr valign=\"top\">
		<td>" . construct_checkbox_code($name . "[$bit]", ($value & (int)$bit), "name=&quot;{$name}[$bit]&quot; value=&quot;$bit&quot;", false, $bit) . "</td>
		<td width=\"100%\" style=\"padding-top:4px\"><label for=\"{$name}_$key\" class=\"smallfont\">" . $val['title'] . "</label></td>\r\n</tr></table>\r\n";
	}

	$HTML .= "</div>\r\n";
	#$HTML .= "</fieldset>";
	print_label_row($text, $HTML, '', 'top', $name, 40);
}

/**
 * [construct_checkbox_code description]
 * @param  [type]  $name          [description]
 * @param  [type]  $checked       [description]
 * @param  [type]  $title         [description]
 * @param  boolean $disabled      [description]
 * @param  integer $value         [description]
 * @param  string  $onclick       [description]
 * @param  boolean $includeHidden [description]
 * @return [type]                 [description]
 */
function construct_checkbox_code($name, $checked, $title, $disabled = false, $value = 1, $onclick = '', $includeHidden = true)
{
	return ($includeHidden ? "<input type=\"hidden\" name=\"$name\" value=\"0\" />" : '') . "<input type=\"checkbox\" name=\"$name\" tabindex=\"1\" value=\"$value\"" . ($onclick ? " onclick=\"$onclick\"" : '') . (XenForo_Application::debugMode() ? " title=\"name=&quot;{$name}&quot;\"" : '') . ($checked ? ' checked="checked"' : '') . ($disabled ? ' disabled="disabled"' : '') . ' />';
}

/**
 * [construct_select_code description]
 * @param  [type]  $name     [description]
 * @param  [type]  $array    [description]
 * @param  string  $selected [description]
 * @param  boolean $htmlise  [description]
 * @param  integer $size     [description]
 * @param  boolean $multiple [description]
 * @return [type]            [description]
 */
function construct_select_code($name, $array, $selected = '', $htmlise = false, $size = 0, $multiple = false)
{
	$app = $GLOBALS['appName']::getInstance();

	if ($multiple)
	{
		// vB wants you to specify this, xF does not
		$name = str_replace('[]', '', $name);
	}

	return XenForo_Template_Helper_Admin::select($name, $selected, $array, ['size' => $size, 'multiple' => $multiple, 'inputclass' => 'autoSize']);
}

/**
 * [construct_input_row description]
 * @param  [type]  $name       [description]
 * @param  string  $value      [description]
 * @param  boolean $htmlise    [description]
 * @param  integer $size       [description]
 * @param  integer $maxlength  [description]
 * @param  string  $direction  [description]
 * @param  boolean $inputclass [description]
 * @param  boolean $inputid    [description]
 * @param  string  $extra      [description]
 * @return [type]              [description]
 */
function construct_input_row($name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	$app = $GLOBALS['appName']::getInstance();

	return XenForo_Template_Helper_Admin::textBox($name, $value, ['size' => $size, 'maxlength' => $maxlength, 'after' => $extra, 'inputclass' => 'autoSize']);
}

/**
 * [print_user_search_rows description]
 * @param  boolean $email [description]
 * @return [type]         [description]
 */
function print_user_search_rows($email = false)
{
	$app = $GLOBALS['appName']::getInstance();

	$criteriaHelper = $app->_getTemplate()->getHelper('UserCriteria');
	$params = $criteriaHelper->getDataForUserSearchForm();
	$params['criteria'] = $criteriaHelper->getDefaultUserSearchCriteria();

	$app->_getTemplate()->setOutput($app->_getTemplate()->renderTemplate('helper_user_search_criteria', $params), ($app->_getTemplate()->getOutput('tabcontents') ? 'tabcontents' : 'table'));
}

/**
 * [print_page_nav description]
 * @param  [type] $perPage    [description]
 * @param  [type] $totalItems [description]
 * @param  [type] $page       [description]
 * @param  [type] $linkType   [description]
 * @param  [type] $linkData   [description]
 * @param  array  $linkParams [description]
 * @param  array  $options    [description]
 * @return [type]             [description]
 */
function print_page_nav($perPage, $totalItems, $page, $linkType,
	$linkData = null, array $linkParams = array(), array $options = array()
)
{
	$pageNav = XenForo_Template_Helper_Core::adminPageNav($perPage, $totalItems, $page, $linkType,	$linkData, $linkParams, $options);
	print_table_footer($options['headerCount'], ($pageNav ? $pageNav : '  &nbsp;  '), '  &nbsp;  ');
}
?>