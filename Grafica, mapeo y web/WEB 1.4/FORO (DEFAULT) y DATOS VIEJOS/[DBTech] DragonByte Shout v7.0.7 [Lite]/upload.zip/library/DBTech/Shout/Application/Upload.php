<?php
class DBTech_Shout_Application_Upload
{
	/**
	 * The user-supplied file name of the upload.
	 *
	 * @var string
	 */
	protected $_fileName = '';

	/**
	 * The extension from the user-supplied file name.
	 *
	 * @var string
	 */
	protected $_extension = '';

	/**
	 * Full path to the temporary file created by the upload.
	 *
	 * @var string
	 */
	protected $_tempFile = '';

	/**
	 * If the upload is an image, information about the image.
	 * If null, state is unknown; if false, not an image. Otherwise, array with keys:
	 * 	* from getimagesize()
	 * 	* width/height/type
	 *
	 * @var array|false|null
	 */
	protected $_imageInfo = null;

	/**
	 * True if errors have been checked.
	 *
	 * @var boolean
	 */
	protected $_errorsChecked = false;

	/**
	 * List of errors that occured in the upload.
	 *
	 * @var array
	 */
	protected $_errors = [];

	/**
	 * List of allowed extensions.
	 *
	 * @var array
	 */
	protected $_allowedExtensions = [];

	protected $app = null;
	protected $cache = null;

	/**
	 * Constructor.
	 *
	 * @param string $fileName User-supplied file name
	 * @param string $tempFile Upload temporary file name; this can be an empty string to account for uploads that are too large
	 */
	public function __construct($fileName, $tempFile)
	{
		// Get the instance
		$this->app = DBTech_Shout_Application_Core::getInstance();
		$this->cache = DBTech_Shout_Cache::getInstance();

		if ($tempFile AND !file_exists($tempFile) AND !is_readable($tempFile))
		{
			throw new DBTech_Shout_Application_ResponseErrorException('The temporary file for the upload cannot be found.');
		}

		$fileName = str_replace('%22', '"', $fileName);

		$this->_fileName = $fileName;
		$this->_extension = strtolower(substr(strrchr($fileName, '.'), 1));
		$this->_tempFile = $tempFile;
	}

	public function setFileName($fileName)
	{
		$this->_fileName = $fileName;
		$this->_extension = strtolower(substr(strrchr($fileName, '.'), 1));
	}

	/**
	 * Set the constraints for this upload. Possible keys:
	 * 	* extensions - array of allowed extensions
	 * 	* size - max file size in bytes
	 * 	* width - max image width in pixels
	 * 	* height - max image height in pixels
	 *
	 * @param array $constraints See above for format.
	 */
	public function setConstraints(array $constraints)
	{
		if (!empty($constraints['extensions']) AND is_array($constraints['extensions']))
		{
			$this->_allowedExtensions = array_map('strtolower', $constraints['extensions']);
		}
		if (!empty($constraints['size']) AND $constraints['size'] > 0)
		{
			$this->_maxFileSize = max(0, intval($constraints['size']));
		}
	}

	/**
	 * Returns true if the upload is valid.
	 *
	 * @return boolean
	 */
	public function isValid()
	{
		if (!$this->_errorsChecked)
		{
			$this->_checkForErrors();
		}

		return (count($this->_errors) == 0);
	}

	/**
	 * Returns true if the upload is a valid image.
	 *
	 * @return boolean
	 */
	public function isImage()
	{
		$this->_checkImageState();
		return ($this->_imageInfo ? true : false);
	}

	/**
	 * Checks the state of the upload to determine if it's
	 * a valid image.
	 */
	protected function _checkImageState()
	{
		if ($this->_imageInfo !== null)
		{
			return;
		}

		$this->_imageInfo = false; // default to not an image

		if (!$this->_tempFile)
		{
			return;
		}

		$imageInfo = @getimagesize($this->_tempFile);
		if (!$imageInfo)
		{
			if (in_array($this->_extension, array('gif', 'jpg', 'jpe', 'jpeg', 'png')))
			{
				$this->_errors['extension'] = $this->app->phrase('dbtech_vbshout_uploaderr_uploaded_file_not_img_expected');
			}
			return;
		}

		$imageInfo['width'] = $imageInfo[0];
		$imageInfo['height'] = $imageInfo[1];
		$imageInfo['type'] = $imageInfo[2];

		$type = $imageInfo['type'];
		$extensionMap = array(
			IMAGETYPE_GIF => array('gif'),
			IMAGETYPE_JPEG => array('jpg', 'jpeg', 'jpe'),
			IMAGETYPE_PNG => array('png')
		);
		if (!isset($extensionMap[$type]))
		{
			return; // only consider gif, jpeg, png to be images in this system
		}
		if (!in_array($this->_extension, $extensionMap[$type]))
		{
			$this->_errors['extension'] = $this->app->phrase('dbtech_vbshout_uploaderr_image_context_extension_mismatch');
			return;
		}

		$fp = @fopen($this->_tempFile, 'rb');
		if ($fp)
		{
			$previous = '';
			while (!@feof($fp))
			{
				$content = fread($fp, 256000);
				$test = $previous . $content;
				$exists = (
					strpos($test, '<?php') !== false
					OR preg_match('/<script\s+language\s*=\s*(php|"php"|\'php\')\s*>/i', $test)
				);
				if ($exists) {
					@fclose($fp);
					$this->_errors['content'] = $this->app->phrase('dbtech_vbshout_uploaderr_invalid_image_content');
					return;
				}

				$previous = $content;
			}

			@fclose($fp);
		}

		$this->_imageInfo = $imageInfo;
	}

	/**
	 * Checks for errors in the upload.
	 */
	protected function _checkForErrors()
	{
		$this->_checkImageState();

		if ($this->_allowedExtensions AND !in_array($this->_extension, $this->_allowedExtensions))
		{
			$this->_errors['extension'] = $this->app->phrase('dbtech_vbshout_uploaderr_invalid_extension');
		}

		if (!$this->_tempFile)
		{
			$this->_errors['fileSize'] = $this->app->phrase('dbtech_vbshout_uploaderr_file_too_big');
		}

		$this->_errorsChecked = true;
	}

	/**
	 * Gets the user-supplied file name.
	 *
	 * @return string
	 */
	public function getFileName()
	{
		return $this->_fileName;
	}

	/**
	 * Gets the path to the temporary file.
	 *
	 * @return string
	 */
	public function getTempFile()
	{
		return $this->_tempFile;
	}

	/**
	 * Gets the errors for the upload.
	 *
	 * @return array
	 */
	public function getErrors()
	{
		return $this->_errors;
	}


	public function writeUpload($isImage, $directory, $fileNamePrefix = '')
	{
		if (!is_dir($directory) OR !is_writable($directory))
		{
			throw new DBTech_Shout_Application_ResponseErrorException($this->app->phrase('dbtech_vbshout_uploaderr_directory_not_writable'));
		}

		if (!$this->isValid())
		{
			throw new DBTech_Shout_Application_ResponseErrorException($this->getErrors());
		}

		if ($isImage AND !$this->isImage())
		{
			throw new DBTech_Shout_Application_ResponseErrorException($this->app->phrase('dbtech_vbshout_uploaderr_uploaded_invalid_image'));
		}

		if ($fileNamePrefix)
		{
			// Set prefix if needed
			$this->setFileName($fileNamePrefix . $this->getFileName());
		}

		// Now write this file
		copy($this->getTempFile(), $directory . '/' . $this->getFileName());

		// Get rid of the temp file
		@unlink($this->getTempFile());
	}

	public function writeUploadedFile($directory, $fileNamePrefix = '')
	{
		// Shorthand
		$this->writeUpload(false, $directory, $fileNamePrefix);
	}

	public function writeUploadedImage($directory, $fileNamePrefix = '')
	{
		// Shorthand
		$this->writeUpload(true, $directory, $fileNamePrefix);
	}

	/**
	 * Gets the files that were uploaded into the specified form field (via HTTP POST).
	 *
	 * @param string $formField Name of the form field
	 * @param array|null $source Source array ($_FILES by default).
	 *
	 * @return array Format: [] => <class> objects
	 */
	public static function getUploadedFiles($formField, array $source = null)
	{
		if ($source === null)
		{
			$source = $_FILES;
		}
		if (empty($source[$formField]))
		{
			return [];
		}

		$files = [];
		$field = $source[$formField];

		if (isset($field['name']))
		{
			if (is_array($field['name']))
			{
				foreach (array_keys($field['name']) AS $key)
				{
					if ($field['name'][$key])
					{
						$files[] = new static($field['name'][$key], $field['tmp_name'][$key]);
					}
				}
			}
			else if ($field['name'])
			{
				$files[] = new static($field['name'], $field['tmp_name']);
			}
		}

		return $files;
	}

	/**
	 * Gets the file that was uploaded into the specified form field (via HTTP POST).
	 *
	 * @param string $formField Name of the form field
	 * @param array|null $source Source array ($_FILES by default).
	 *
	 * @return <class> (or false)
	 */
	public static function getUploadedFile($formField, array $source = null)
	{
		$files = static::getUploadedFiles($formField, $source);
		return reset($files);
	}
}