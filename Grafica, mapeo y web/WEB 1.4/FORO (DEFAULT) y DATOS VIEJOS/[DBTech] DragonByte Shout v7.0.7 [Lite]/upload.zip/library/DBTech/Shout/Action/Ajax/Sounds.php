<?php
class DBTech_Shout_Action_Ajax_Sounds extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 64))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter(array(
			'tabs' => TYPE_ARRAY,
		));

		$soundSettings =
			is_array($this->app->getUserInfo('dbtech_vbshout_soundsettings')) ?
			$this->app->getUserInfo('dbtech_vbshout_soundsettings') :
			@unserialize($this->app->getUserInfo('dbtech_vbshout_soundsettings'))
		;
		$soundSettings =
			is_array($soundSettings) ?
			$soundSettings :
			array()
		;

		// Set the new sound setting
		$soundSettings[$instance['instanceid']] = $cleanedInput['tabs'];

		// Set it back
		$this->app->setUserInfo('dbtech_vbshout_soundsettings', $soundSettings);

		// Update the user's editor styles
		$this->_getDb()->update('user', array(
			'dbtech_vbshout_soundsettings' => trim(serialize($soundSettings))
		), '=user:userid= = ' . intval($this->app->getUserInfo('userid')));
	}
}