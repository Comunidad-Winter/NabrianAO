<?php
abstract class DBTech_Shout_Model extends DBTech_Shout_Application_Model
{
}