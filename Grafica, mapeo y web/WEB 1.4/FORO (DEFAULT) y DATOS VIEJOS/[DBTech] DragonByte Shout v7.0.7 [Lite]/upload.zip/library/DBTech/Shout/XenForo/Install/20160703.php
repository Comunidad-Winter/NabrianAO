<?php
class DBTech_Shout_XenForo_Install_20160703 extends DBTech_Shout_XenForo_Install
{
	protected function _install()
	{
		$db = XenForo_Application::getDb();

		try
		{
			$db->query("
				ALTER TABLE `xf_dbtech_vbshout_log`
					CHANGE `ipaddress` `ipaddress` VARCHAR(45) NOT NULL DEFAULT ''
			");
		}
		catch (Zend_Db_Exception $e) {}
	}
}