<?php

/**
 * Route prefix handler for BB code media sites in the admin control panel.
 *
 * @package XenForo_BbCode
 */
class DBTech_Shout_XenForo_Route_PrefixAdmin_Shout implements XenForo_Route_Interface
{
	protected $_subComponents = array(
		'options' => array(
			'actionPrefix' => 'option'
		),
	);

	/**
	 * Match a specific route for an already matched prefix.
	 *
	 * @see XenForo_Route_Interface::match()
	 */
	public function match($routePath, Zend_Controller_Request_Http $request, XenForo_Router $router)
	{
		$controller = 'DBTech_Shout_XenForo_ControllerAdmin_Shout';
		$action = $router->getSubComponentAction($this->_subComponents, $routePath, $request, $controller);

		$addonModel = XenForo_Model::create('XenForo_Model_AddOn');
		$bridge = $addonModel->getAddOnById('dbtech_integration');
		$majorSection = ($bridge AND !$addonModel->isAddOnDisabled($bridge)) ? 'dbtech' : 'applications';

		if ($action === false)
		{
			$action = $router->resolveActionWithIntegerParam($routePath, $request, 'id');

			$request->setParam('_dbtechAction', $action);

			return $router->getRouteMatch($controller, 'index', $majorSection);
		}

		return $router->getRouteMatch($controller, $action, $majorSection);
	}

	/**
	 * Method to build a link to the specified page/action with the provided
	 * data and params.
	 *
	 * @see XenForo_Route_BuilderInterface
	 */
	public function buildLink($originalPrefix, $outputPrefix, $action, $extension, $data, array &$extraParams)
	{
		return XenForo_Link::buildBasicLinkWithIntegerParam($outputPrefix, $action, $extension, $data, 'id', 'title');
	}
}