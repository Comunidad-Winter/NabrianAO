<?php
class DBTech_Shout_XenForo_ControllerAdmin_Shout extends XenForo_ControllerAdmin_Abstract
{
	protected function _preDispatch($action)
	{
		$this->assertAdminPermission('dbtechShout');
	}

	public function actionIndex()
	{
		// Ensure this is done
		DBTech_Shout_Core::destroyInstance();

		// Get the instance
		$app = DBTech_Shout_Core_Admin::getInstance();

		if (!isset($_REQUEST['do']))
		{
			if ($this->_request->isPost())
			{
				$_POST['do'] = $this->_request->getParam('_dbtechAction');
				$_POST['id'] = $this->_input->filterSingle('id', XenForo_Input::UINT);
			}
			else
			{
				$_GET['do'] = $this->_request->getParam('_dbtechAction');
				$_GET['id'] = $this->_input->filterSingle('id', XenForo_Input::UINT);
			}
		}

		try
		{
			// Run the action based on URL params
			$app->runAction();
		}
		catch (XenForo_Exception $e)
		{
			if ($e->isUserPrintable())
			{
				// User printable message
				return $this->responseMessage($e->getMessages());
			}
			else
			{
				// An error
				return $this->responseError($e->getMessages());
			}
		}

		$viewParams = array_merge($this->_getTemplate()->getParams('output'), array(
			'success' => $this->_input->filterSingle('success', XenForo_Input::UINT),
			'html' => $this->_getTemplate()->getOutput(),
		));

		// Init this
		$containerParams = $this->_getTemplate()->getParams('output');

		$containerParams['adminNavigation']['breadCrumb'][$this->getRouteMatch()->getMajorSection()] = [
			'link' => $this->getRouteMatch()->getMajorSection(),
			'title' => ($this->getRouteMatch()->getMajorSection() == 'dbtech') ? 'DragonByte Tech' : $app->phrase('applications')
		];
		$containerParams['adminNavigation']['breadCrumb'][] = [
			'link' => '',
			'title' => $app->phrase('dbtech_vbshout_vbshout_long')
		];

		if ($breadCrumb = $this->_getTemplate()->getParams('_adminNavigation') AND is_array($breadCrumb))
		{
			// Add the breadcrumbs
			$containerParams['adminNavigation']['breadCrumb'] = array_merge($containerParams['adminNavigation']['breadCrumb'], $breadCrumb);
		}

		return $this->responseView('DBTech_Shout_ViewAdmin_Shout', 'dbtech_shout', $viewParams, $containerParams);
	}

	public function actionOption()
	{
		$optionModel = $this->_getOptionModel();

		$fetchOptions = array('join' => XenForo_Model_Option::FETCH_ADDON);

		$group = $this->_getOptionGroupOrError('dbtech_shout', $fetchOptions);
		$groups = $optionModel->getOptionGroupList($fetchOptions);
		$options = $optionModel->getOptionsInGroup($group['group_id'], $fetchOptions);

		$canEdit = $optionModel->canEditOptionAndGroupDefinitions();

		$viewParams = array(
			'group' => $group,
			'groups' => $optionModel->prepareOptionGroups($groups, false),
			'preparedOptions' => $optionModel->prepareOptions($options, false),
			'canEditGroup' => $canEdit,
			'canEditOptionDefinition' => $canEdit
		);

		return $this->responseView('XenForo_ViewAdmin_Option_ListOptions', 'dbtech_shout_option_list', $viewParams);
	}

	/**
	 * Gets the specified option group or throws an exception.
	 *
	 * @param integer $groupId
	 * @param array $fetchOptions
	 *
	 * @return array
	 */
	protected function _getOptionGroupOrError($groupId, array $fetchOptions = array())
	{
		$info = $this->_getOptionModel()->getOptionGroupById($groupId, $fetchOptions);
		if (!$info)
		{
			throw $this->responseException($this->responseError(new XenForo_Phrase('requested_option_group_not_found'), 404));
		}

		if (!empty($fetchOptions['join']) && $fetchOptions['join'] & XenForo_Model_Option::FETCH_ADDON)
		{
			if ($this->getModelFromCache('XenForo_Model_AddOn')->isAddOnDisabled($info))
			{
				throw $this->responseException($this->responseError(
					new XenForo_Phrase('option_group_belongs_to_disabled_addon', array(
						'addon' => $info['addon_title'],
						'link' => XenForo_Link::buildAdminLink('add-ons', $info)
					))
				));
			}
		}

		return $this->_getOptionModel()->prepareOptionGroup($info);
	}

	/**
	 * Lazy load the option model.
	 *
	 * @return XenForo_Model_Option
	 */
	protected function _getOptionModel()
	{
		return $this->getModelFromCache('XenForo_Model_Option');
	}

	protected function _getTemplate()
	{
		return DBTech_Shout_Template::getInstance();
	}
}