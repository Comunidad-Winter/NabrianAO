<?php
class DBTech_Shout_XenForo_EventListener_FrontControllerPostView
{
	public static function listen(XenForo_FrontController $fc, &$output)
	{
		if (
			file_exists(XenForo_Helper_File::getExternalDataPath() . '/dbtechShoutUpgrade.lock')
			AND !XenForo_Application::debugMode()
		)
		{
			return true;
		}

		// Init the core application
		$app = DBTech_Shout_Core::getInstance();

		if (!$app->option('dbtech_vbshout_active') AND !$app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
		{
			// SB isn't even on!
			return true;
		}

		if ($app->getUserInfo('dbtech_vbshout_banned'))
		{
			// Bunned.
			return true;
		}

		$headers = $fc->getResponse()->getHeaders();
		$isText = false;
		foreach ($headers AS $header)
		{
			if ($header['name'] == 'Content-Type')
			{
				if (strpos($header['value'], 'text/') === 0)
				{
					$isText = true;
				}
				break;
			}
		}

		if (!$isText)
		{
			// We only want to do this when it's text we're dealing with
			return true;
		}

		// Init this
		$includedInstances = array();

		// This is text output
		if (preg_match_all('#<!--XFSHOUT.(\w+)-->#', $output, $matches))
		{
			// Init this
			$instanceCache = DBTech_Shout_Cache::getInstance()->get('instance');

			foreach ($instanceCache as $instanceid => $instance)
			{
				if (in_array($instance['varname'], $matches[1]))
				{
					$includedInstances[$instanceid] = $instance;
				}
			}
		}

		if (!$includedInstances)
		{
			// We aren't auto-displaying anything
			return true;
		}

		// Render the wrapper stuff
		if ($vBShout = DBTech_Shout_Shoutbox::getInstance()->renderWrapper($includedInstances))
		{
			foreach ($vBShout['instances'] as $instanceId => $rendered)
			{
				// We have the XFSHOUT tag
				$output = str_replace('<!--XFSHOUT.' . $includedInstances[$instanceId]['varname'] . '-->', $rendered, $output);
			}

			if (!DBTech_Shout_Shoutbox::getInstance()->hasIncludedJS)
			{
				$template = new XenForo_Template_Public('dbtech_shout_shoutbox');

				// Replace </head> tag with our JS / CSS
				$output = str_replace(
					'</head>',
					$template->getRequiredExternalsAsHtml('css') .
					$template->getRequiredExternalsAsHtml('js') .
					'</head>',
					$output
				);

				// We're done here
				unset($template);
			}

			// Replace </body> tag with our JS
			$output = str_replace('</body>', $vBShout['js'] . '</body>', $output);
		}
	}
}