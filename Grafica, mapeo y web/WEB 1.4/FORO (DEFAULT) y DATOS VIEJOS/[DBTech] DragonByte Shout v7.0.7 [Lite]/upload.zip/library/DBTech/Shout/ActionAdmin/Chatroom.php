<?php
class DBTech_Shout_ActionAdmin_Chatroom extends DBTech_Shout_ActionAdmin
{
	// #############################################################################
	public function actionIndex()
	{
		// Init this
		$chatroomCache = $this->cache->get('chatroom');
		$instanceCache = $this->cache->get('instance');

		$chatroomsByInstance = [];
		foreach ($chatroomCache as $chatroomid => $chatroom)
		{
			if (!$chatroom['membergroupids'])
			{
				// This is an on-the-fly chatroom
				continue;
			}

			if (!isset($chatroomsByInstance[$chatroom['instanceid']]))
			{
				// init this
				$chatroomsByInstance[$chatroom['instanceid']] = [];
			}

			$chatroomsByInstance[$chatroom['instanceid']][$chatroomid] = $chatroom;
		}

		print_cp_header($this->app->phrase('dbtech_vbshout_chatroom_management'));

		// Table header
		$headings = [];
		$headings[] = $this->app->phrase('title');
		$headings[] = $this->app->phrase('dbtech_vbshout_usergroups');
		$headings[] = $this->app->phrase('dbtech_vbshout_instance');
		$headings[] = $this->app->phrase('dbtech_vbshout_active');
		$headings[] = $this->app->phrase('edit');

		if (count($chatroomsByInstance))
		{
			print_form_header('vbshout', 'chatroom');
			construct_hidden_code('action', 'mass-update');
			foreach ($chatroomsByInstance as $instanceid => $chatrooms)
			{
				print_table_header($instanceid ? $instanceCache[$instanceid]['name'] : $this->app->phrase('dbtech_vbshout_all_instances'), count($headings));
				print_cells_row($headings, true);

				foreach ($chatrooms as $chatroomid => $chatroom)
				{
					$usergroups = [];

					$memberGroupIds = explode(',', $chatroom['membergroupids']);
					if (in_array(-1, $memberGroupIds))
					{
						$usergroups[] = $this->app->phrase('dbtech_vbshout_all_usergroups');
					}
					else
					{
						foreach($memberGroupIds as $usergroupid)
						{
							// Usergroup cache
							$userGroup = $this->app->getUserGroupCache($usergroupid);
							$usergroups[] = $userGroup['title'];
						}
					}

					// Table data
					$cell = [];
					$cell[] = $chatroom['title'];
					$cell[] = implode(', ', $usergroups);
					$cell[] = ($chatroom['instanceid'] ? $instanceCache[$chatroom['instanceid']]['name'] : $this->app->phrase('dbtech_vbshout_all_instances'));
					$cell[] = construct_checkbox_code("chatroom[$chatroomid][active]", $chatroom['active'], $this->app->phrase('dbtech_vbshout_active'));
					$cell[] = construct_link_code($this->app->phrase('edit'), $this->app->link('chatroom', ['action' => 'modify', 'chatroomid' => $chatroomid]));

					// Print the data
					print_cells_row($cell, false, false, -5, 'middle', false, true);
				}
				print_cells_row(false);
			}
			print_submit_row($this->app->phrase('save'), false, count($headings), false, construct_button_code($this->app->phrase('dbtech_vbshout_add_new_chatroom'), $this->app->link('chatroom', ['action' => 'modify'])));
		}
		else
		{
			print_table_start();
			print_table_header($this->app->phrase('dbtech_vbshout_chatroom_management'), count($headings));
			print_description_row($this->app->phrase('dbtech_vbshout_no_chatrooms'), false, count($headings));
			print_table_footer(count($headings), construct_button_code($this->app->phrase('dbtech_vbshout_add_new_chatroom'), $this->app->link('chatroom', ['action' => 'modify'])));
		}
	}

	// #############################################################################
	public function actionModify()
	{
		// Init this
		$chatroomCache = $this->cache->get('chatroom');
		$instanceCache = $this->cache->get('instance');

		$instances = [];
		$instances[0] = $this->app->phrase('dbtech_vbshout_all_instances');
		
		asort($instances);

		$chatroomid = $this->app->filterSingle('chatroomid', TYPE_UINT);
		$chatroom = ($chatroomid ? $chatroomCache[$chatroomid] : false);

		if (!is_array($chatroom))
		{
			// Non-existing chatroom
			$chatroomid = 0;
		}

		if ($chatroomid)
		{
			// Shorthand
			$titlePhrase = $this->app->phrase('dbtech_vbshout_editing_x_y', ['param1' => $this->app->phrase('dbtech_vbshout_chatroom'), 'param2' => '%s']);
			$titlePhraseParsed = $this->app->phrase('dbtech_vbshout_editing_x_y', ['param1' => $this->app->phrase('dbtech_vbshout_chatroom'), 'param2' => $chatroom['title']]);

			// Edit
			print_cp_header(strip_tags($titlePhraseParsed));
			print_form_header('vbshout', 'chatroom');
			construct_hidden_code('action', 'update');
			construct_hidden_code('chatroomid', $chatroomid);
			print_table_header($titlePhraseParsed, 2, false, ' ', 'center', false);
		}
		else
		{
			// Shorthand
			$titlePhrase = $this->app->phrase('dbtech_vbshout_add_new_chatroom') . ': <em>%s</em>';
			$titlePhraseParsed = $this->app->phrase('dbtech_vbshout_add_new_chatroom');

			// Add
			print_cp_header($titlePhraseParsed);
			print_form_header('vbshout', 'chatroom');
			construct_hidden_code('action', 'update');
			print_table_header($titlePhraseParsed, 2, false, ' ', 'center', false);

			$defaults = [
			];

			// Load defaults from cache
			$chatroom = $this->cache->loadDefaults('chatroom', $defaults);
		}

		$memberGroupIds = explode(',', $chatroom['membergroupids']);
		if (in_array(-1, $memberGroupIds))
		{
			// Ensure only this is checked
			$chatroom['membergroupids'] = '-1';
		}

		print_description_row($this->app->phrase('dbtech_vbshout_main_settings'), false, 2, 'optiontitle');
		print_title_row($this->app->phrase('title'), 							'chatroom[title]', 					$chatroom['title'], 		$titlePhrase);
		print_textarea_row($this->app->phrase('description'), 					'chatroom[description]', 			$chatroom['description']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_active'),			'chatroom[active]',					$chatroom['active']);
		print_description_row($this->app->phrase('dbtech_vbshout_chatroom_settings'), false, 2, 'optiontitle');
		print_membergroup_row($this->app->phrase('dbtech_vbshout_usergroups'), 'chatroom[membergroupids]', 2, 		$chatroom);
		print_select_row($this->app->phrase('dbtech_vbshout_instance'), 		'chatroom[instanceid]', $instances,	$chatroom['instanceid']);
		

		print_submit_row(($chatroomid ? $this->app->phrase('save') : $this->app->phrase('dbtech_vbshout_add_new_chatroom')));
	}

	// #############################################################################
	public function actionUpdate()
	{
		// Init this
		$chatroomCache = $this->cache->get('chatroom');

		$cleanedInput = $this->app->filter([
			'chatroomid' 		=> TYPE_UINT,
			'chatroom' 			=> TYPE_ARRAY,
		]);

		if (!count($cleanedInput['chatroom']['membergroupids']) OR in_array(-1, $cleanedInput['chatroom']['membergroupids']))
		{
			// Ensure only this is checked
			$cleanedInput['chatroom']['membergroupids'] = '-1';
		}

		// init data manager
		$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['chatroomid'])
		{
			if (!$existing = $chatroomCache[$cleanedInput['chatroomid']])
			{
				// Couldn't find the chatroom
				print_stop_message('dbtech_vbshout_invalid_x', $this->app->phrase('dbtech_vbshout_chatroom'), $cleanedInput['chatroomid']);
			}

			// Set existing
			$chatroomDm->setExistingData($existing);

			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$chatroomDm->bulkSet($cleanedInput['chatroom']);

		// Save! Hopefully.
		$chatroomDm->save();

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', [
			'param1' => $this->app->phrase('dbtech_vbshout_chatroom'),
			'param2' => $phrase
		]), $this->app->link('chatroom'));
	}

	// #############################################################################
	public function actionMassUpdate()
	{
		// Init this
		$chatroomCache = $this->cache->get('chatroom');

		$cleanedInput = $this->app->filter([
			'chatroom' => TYPE_ARRAY
		]);

		foreach ($cleanedInput['chatroom'] as $chatroomid => $chatroom)
		{
			if (!$existing = $chatroomCache[$chatroomid])
			{
				// Couldn't find the chatroom
				continue;
			}

			// init data manager
			$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_EXCEPTION);
				$chatroomDm->setExistingData($existing);
				$chatroomDm->bulkSet($chatroom);
			$chatroomDm->save();
			unset($chatroomDm);
		}

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', [
			'param1' => $this->app->phrase('dbtech_vbshout_chatroom'),
			'param2' => $this->app->phrase('dbtech_vbshout_edited')
		]), $this->app->link('chatroom'));
	}

	// #############################################################################
	public function actionDelete()
	{
		$cleanedInput = $this->app->filter([
			'chatroomid' => TYPE_UINT,
		]);

		print_cp_header($this->app->phrase('dbtech_vbshout_delete_x', ['param1' => $this->app->phrase('dbtech_vbshout_chatroom')]));
		print_delete_confirmation('dbtech_vbshout_chatroom', $cleanedInput['chatroomid'], 'vbshout', 'chatroom', 'dbtech_vbshout_chatroom', ['action' => 'kill'], '', 'title');
		print_cp_footer();
	}

	// #############################################################################
	public function actionKill()
	{
		// Init this
		$chatroomCache = $this->cache->get('chatroom');

		$cleanedInput = $this->app->filter([
			'chatroomid' => TYPE_UINT,
			'kill' 		 => TYPE_BOOL
		]);

		if (!$existing = $chatroomCache[$cleanedInput['chatroomid']])
		{
			// Couldn't find the chatroom
			print_stop_message('dbtech_vbshout_invalid_x', $this->app->phrase('dbtech_vbshout_chatroom'), $cleanedInput['chatroomid']);
		}

		// init data manager
		$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_EXCEPTION);
			$chatroomDm->setExistingData($existing);
		$chatroomDm->delete();

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', [
			'param1' => $this->app->phrase('dbtech_vbshout_chatroom'),
			'param2' => $this->app->phrase('dbtech_vbshout_deleted')
		]), $this->app->link('chatroom'));
	}
}
?>