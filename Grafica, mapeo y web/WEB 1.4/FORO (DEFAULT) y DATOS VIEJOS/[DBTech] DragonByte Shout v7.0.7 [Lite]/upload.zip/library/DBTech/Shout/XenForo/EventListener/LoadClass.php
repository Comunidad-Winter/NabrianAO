<?php
class DBTech_Shout_XenForo_EventListener_LoadClass
{
	public static function load($class, array &$extend)
	{
		if (
			file_exists(XenForo_Helper_File::getExternalDataPath() . '/dbtechShoutUpgrade.lock')
			AND !XenForo_Application::debugMode()
		)
		{
			return;
		}

		if (!in_array('DBTech_Shout_' . $class, $extend))
		{
			// As this will only ever be called with an event hint, this is fine
			$extend[] = 'DBTech_Shout_' . $class;
		}

		$extend = array_unique($extend);
	}
}