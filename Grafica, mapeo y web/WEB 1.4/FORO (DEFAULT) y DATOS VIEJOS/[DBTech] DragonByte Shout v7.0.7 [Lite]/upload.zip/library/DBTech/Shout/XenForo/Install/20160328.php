<?php

class DBTech_Shout_XenForo_Install_20160328 extends DBTech_Shout_XenForo_Install
{
	protected function _install()
	{
		$db = XenForo_Application::getDb();

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_button`
				(
					`buttonid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`title` varchar(50) NOT NULL,
					`instanceid` int(10) unsigned NOT NULL DEFAULT '0',
					`active` tinyint(1) unsigned NOT NULL DEFAULT '1',
					`link` mediumblob,
					`image` mediumblob,
					PRIMARY KEY (`buttonid`),
					KEY `instanceid` (`instanceid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_chatroom`
				(
					`chatroomid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`title` varchar(50) NOT NULL,
					`membergroupids` char(250) NOT NULL DEFAULT '',
					`instanceid` int(10) unsigned NOT NULL DEFAULT '0',
					`active` tinyint(1) unsigned NOT NULL DEFAULT '1',
					`creator` int(10) unsigned NOT NULL DEFAULT '1',
					`members` mediumblob,
					PRIMARY KEY (`chatroomid`),
					KEY `instanceid` (`instanceid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_chatroommember`
				(
					`userid` int(10) unsigned NOT NULL,
					`chatroomid` int(10) unsigned NOT NULL,
					`status` tinyint(1) unsigned NOT NULL DEFAULT '0',
					`invitedby` int(10) unsigned NOT NULL DEFAULT '0',
					PRIMARY KEY (`userid`,`chatroomid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_command`
				(
					`commandid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`userid` int(10) unsigned NOT NULL DEFAULT '0',
					`command` varchar(50) NOT NULL DEFAULT '',
					`useinput` tinyint(1) unsigned NOT NULL DEFAULT '0',
					`output` mediumblob,
					PRIMARY KEY (`commandid`),
					KEY `userid` (`userid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_deeplog`
				(
					`deeplogid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`shoutid` int(10) unsigned NOT NULL DEFAULT '0',
					`userid` int(10) NOT NULL DEFAULT '0',
					`username` varchar(100) NOT NULL DEFAULT '',
					`dateline` int(10) unsigned NOT NULL DEFAULT '0',
					`message` mediumblob,
					`type` tinyint(1) unsigned NOT NULL DEFAULT '1',
					`id` int(10) unsigned NOT NULL DEFAULT '0',
					`notification` enum('','thread','reply') NOT NULL DEFAULT '',
					PRIMARY KEY (`deeplogid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_ignorelist`
				(
					`userid` int(10) unsigned NOT NULL,
					`ignoreuserid` int(10) unsigned NOT NULL,
					PRIMARY KEY (`userid`,`ignoreuserid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_instance`
				(
					`instanceid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`name` varchar(50) NOT NULL,
					`description` mediumblob,
					`active` tinyint(1) unsigned NOT NULL DEFAULT '1',
					`autodisplay` tinyint(1) unsigned NOT NULL DEFAULT '0',
					`permissions` mediumblob,
					`sticky` mediumblob,
					`shoutsound` varchar(50) NOT NULL DEFAULT '',
					`invitesound` varchar(50) NOT NULL DEFAULT '',
					`pmsound` varchar(50) NOT NULL DEFAULT '',
					`bbcodepermissions` mediumblob,
					`notices` mediumblob,
					`sticky_raw` mediumblob,
					`varname` varchar(50) NOT NULL DEFAULT '',
					`options` mediumblob,
					`forumids` mediumblob,
					`displayorder` int(10) unsigned NOT NULL DEFAULT '10',
					PRIMARY KEY (`instanceid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				REPLACE INTO `xf_dbtech_vbshout_instance`
					(`instanceid`, `name`, `description`, `active`, `autodisplay`, `permissions`, `sticky`, `shoutsound`, `invitesound`, `pmsound`, `bbcodepermissions`, `notices`, `sticky_raw`, `varname`, `options`, `forumids`, `displayorder`)
				VALUES
					(1, 'Shoutbox', X'54686973206973207468652064656661756C742053686F7574626F782E0D0A596F752063616E206368616E67652074686973206465736372697074696F6E20627920636C69636B696E67205B456469745D2E', 1, 1, X'613A343A7B693A313B693A343B693A323B693A323130383B693A333B693A343039323B693A343B693A333936343B7D', NULL, '', '', '', NULL, NULL, NULL, 'instance1', NULL, NULL, 10)
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_log`
				(
					`logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`userid` int(10) unsigned NOT NULL DEFAULT '0',
					`username` varchar(100) NOT NULL DEFAULT '',
					`dateline` int(10) unsigned NOT NULL DEFAULT '0',
					`ipaddress` char(15) NOT NULL,
					`command` varchar(50) NOT NULL,
					`comment` mediumblob,
					PRIMARY KEY (`logid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_report`
				(
					`reportid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`reportuserid` int(10) unsigned NOT NULL DEFAULT '0',
					`userid` int(10) unsigned NOT NULL DEFAULT '0',
					`shoutid` int(10) unsigned NOT NULL DEFAULT '0',
					`instanceid` int(10) unsigned NOT NULL DEFAULT '0',
					`shout` mediumblob,
					`reportreason` mediumblob,
					`modnotes` mediumblob,
					`handled` tinyint(1) unsigned NOT NULL DEFAULT '0',
					PRIMARY KEY (`reportid`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_session`
				(
					`userid` int(10) unsigned NOT NULL DEFAULT '0',
					`lastactivity` int(10) unsigned NOT NULL DEFAULT '0',
					`instanceid` int(10) unsigned NOT NULL DEFAULT '0',
					`chatroomid` int(10) unsigned NOT NULL DEFAULT '0',
					PRIMARY KEY (`userid`,`instanceid`,`chatroomid`),
					KEY `last_activity` (`lastactivity`) USING BTREE,
					KEY `instance_activity` (`lastactivity`,`instanceid`) USING BTREE,
					KEY `chatroom_activity` (`lastactivity`,`chatroomid`) USING BTREE
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				CREATE TABLE IF NOT EXISTS `xf_dbtech_vbshout_shout`
				(
					`shoutid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`userid` int(10) NOT NULL DEFAULT '0',
					`dateline` int(10) unsigned NOT NULL DEFAULT '0',
					`message` mediumblob,
					`type` int(10) unsigned NOT NULL DEFAULT '1',
					`id` int(10) unsigned NOT NULL DEFAULT '0',
					`notification` enum('','thread','reply') NOT NULL DEFAULT '',
					`forumid` int(10) unsigned NOT NULL DEFAULT '0',
					`chatroomid` int(10) unsigned NOT NULL DEFAULT '0',
					`instanceid` int(10) unsigned NOT NULL DEFAULT '0',
					`message_raw` mediumblob,
					PRIMARY KEY (`shoutid`),
					KEY `type` (`type`,`id`),
					KEY `userid` (`userid`),
					KEY `dateline` (`dateline`)
				) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				REPLACE INTO `xf_dbtech_vbshout_shout`
					(`shoutid`, `userid`, `dateline`, `message`, `type`, `id`, `notification`, `forumid`, `chatroomid`, `instanceid`, `message_raw`)
				VALUES
					(1, -1, UNIX_TIMESTAMP(), X'436F6E67726174756C6174696F6E73206F6E20796F757220696E7374616C6C6174696F6E206F6620447261676F6E4279746520546563683A20764253686F75742120576520686176652074616B656E20746865206C696265727479206F662073657474696E6720736F6D652064656661756C74206F7074696F6E7320666F7220796F752C2062757420796F752073686F756C6420656E746572207468652041646D696E435020616E642066616D696C69617269736520796F757273656C6620776974682074686520766172696F75732073657474696E67732E2055736520746865202F7072756E6520636F6D6D616E6420746F2067657420726964206F662074686973206D6573736167652C206F7220646F75626C652D636C69636B20697420616E6420636C69636B207468652044656C65746520627574746F6E2E20456E6A6F7920796F7572206E65772053686F7574626F7821', 32, 0, '', 0, 0, 1, X'436F6E67726174756C6174696F6E73206F6E20796F757220696E7374616C6C6174696F6E206F6620447261676F6E4279746520546563683A20764253686F75742120576520686176652074616B656E20746865206C696265727479206F662073657474696E6720736F6D652064656661756C74206F7074696F6E7320666F7220796F752C2062757420796F752073686F756C6420656E746572207468652041646D696E435020616E642066616D696C69617269736520796F757273656C6620776974682074686520766172696F75732073657474696E67732E2055736520746865202F7072756E6520636F6D6D616E6420746F2067657420726964206F662074686973206D6573736167652C206F7220646F75626C652D636C69636B20697420616E6420636C69636B207468652044656C65746520627574746F6E2E20456E6A6F7920796F7572206E65772053686F7574626F7821')
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_banned` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_settings` INT(10) UNSIGNED NOT NULL DEFAULT '8191'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_shouts` INT(10) UNSIGNED NOT NULL DEFAULT '0'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_shoutstyle` MEDIUMBLOB
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_silenced` TINYINT(1) UNSIGNED NOT NULL DEFAULT '0'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_shoutarea` VARCHAR(15) NOT NULL DEFAULT 'default'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_pm` INT(10) UNSIGNED NOT NULL DEFAULT '0'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_shoutboxsize` INT(10) UNSIGNED NOT NULL DEFAULT '0'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_shoutboxsize_detached` INT(10) UNSIGNED NOT NULL DEFAULT '0'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_displayorder` MEDIUMBLOB
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_shouts_lifetime` INT(10) UNSIGNED NOT NULL DEFAULT '0'
			");
		}
		catch (Zend_Db_Exception $e) {}

		try
		{
			$db->query("
				ALTER TABLE `xf_user`
					ADD `dbtech_vbshout_invisiblesettings` MEDIUMBLOB
			");
		}
		catch (Zend_Db_Exception $e) {}

	}
}
?>