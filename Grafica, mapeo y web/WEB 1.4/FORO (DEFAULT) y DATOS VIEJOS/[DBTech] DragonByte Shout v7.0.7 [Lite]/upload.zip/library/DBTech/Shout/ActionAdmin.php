<?php
abstract class DBTech_Shout_ActionAdmin extends DBTech_Shout_Action
{
	public function __construct()
	{
		// This is a shorthand for the adminfunctions files
		$GLOBALS['appName'] = 'DBTech_Shout_Core_Admin';

		// Get the instance
		$this->app = $GLOBALS['appName']::getInstance();
		$this->cache = DBTech_Shout_Cache::getInstance();

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				require_once('./library/DBTech/Shout/Application/includes/adminfunctions_xenforo.php');
				break;

			case 'vBulletin':
				require_once('./library/DBTech/Shout/Application/includes/adminfunctions_vbulletin.php');
				break;
		}
	}
}
?>