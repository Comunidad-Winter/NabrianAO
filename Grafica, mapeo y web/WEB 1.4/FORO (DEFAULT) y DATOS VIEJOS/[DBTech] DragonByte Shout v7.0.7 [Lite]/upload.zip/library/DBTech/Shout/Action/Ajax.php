<?php
class DBTech_Shout_Action_Ajax extends DBTech_Shout_Action
{
	protected $shoutbox;

	public function __construct()
	{
		// Do normal construct
		parent::__construct();

		// Get the instance
		$this->shoutbox = DBTech_Shout_Shoutbox::getInstance();
	}

	public function actionIndex()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');
		$chatroomCache = $this->cache->get('chatroom');

		// Fetch the list of users
		$cleanedInput = $this->app->filter(array(
			'instanceid' 	=> TYPE_UINT,
			'chatroomid' 	=> TYPE_UINT,
			'detached' 		=> TYPE_BOOL,
			'shoutid' 		=> TYPE_UINT,
			'type' 			=> TYPE_NOHTML
		));

		if (!isset($instanceCache[$cleanedInput['instanceid']]) OR !$instance = $instanceCache[$cleanedInput['instanceid']])
		{
			// Wrong instance
			$this->shoutbox->fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			$this->outputXml($this->shoutbox->fetched);
		}

		if (!$instance['active'])
		{
			// Inactive instance
			$this->shoutbox->fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			$this->outputXml($this->shoutbox->fetched);
		}

		if ($this->app->getUserInfo('dbtech_vbshout_banned'))
		{
			// Banz!
			$this->shoutbox->fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			$this->outputXml($this->shoutbox->fetched);
		}

		if (!$instance['permissions_parsed']['canviewshoutbox'])
		{
			// Can't view this instance
			$this->shoutbox->fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			$this->outputXml($this->shoutbox->fetched);
		}

		if ((int)$this->app->getUserInfo($this->_getDb()->lookup('user', 'posts')) < $instance['options']['minposts'] AND !$this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
		{
			// Too few posts
			$this->shoutbox->fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			$this->outputXml($this->shoutbox->fetched);
		}

		// Do posts per day
		$jointime = ($this->app->getTime() - $this->app->getUserInfo($this->_getDb()->lookup('user', 'joindate'))) / 86400;
		$postsperday = ($jointime <= 1 ? $this->app->getUserInfo($this->_getDb()->lookup('user', 'posts')) : round($this->app->getUserInfo($this->_getDb()->lookup('user', 'posts')) / $jointime, 2));

		if ((int)$postsperday < $instance['options']['minpostsperday'] AND !$this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
		{
			// Too few posts
			$this->shoutbox->fetched['error'] = 'Invalid Instance: ' . $cleanedInput['instanceid'];

			// Prints the XML for reading by the AJAX script
			$this->outputXml($this->shoutbox->fetched);
		}

		// Set this
		$tmp = explode('_', get_class($this));

		// Strip non-valid characters
		$do = strtolower(preg_replace('/[^\w-]/i', '', array_pop($tmp)));

		// Any additional arguments we may be having to the fetching of shouts
		$args['instanceid'] = $cleanedInput['instanceid'];

		// Fetch the list of users
		if ($cleanedInput['chatroomid'])
		{
			// Check if the chatroom is active
			$chatroomid = $cleanedInput['chatroomid'];

			if (
				!isset($chatroomCache[$chatroomid])
				OR !$chatroom = $chatroomCache[$chatroomid]
			)
			{
				// Default value
				$chatroom = [];
			}
			else
			{
				$userid = $this->app->getUserInfo('userid');

				if (
					$do != 'joinchat'
					AND (
						!$chatroom['active']
						OR (
							(
								!$chatroom['membergroupids']
								OR !$chatroom['autojoin']
							)
							AND !isset($chatroom['members'][$userid])
						)
						OR (
							$chatroom['membergroupids']
							AND $chatroom['membergroupids'] != '-1'
							AND !$this->app->isMemberOf($this->app->getUserInfo(), explode(',', $chatroom['membergroupids']))
						)
					)
				)
				{
					// Wrong chatroom
					$this->shoutbox->leaveChatroom($chatroom, $this->app->getUserInfo('userid'));
					$this->shoutbox->fetched['error'] = 'disband_' . $chatroomid;
				}
			}
		}
		else
		{
			// Default value
			$chatroom = [];
		}

		

		if (isset($this->shoutbox->fetched['error']) AND $this->shoutbox->fetched['error'])
		{
			// We had errors, don't bother

			// Prints the XML for reading by the AJAX script
			$this->outputXml($this->shoutbox->fetched);
		}

		// Run the action
		$this->__handle($instance, $chatroom, $args);

		if (isset($this->shoutbox->fetched['error']) AND !$this->shoutbox->fetched['error'])
		{
			// Bugfix
			unset($this->shoutbox->fetched['error']);
		}

		// Prints the XML for reading by the AJAX script
		$this->outputXml($this->shoutbox->fetched);
	}

	/**
	* Outputs an XML string to the browser
	*
	* @param	mixed	array to output
	*/
	public function outputXml($arr)
	{
		$document = new DOMDocument('1.0', 'utf-8');
		$document->formatOutput = true;

		$rootNode = $document->createElement('vbshout');

		foreach (array(
			'aoptimes',
			'chatrooms',
			'shouts',
		) as $key)
		{
			if (!isset($this->shoutbox->fetched[$key]) OR !is_array($this->shoutbox->fetched[$key]))
			{
				// Skip this
				continue;
			}

			// Array values
			$node = $document->createElement($key);
			foreach ($this->shoutbox->fetched[$key] as $key2 => $arr)
			{
				$node2 = $document->createElement(substr($key, 0, -1));
				foreach ($arr as $key3 => $val)
				{
					$node3 = $document->createElement($key3);
						$node3->appendChild($document->createCDATASection($val));
					$node2->appendChild($node3);
				}
				$node->appendChild($node2);
			}
			$rootNode->appendChild($node);
		}

		foreach (array(
			'ajax',
			'activereports',
			'content',
			'editor',
			'error',
			'menucode',
			'pmtime',
			'pmuserid',
			'sticky',
		) as $key)
		{
			if (!isset($this->shoutbox->fetched[$key]))
			{
				continue;
			}

			// Singular values
			$node = $document->createElement($key);
				$node->appendChild($document->createCDATASection($this->shoutbox->fetched[$key]));
			$rootNode->appendChild($node);
		}

		if (isset($this->shoutbox->fetched['activeusers']['usernames']))
		{
			// Create the attribute
			$attribute = $document->createAttribute('count');
			$attribute->value = $this->shoutbox->fetched['activeusers']['count'];

			// Singular values
			$node = $document->createElement('activeusers');
				$node->appendChild($document->createCDATASection($this->shoutbox->fetched['activeusers']['usernames']));
				$node->appendChild($attribute);
			$rootNode->appendChild($node);
		}

		if (isset($this->shoutbox->fetched['chatroom']))
		{
			// Create the attribute
			$attribute = $document->createAttribute('chatroomid');
			$attribute->value = $this->shoutbox->fetched['chatroom']['chatroomid'];

			// Singular values
			$node = $document->createElement('chatroom');
				$node->appendChild($document->createCDATASection($this->shoutbox->fetched['chatroom']['title']));
				$node->appendChild($attribute);
			$rootNode->appendChild($node);
		}

		$document->appendChild($rootNode);

		header("Content-Type: application/xml; charset=UTF-8");
		echo $document->saveXML();
		die();
	}
}