<?php
/**
* Constructs a row containing a list of <input type="checkbox" />
*
* @param	string	Name for checkbox
* @param	array	Values to use
* @param	boolean	Whether or not to check the box
* @param	boolean	Whether or not to htmlspecialchars the title
*/
function construct_checkbox_array_row($name, $array, array $selected = array(), $htmlise = false)
{
	if (function_exists('fetch_uniqueid_counter'))
	{
		$uniqueid = fetch_uniqueid_counter();
	}

	if (!is_array($array))
	{
		$array = array();
		$selected = array();
	}

	$check = "<div id=\"ctrl_$name\">\n";
	$check .= construct_checkbox_options($name, $array, $selected, $htmlise);
	$check .= "</div>\n";

	return $check;
}

/**
* Prints a row containing a list of <input type="checkbox" />
*
* @param	string	Title for row
* @param	string	Name for checkbox
* @param	array	Values to use
* @param	boolean	Whether or not to check the box
* @param	boolean	Whether or not to htmlspecialchars the title
*/
function print_checkbox_array_row($title, $name, $array, array $selected = array(), $htmlise = false)
{
	print_label_row($title, construct_checkbox_array_row($name, $array, $selected, $htmlise), '', 'top', $name);
}

/**
* Creates <input type="checkbox" /> from an array (array of checked boxes)
*
* @param	string	Name for checkbox
* @param	array	Values to use
* @param	array	The checked value(s)
* @param	boolean	Whether to htmlise the output
*/
function construct_checkbox_options($name, $array, array $selected = array(), $htmlise = false)
{
	$box = '';

	foreach ($array as $value => $title)
	{
		if (function_exists('fetch_uniqueid_counter'))
		{
			$uniqueid = fetch_uniqueid_counter();
		}

		$checked = in_array($value, $selected);
		$box .= "<div id=\"ctrl_$name_$value\"><label class=\"smallfont\">" . construct_checkbox_code($name, $checked, $title, false, $value) . ($htmlise ? htmlspecialchars_uni($title) : $title) . "</label></div>\n";
		if ($checked)
		{
			construct_hidden_code('set_' . str_replace('[]', '[' . $value . ']', $name), $value);
		}
	}

	return $box;
}

/**
* Creates <input type="checkbox" /> from an array (bitfield of checked boxes)
*
* @param	string	Name for checkbox
* @param	array	Values to use
* @param	integer	The bitfield value
* @param	boolean	Whether to htmlise the output
*/
function construct_checkbox_bitfield_options($name, $array, $bitfield, $htmlise = false)
{
	$box = '';
	construct_hidden_code($name, 0);

	foreach ($array as $value => $title)
	{
		if (function_exists('fetch_uniqueid_counter'))
		{
			$uniqueid = fetch_uniqueid_counter();
		}

		$checked = ($bitfield & $value);
		$box .= "<div id=\"ctrl_$name_$value\"><label class=\"smallfont\">" . construct_checkbox_code($name, $checked, $title, false, $value, '', false) . ($htmlise ? htmlspecialchars_uni($title) : $title) . "</label></div>\n";
		if ($checked)
		{
			construct_hidden_code('set_' . str_replace('[]', '[' . $value . ']', $name), $value);
		}
	}

	return $box;
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function print_spinbox_row($title, $name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	print_input_row($title, $name, $value, $htmlise, $size, $maxlength, $direction, $inputclass, $inputid, $extra);
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
*/
function print_title_row($title, $name, $value = '', $titlePhrase = '', $htmlise = true, $size = 35, $maxlength = 0)
{
	print_input_row($title, $name, $value, $htmlise, $size, $maxlength);
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Title for row
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function print_username_row($title, $name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	print_input_row($title, $name, $value, $htmlise, $size, $maxlength, $direction, $inputclass, $inputid, $extra);
}

/**
 * Constructs a bitfield row
 *
 * @param	string	The label text
 * @param	string	The name of the row for the form
 * @param	string	What bitfields we are using
 * @param	integer	The value of the setting
 */
function print_bitfield_row($text, $name, $bitfield, $value)
{
	require_once(DIR . '/includes/adminfunctions.php');
	require_once(DIR . '/includes/adminfunctions_options.php');

	// make sure all rows use the alt1 class
	$bgcounter--;

	$value = intval($value);
	$HTML = '';
	$bitfielddefs =& fetch_bitfield_definitions($bitfield);

	if ($bitfielddefs === NULL)
	{
		print_label_row($text, construct_phrase("<strong>{$GLOBALS['vbphrase']['settings_bitfield_error']}</strong>", implode(',', vB_Bitfield_Builder::fetch_errors())), '', 'top', $name, 40);
	}
	else
	{
		#$HTML .= "<fieldset><legend>{$GLOBALS['vbphrase']['yes']} / {$GLOBALS['vbphrase']['no']}</legend>";
		$HTML .= "<div id=\"ctrl_{$name}\" class=\"smallfont\">\r\n";
		foreach ($bitfielddefs AS $key => $val)
		{
			$val = intval($val);
			$HTML .= "<table style=\"width:175px; float:left\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr valign=\"top\">
			<td>" . construct_checkbox_code($name . "[$val]", ($value & $val), "name=&quot;{$name}[$val]&quot; value=&quot;$val&quot;", false, $val) . "</td>
			<td width=\"100%\" style=\"padding-top:4px\"><label for=\"{$name}_$key\" class=\"smallfont\">" . fetch_phrase_from_key($key) . "</label></td>\r\n</tr></table>\r\n";
		}

		$HTML .= "</div>\r\n";
		#$HTML .= "</fieldset>";
		print_label_row($text, $HTML, '', 'top', $name, 40);
	}
}

/**
 * Prints a table row but not from a bitfield.
 *
 * @param	string	The label text
 * @param	string	The name of the row for the form
 * @param	string	What bitfields we are using
 * @param	integer	The value of the setting
 */
function print_table_row($text, $name, $array, $value)
{
	// make sure all rows use the alt1 class
	$bgcounter--;

	$value = intval($value);
	$HTML = '';

	#$HTML .= "<fieldset><legend>{$GLOBALS['vbphrase']['yes']} / {$GLOBALS['vbphrase']['no']}</legend>";
	$HTML .= "<div id=\"ctrl_{$name}\" class=\"smallfont\">\r\n";
	foreach ($array AS $key => $val)
	{
		$bit = intval($val['bitfield']);
		$HTML .= "<table style=\"width:175px; float:left\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr valign=\"top\">
		<td>" . construct_checkbox_code($name . "[$bit]", ($value & (int)$bit), "name=&quot;{$name}[$bit]&quot; value=&quot;$bit&quot;", false, $bit) . "</td>
		<td width=\"100%\" style=\"padding-top:4px\"><label for=\"{$name}_$key\" class=\"smallfont\">" . $val['title'] . "</label></td>\r\n</tr></table>\r\n";
	}

	$HTML .= "</div>\r\n";
	#$HTML .= "</fieldset>";
	print_label_row($text, $HTML, '', 'top', $name, 40);
}

/**
 * [construct_checkbox_code description]
 * @param  [type]  $name          [description]
 * @param  [type]  $checked       [description]
 * @param  [type]  $title         [description]
 * @param  boolean $disabled      [description]
 * @param  integer $value         [description]
 * @param  string  $onclick       [description]
 * @param  boolean $includeHidden [description]
 * @return [type]                 [description]
 */
function construct_checkbox_code($name, $checked, $title, $disabled = false, $value = 1, $onclick = '', $includeHidden = true)
{
	return ($includeHidden ? "<input type=\"hidden\" name=\"$name\" value=\"0\" />" : '') . "<input type=\"checkbox\" name=\"$name\" tabindex=\"1\" value=\"$value\"" . ($onclick ? " onclick=\"$onclick\"" : '') . ($GLOBALS['vbulletin']->debug ? " title=\"name=&quot;{$name}&quot;\"" : '') . ($checked ? ' checked="checked"' : '') . ($disabled ? ' disabled="disabled"' : '') . ' />';
}

/**
 * [construct_select_code description]
 * @param  [type]  $name     [description]
 * @param  [type]  $array    [description]
 * @param  string  $selected [description]
 * @param  boolean $htmlise  [description]
 * @param  integer $size     [description]
 * @param  boolean $multiple [description]
 * @return [type]            [description]
 */
function construct_select_code($name, $array, $selected = '', $htmlise = false, $size = 0, $multiple = false)
{
	$uniqueid = fetch_uniqueid_counter();

	$select = "<select name=\"$name\" id=\"sel_{$name}_$uniqueid\" tabindex=\"1\" class=\"bginput\"" . ($size ? " size=\"$size\"" : '') . ($multiple ? ' multiple="multiple"' : '') . ($GLOBALS['vbulletin']->debug ? " title=\"name=&quot;$name&quot;\"" : '') . ">\n";
	$select .= construct_select_options($array, $selected, $htmlise);
	$select .= "</select>\n";

	return $select;
}

/**
* Prints a row containing an <input type="text" />
*
* @param	string	Name for input field
* @param	string	Value for input field
* @param	boolean	Whether or not to htmlspecialchars the input field value
* @param	integer	Size for input field
* @param	integer	Max length for input field
* @param	string	Text direction for input field
* @param	mixed	If specified, overrides the default CSS class for the input field
*/
function construct_input_row($name, $value = '', $htmlise = true, $size = 35, $maxlength = 0, $direction = '', $inputclass = false, $inputid = false, $extra = '')
{
	$direction = verify_text_direction($direction);

	if($inputid===false)
	{
		$id = 'it_' . $name . '_' . fetch_uniqueid_counter();
	}
	else
	{
		$id = $inputid;
	}

	return "<input type=\"text\" class=\"" . ($inputclass ? $inputclass : 'bginput') . "\" name=\"$name\" id=\"$id\" value=\"" . ($htmlise ? htmlspecialchars_uni($value) : $value) . "\" size=\"$size\"" . ($maxlength ? " maxlength=\"$maxlength\"" : '') . " dir=\"$direction\" tabindex=\"1\"" . ($GLOBALS['vbulletin']->debug ? " title=\"name=&quot;$name&quot;\"" : '') . " />$extra";
}

/**
* Prints a column-spanning row containing arbitrary HTML
*
* @param	string	HTML contents for row
* @param	integer	Number of columns to span
*/
function print_notice_row($text, $colspan = 2)
{
	print_description_row($text, false, $colspan);
}

if (!function_exists('print_confirmation'))
{
/**
* Prints a dialog box asking if the user if they want to continue
*
* @param	string	Phrase that is presented to the user
* @param	string	PHP script to which the form will submit
* @param	string	'do' action for target script
* @param	mixed		If not empty, an array containing name=>value pairs to be used as hidden input fields
*/
function print_confirmation($phrase, $phpscript, $do, $hiddenfields = array())
{
	global $vbulletin, $vbphrase;

	echo "<p>&nbsp;</p><p>&nbsp;</p>";
	print_form_header($phpscript, $do, 0, 1, '', '75%');
	if (is_array($hiddenfields))
	{
		foreach($hiddenfields AS $varname => $value)
		{
			construct_hidden_code($varname, $value);
		}
	}
	print_table_header($vbphrase['confirm_action']);
	print_description_row("
		<blockquote><br />
		$phrase
		<br /></blockquote>\n\t");
	print_submit_row($vbphrase['yes'], 0, 2, $vbphrase['no']);
}
}

/**
 * [print_page_nav description]
 * @param  [type] $perPage    [description]
 * @param  [type] $totalItems [description]
 * @param  [type] $page       [description]
 * @param  [type] $linkType   [description]
 * @param  [type] $linkData   [description]
 * @param  array  $linkParams [description]
 * @param  array  $options    [description]
 * @return [type]             [description]
 */
function print_page_nav($perPage, $totalItems, $page, $linkType,
	$linkData = null, array $linkParams = array(), array $options = array()
)
{
	if (isset($linkParams['_params']) && is_array($linkParams['_params']))
	{
		$tempParams = $linkParams['_params'];
		unset($linkParams['_params']);
		$linkParams = array_merge($tempParams, $linkParams);
	}

	$linkParams = array_merge($linkParams, [
		'perpage' 	=> $perPage,
	]);

	$totalPages = ceil($totalItems / $perPage);

	$firstpage = $prevpage = $nextpage = $lastpage = '';
	if ($page != 1)
	{
		$linkParamsTmp = $linkParams;
		$linkParamsTmp['page'] = 1;
		$firstpage = construct_button_code("&laquo; " . $GLOBALS['vbphrase']['dbtech_vbshout_first_page'], 'vbshout.php' . ($linkData['do'] ? ('?do=' . $linkData['do']) : '') . ($linkParamsTmp ? ($linkData['do'] ? '&' : '?') . http_build_query($linkParamsTmp) : ''));

		$linkParamsTmp = $linkParams;
		$linkParamsTmp['page'] = ($page - 1);
		$prevpage = construct_button_code("&lt; " . $GLOBALS['vbphrase']['dbtech_vbshout_prev_page'], 'vbshout.php' . ($linkData['do'] ? ('?do=' . $linkData['do']) : '') . ($linkParamsTmp ? ($linkData['do'] ? '&' : '?') . http_build_query($linkParamsTmp) : ''));
	}

	if ($page != $totalPages)
	{
		$linkParamsTmp = $linkParams;
		$linkParamsTmp['page'] = ($page + 1);
		$nextpage = construct_button_code($GLOBALS['vbphrase']['dbtech_vbshout_next_page'] . " &gt;", 'vbshout.php' . ($linkData['do'] ? ('?do=' . $linkData['do']) : '') . ($linkParamsTmp ? ($linkData['do'] ? '&' : '?') . http_build_query($linkParamsTmp) : ''));

		$linkParamsTmp = $linkParams;
		$linkParamsTmp['page'] = $totalPages;
		$lastpage = construct_button_code($GLOBALS['vbphrase']['dbtech_vbshout_last_page'] . " &raquo;", 'vbshout.php' . ($linkData['do'] ? ('?do=' . $linkData['do']) : '') . ($linkParamsTmp ? ($linkData['do'] ? '&' : '?') . http_build_query($linkParamsTmp) : ''));
	}

	print_table_footer($options['headerCount'], "$firstpage $prevpage &nbsp; $nextpage $lastpage");
}