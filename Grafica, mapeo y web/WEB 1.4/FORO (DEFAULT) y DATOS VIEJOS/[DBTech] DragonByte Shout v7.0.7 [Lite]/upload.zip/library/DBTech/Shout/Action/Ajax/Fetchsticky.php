<?php
class DBTech_Shout_Action_Ajax_Fetchsticky extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 4))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		// Fetch sticky
		$this->shoutbox->fetched['editor'] = '/sticky ' . $instance['sticky_raw'];
	}
}