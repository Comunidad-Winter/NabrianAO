<?php
class DBTech_Shout_Action_Ajax_Savesettings extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 64))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter(array(
			'settings' => TYPE_ARRAY,
		));

		$settingBits = array_merge(
			$this->app->fetchBitfield('nocache|dbtech_vbshout_general_settings'),
			$this->app->fetchBitfield('nocache|dbtech_vbshout_editor_settings')
		);

		// Default DB value
		$this->app->setUserInfo('dbtech_vbshout_settings', 0);

		
		foreach ($settingBits as $settingname => $bit)
		{
			$settingNameShort = substr($settingname, strlen('dbtech_vbshout_'));
			if (in_array($settingNameShort, [
				'enabledesktop'
			]))
			{
				// Take the true value from this
				continue;
			}

			// These are
			$cleanedInput['settings'][$settingNameShort] = (!in_array($settingNameShort, array(
				'hidealtcolours',
				'hideavatars',
				'enableoverride',
				'disableshoutbox'
			)) ? 1 : 0);
		}
		
		$settings = 0;
		foreach ($cleanedInput['settings'] as $key => $onOff)
		{
			if (!isset($settingBits['dbtech_vbshout_' . $key]))
			{
				// Skip this
				continue;
			}

			if ($onOff)
			{
				$settings += $settingBits['dbtech_vbshout_' . $key];
			}
		}

		// Default DB value
		$this->app->setUserInfo('dbtech_vbshout_settings', $settings);

		// Update the user's editor styles
		$this->_getDb()->update('user', array(
			'dbtech_vbshout_settings' => intval($settings)
		), '=user:userid= = ' . intval($this->app->getUserInfo('userid')));
	}
}