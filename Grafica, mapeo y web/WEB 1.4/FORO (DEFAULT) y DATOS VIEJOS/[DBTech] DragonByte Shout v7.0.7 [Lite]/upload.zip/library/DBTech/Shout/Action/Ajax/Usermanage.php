<?php
class DBTech_Shout_Action_Ajax_Usermanage extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 256))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter(array(
			'manageaction' 	=> TYPE_STR,
			'userid' 		=> TYPE_UINT,
			'type' 			=> TYPE_STR,
		));

		// Grab the username
		if (!$exists = $this->_getDb()->fetchRow('
			SELECT *
			FROM $user
			WHERE =user:userid= = ?
		', array(
			$cleanedInput['userid']
		)))
		{
			// User didn't exist
			return false;
		}

		// Begin shout info
		$shoutInfo = array();

		if ($instance)
		{
			// We are in an instance
			$shoutInfo['instanceid'] = $instance['instanceid'];
		}

		if ($chatroom)
		{
			// We are in a chatroom
			$shoutInfo['chatroomid'] = $chatroom['chatroomid'];
		}

		$skip = false;
		switch ($cleanedInput['manageaction'])
		{
			case 'ignoreunignore':
				$isignored = $this->_getDb()->fetchRow('
					SELECT userid
					FROM $dbtech_vbshout_ignorelist
					WHERE userid = ?
						AND ignoreuserid = ?
				', array(
					$this->app->getUserInfo('userid'),
					$cleanedInput['userid']
				));
				$shoutInfo['message'] = ($isignored ? '/unignore ' : '/ignore ') . $exists['username'];
				break;

			case 'chatremove':
				// Remove an user from chat

				// Leave the chat room
				$this->shoutbox->leaveChatroom($chatroom, $cleanedInput['userid']);

				$shoutInfo['message'] = $this->app->phrase('dbtech_vbshout_x_removed_successfully', array('param1' => $exists['username']));
				$shoutInfo['userid'] = -1;
				$shoutInfo['type'] = $this->shoutbox->shouttypes['system'];
				break;

			

			default:
				$skip = true;
				break;
		}

		if (!$skip)
		{
			// Init the Shout DM
			$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
				$shoutDm->setInfo('instance', $instance);
				$shoutDm->bulkSet($shoutInfo);
			$shoutDm->save();

			if (isset($this->shoutbox->fetched['error']) AND $this->shoutbox->fetched['error'])
			{
				// We haz error
				return false;
			}

			// Update the AOP
			$this->shoutbox->setAop('shouts', $instance['instanceid'], false, true);

			// Shout fetching args
			$args = array();
			if ($cleanedInput['type'] == 'pm')
			{
				// Fetch only PMs
				$args['types'] 		= $this->shoutbox->shouttypes['pm'];
				$args['onlyuser'] 	= $cleanedInput['userid'];
			}

			if ($chatroom)
			{
				// Fetch only from this chatroom
				$args['chatroomid'] = $chatroom['chatroomid'];
			}

			// We want to fetch shouts
			$this->shoutbox->fetchShouts($instance, $chatroom, $args);
		}
		unset($shout);
	}
}