<?php
class DBTech_Shout_Application_Template
{
	protected static $_instance;

	protected $viewRenderer = NULL;
	protected $viewClass = NULL;
	protected $baseViewClass = NULL;
	protected $hasPreRendered = false;
	protected $HTML = [];
	protected $params = [];
	protected $helpers = [];

	protected $app = null;


	public function __construct()
	{
		$this->app = DBTech_Shout_Application_Core::getInstance();

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				// Shorthand
				$db = XenForo_Application::getDb();

				// Set a few required things
				XenForo_Template_Public::setStyleId($this->app->getUserInfo('style_id') ? $this->app->getUserInfo('style_id') : $this->app->option('defaultStyleId'));
				XenForo_Template_Public::setLanguageId($this->app->getUserInfo('language_id') ? $this->app->getUserInfo('language_id') : $this->app->option('defaultLanguageId'));

				$templates = $db->fetchCol('
					SELECT title
					FROM xf_template
					WHERE style_id = 0
						AND addon_id = ?
				', [
					'dbtech_vbshout'
				]);
				foreach ($templates as $template)
				{
					// Cache this
					XenForo_Template_Public::preloadTemplate($template);
				}

				// Shorthand
				$dependencies = XenForo_Application::get('fc')->getDependencies();

				// Get view class
				$this->baseViewClass = $dependencies->getBaseViewClassName();
				$class = 'DBTech_Shout_XenForo_View' . (($dependencies instanceof XenForo_Dependencies_Public) ? 'Public' : 'Admin') . '_TemplateRender';

				$this->viewClass = XenForo_Application::resolveDynamicClass($class, 'view', $this->baseViewClass);
				if (!$this->viewClass)
				{
					$this->viewClass = $this->baseViewClass;
				}

				$this->viewRenderer = $dependencies->getViewRenderer(XenForo_Application::get('fc')->getResponse(), 'Html', XenForo_Application::get('fc')->getRequest());
				break;
		}
	}


	public function renderTemplate($templateName, array $params = array())
	{
		$params = array_merge($this->getParams($templateName), $params);

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$this->preRenderView();

				$view = new $this->viewClass($this->viewRenderer, XenForo_Application::get('fc')->getResponse(), $params, $templateName);
				if (!$view instanceof $this->baseViewClass)
				{
					throw new XenForo_Exception('View must be a child of ' . $this->baseViewClass);
				}
				$view->prepareParams();

				return $view->createOwnTemplateObject()->render();
				break;

			case 'vBulletin':
				if (intval($GLOBALS['vbulletin']->versionnumber) == 3)
				{
					global $navbits, $show, $template_hook, $ad_location, $headinclude;
					global $includecss, $pagetitle, $pagedescription;

					global $header, $footer, $forumjump, $timezone, $gobutton;
					global $vbulletin, $vbphrase, $stylevar, $template_hook;
					global $pmbox, $ad_location, $notifications_menubits, $notifications_total;
					global $vboptions, $bbuserinfo, $session;

					// Extract all our variables
					extract($params);

					// Eval the template
					eval('$__retval = "' . fetch_template($templateName) . '";');

					// Return the correct value
					return $__retval;
				}
				else
				{
					// Finish the main template
					$templater = vB_Template::create($templateName);
					foreach ($params as $param => $val)
					{
						$templater->register($param, $val);
					}
					return $templater->render();
				}
				break;
		}
	}

	public function renderOutput($innerContent, array $params = array(), $selectedTabId = 'forums', $renderContainer = true, $containerTemplate = 'dbtech_vbshout')
	{
		$params = array_merge($this->getParams('output'), $params);

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				// Set selected tab
				$params['majorSection'] = $selectedTabId;

				$this->preRenderView();
				$viewRenderer = XenForo_Application::get('fc')->getDependencies()->getViewRenderer(XenForo_Application::get('fc')->getResponse(), 'Html', XenForo_Application::get('fc')->getRequest());
				$containerParams = XenForo_Application::get('fc')->getDependencies()->getEffectiveContainerParams($params, XenForo_Application::get('fc')->getRequest());

				if (isset($containerParams['adminNavigation']))
				{
					$addonModel = XenForo_Model::create('XenForo_Model_AddOn');
					$bridge = $addonModel->getAddOnById('dbtech_integration');

					$containerParams['adminNavigation']['breadCrumb'][(($bridge AND !$addonModel->isAddOnDisabled($bridge)) ? 'dbtech' : 'applications')] = [
						'link' => (($bridge AND !$addonModel->isAddOnDisabled($bridge)) ? 'dbtech' : 'applications'),
						'title' => (($bridge AND !$addonModel->isAddOnDisabled($bridge)) ? 'DragonByte Tech' : $this->app->phrase('applications'))
					];
					$containerParams['adminNavigation']['breadCrumb'][] = [
						'link' => '',
						'title' => $this->app->phrase('dbtech_vbshout_vbshout_long')
					];

					if ($breadCrumb = $this->getParams('_adminNavigation') AND is_array($breadCrumb))
					{
						// Add the breadcrumbs
						$containerParams['adminNavigation']['breadCrumb'] = array_merge($containerParams['adminNavigation']['breadCrumb'], $breadCrumb);
					}
				}

				// Now render the container
				$content = $renderContainer ? $viewRenderer->renderContainer($innerContent, $containerParams) : $innerContent;

				$bufferedContents = ob_get_contents();
				@ob_end_clean();
				if ($bufferedContents !== '' && is_string($content))
				{
					if (preg_match('#<body[^>]*>#sU', $content, $match))
					{
						$content = str_replace($match[0], $match[0] . $bufferedContents, $content);
					}
					else
					{
						$content = $bufferedContents . $content;
					}
				}

				$headers = XenForo_Application::get('fc')->getResponse()->getHeaders();
				$isText = false;
				foreach ($headers AS $header)
				{
					if ($header['name'] == 'Content-Type')
					{
						if (strpos($header['value'], 'text/') === 0)
						{
							$isText = true;
						}
						break;
					}
				}
				if ($isText && is_string($content) && $content)
				{
					$extraHeaders = XenForo_Application::gzipContentIfSupported($content);
					foreach ($extraHeaders AS $extraHeader)
					{
						XenForo_Application::get('fc')->getResponse()->setHeader($extraHeader[0], $extraHeader[1], $extraHeader[2]);
					}
				}

				if (is_string($content) && $content && !ob_get_level() && XenForo_Application::get('config')->enableContentLength)
				{
					if (XenForo_Application::get('fc')->getResponse()->getHttpResponseCode() >= 400
						&& strpos(XenForo_Application::get('fc')->getRequest()->getServer('HTTP_USER_AGENT', ''), 'IEMobile') !== false
					)
					{
						// Windows mobile bug - 400+ errors cause the standard browser error
						// to be output if a content length is sent. ...Err, what?
					}
					else
					{
						XenForo_Application::get('fc')->getResponse()->setHeader('Content-Length', strlen($content), true);
					}
				}

				XenForo_Application::get('fc')->getResponse()->sendHeaders();

				echo $content;

				if (!$renderContainer)
				{
					// Make sure we're done here
					die();
				}
				break;

			case 'vBulletin':

				if (!$renderContainer)
				{
					// We don't want the container
					print_output($innerContent);
					die();
				}

				global $navbits, $show, $template_hook, $ad_location, $headinclude;
				global $includecss, $pagetitle, $pagedescription;

				$year = date('Y');
				$jQueryPath = $this->app->jQueryPath();
				$version = '7.0.7';
				$versionnumber = '707';
				$HTML = $innerContent;

				if (intval($GLOBALS['vbulletin']->versionnumber) == 3)
				{
					global $header, $footer, $forumjump, $timezone, $gobutton;
					global $vbulletin, $vbphrase, $stylevar, $template_hook;
					global $pmbox, $ad_location, $notifications_menubits, $notifications_total;
					global $vboptions, $bbuserinfo, $session;

					extract($params);

					// Create navbits
					$navbits = construct_navbits($navbits);
					eval('$navbar = "' . fetch_template('navbar') . '";');
					eval('print_output("' . fetch_template($containerTemplate) . '");');
					die();
				}
				else
				{
					$navbar = render_navbar_template(construct_navbits($navbits));

					// Show branding or not
					$show['dbtech_vbshout_producttype'] = ($isPro ? ' (Pro)' : ' (Lite)');

					// Finish the main template
					$templater = vB_Template::create($containerTemplate);
						$templater->register_page_templates();
						$templater->register('navclass', 		$navclass);
						$templater->register('HTML', 			$HTML);
						$templater->register('navbar', 			$navbar);
						$templater->register('pagetitle', 		$pagetitle);
						$templater->register('pagedescription', $pagedescription);
						$templater->register('template_hook', 	$template_hook);
						$templater->register('includecss', 		$includecss);
						$templater->register('year',			$year);
						$templater->register('jQueryPath',		$jQueryPath);
						$templater->register('version',			$version);
						$templater->register('versionnumber', 	$versionnumber);
						$templater->register('headinclude', 	$headinclude);
					foreach ($params as $key => $val)
					{
						$templater->register($key, 				$val);
					}
					print_output($templater->render());
				}
				break;
		}

		exit;
	}

	public function setParam($templateName, $key, $value)
	{
		if (!isset($this->params[$templateName]))
		{
			// Make sure this is an array
			$this->params[$templateName] = [];
		}

		// Now set the template param
		$this->params[$templateName][$key] = $value;
	}

	public function getParams($templateName, $key = NULL)
	{
		// Return either a single template param, or all of them belonging to a certain template
		return $key !== NULL ? (
			isset($this->params[$templateName][$key]) ? $this->params[$templateName][$key] : ''
		) : (
			isset($this->params[$templateName]) ? $this->params[$templateName] : []
		);
	}

	public function setOutput($HTML, $buffer = '_', $overwrite = false)
	{
		// Now set the template param
		if (!isset($this->HTML[$buffer]))
		{
			// Init this
			$this->HTML[$buffer] = '';
		}

		$this->HTML[$buffer] = $overwrite ? $HTML : ($this->HTML[$buffer] . $HTML);
	}

	public function setHelper($helper, $class)
	{
		$this->helpers[$helper] = $class;
	}

	public function getHelper($helper)
	{
		return isset($this->helpers[$helper]) ? $this->helpers[$helper] : new stdClass();
	}

	public function getOutput($buffer = null)
	{
		// Return either a single template param, or all of them belonging to a certain template
		return $buffer === NULL ? implode('', $this->HTML) : (isset($this->HTML[$buffer]) ? $this->HTML[$buffer] : '');
	}

	protected function preRenderView()
	{
		if (!$this->hasPreRendered)
		{
			XenForo_Application::get('fc')->getDependencies()->preRenderView();
			$this->hasPreRendered = true;
		}
	}

	public static final function getInstance()
	{
		if (!self::$_instance)
		{
			self::$_instance = new static();
		}

		return self::$_instance;
	}
}
?>