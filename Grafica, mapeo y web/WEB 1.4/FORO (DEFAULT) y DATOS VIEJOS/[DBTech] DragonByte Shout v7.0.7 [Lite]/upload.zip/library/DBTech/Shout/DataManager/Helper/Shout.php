<?php
/**
* DataManager for Shouts.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Helper_Shout
{
	public static function _verifyUserId(&$userId, DBTech_Shout_DataManager $dm, $fieldName = false)
	{
		if ($userId == -1)
		{
			return true;
		}

		return $dm->verifyUserId($userId, $dm, $fieldName);
	}

	/**
	* Verifies that the notification is valid
	*
	* @param	integer	notification of the shout
	*
	* @return	boolean
	*/
	public static function _verifyNotification(&$data, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		return (in_array($data, array('', 'thread', 'reply')));
	}

	/**
	 * Verifies that the forumid is valid.
	 *
	 * @param string $forumid
	 *
	 * @return boolean
	 */
	public static function _verifyForum(&$forumid, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		$forumid = intval($forumid);
		if ($forumid === 0)
		{
			// Forumid 0 is valid
			return true;
		}

		// Check for existing instance of this name
		$forumCache = $dm->app->getForumCache();
		if (!isset($forumCache[$forumid]))
		{
			// Whoopsie, exists
			$dm->error($dm->app->phrase('dbtech_vbshout_invalid_forum'), $fieldName);
			return false;
		}

		return true;
	}

	/**
	 * Verifies that the message is valid.
	 *
	 * @param string $message
	 *
	 * @return boolean
	 */
	public static function _verifyMessage(&$message, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		// Init this
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();
		$instanceCache = $dm->cache->get('instance');

		$instanceid = $dm->get('instanceid');
		if (!$instance = $dm->getInfo('instance'))
		{
			$instance = $instanceCache[$instanceid];
			$dm->setInfo('instance', $instance);
		}

		switch ($dm->app->getSystem())
		{
			case 'XenForo':
				break;

			case 'vBulletin':
				$message = convert_urlencoded_unicode($message);
				break;
		}

		$message = str_replace(array("\n", '&lt;', '&gt;', '&quot;', '&amp;'), array('', '<', '>', '"', '&'), trim($message));

		if ($instance['options']['maxchars'] AND !$dm->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager') AND !$dm->getInfo('verifiedmessage'))
		{
			$message = substr($message, 0, $instance['options']['maxchars']);
			$dm->setInfo('verifiedmessage', true);
		}

		if (empty($message))
		{
			$dm->error($dm->app->phrase('dbtech_vbshout_invalid_message_specified'));
			return false;
		}

		// Strip out some characters we can't deal with
		$message = preg_replace('/[\x00-\x1F]/', '', $message);

		if ($instance['options']['allcaps'])
		{
			switch ($dm->app->getSystem())
			{
				case 'XenForo':
					if ($message == utf8_strtoupper($message))
					{
						// Sort this out
						$message = utf8_ucfirst(utf8_strtolower($message));
					}
					break;

				case 'vBulletin':
					// Grab the noshout text
					require_once(DIR . '/includes/functions_newpost.php');
					$message = fetch_no_shouting_text($message);
					break;
			}
		}

		return true;
	}

	/**
	 * Parses action codes
	 *
	 * @return boolean
	 */
	public static function _parseActionCodes(DBTech_Shout_DataManager $dm)
	{
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();

		if ($dm->get('type') != $shoutbox->shouttypes['shout'])
		{
			// We're not doing anything with a non-shout type
			// Notifications / PMs are already parsed and ready
			return true;
		}

		// Init this
		$instanceCache = $dm->cache->get('instance');
		$chatroomCache = $dm->cache->get('chatroom');
		

		$instanceid = $dm->get('instanceid');
		if (!$instance = $dm->getInfo('instance'))
		{
			$instance = $instanceCache[$instanceid];
			$dm->setInfo('instance', $instance);
		}

		// Shorthand
		$message = $dm->get('message');

		// The PM command is special and can't be prettified.
		// It's also the only 3-stage command we have, so it doesn't matter
		if (preg_match("#^(\/pm)\s+?(.+?);\s+?(.+?)$#i", $message, $matches))
		{
			if (!$instance['permissions_parsed']['canpm'])
			{
				// We has an error
				$dm->error($dm->app->phrase('dbtech_vbshout_pming_disabled_usergroup'));
				return false;
			}

			if ($matches[2] == $dm->app->getUserInfo('username'))
			{
				// We has an error
				$dm->error($dm->app->phrase('dbtech_vbshout_cannot_pm_self'));
				return false;
			}

			if (!$exists = $dm->_getDb()->fetchRow('
				SELECT *, =user:userid= AS userid
				FROM $user AS user
				WHERE username = ?
			', array(htmlspecialchars($matches[2]))))
			{
				// We has an error
				$dm->error($dm->app->phrase('dbtech_vbshout_invalid_user'));
				return false;
			}

			$return_value = true;
			

			if (!$return_value)
			{
				// We're ending it early
				return $return_value;
			}

			// Override some values
			$dm->set('id', 			$exists['userid']);
			$dm->set('type', 		$shoutbox->shouttypes['pm']);
			$dm->set('message', 	$matches[3]);
			$dm->set('chatroomid', 	0);
		}
		else if (preg_match("#^(\/[a-z0-9]*?)$#i", $message, $matches))
		{
			// 1-stage command
			switch ($matches[1])
			{
				case '/prune':

					if (!$dm->get('chatroomid'))
					{
						if (!$instance['permissions_parsed']['canprune'])
						{
							// We has an error
							$dm->error($dm->app->phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}
					else
					{
						if ($chatroomCache[$dm->get('chatroomid')]['creator'] != $dm->app->getUserInfo('userid') AND !$instance['permissions_parsed']['canprune'])
						{
							// Only chat room creators can prune
							$dm->error($dm->app->phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}

					// Now get rid of the shouts
					$dm->_getDb()->delete('dbtech_vbshout_shout', 'instanceid = ' . intval($dm->get('instanceid')) . ' AND chatroomid = ' . intval($dm->get('chatroomid')));

					// Rebuild shout counts
					$shoutbox->buildShoutsCounter();

					// Log the prune command
					$shoutbox->logCommand('prune');

					// Blank out the message and change type
					$dm->set('type', 		$shoutbox->shouttypes['system']);
					$dm->set('message', 	$dm->app->phrase('dbtech_vbshout_shoutbox_pruned'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}
					break;

				case '/editsticky':
					if (!$instance['permissions_parsed']['cansticky'])
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_cannot_sticky'));
						return false;
					}

					// What we need to put in the editor
					$shoutbox->fetched['editor'] = '/sticky ' . $instance['sticky_raw'];

					// We're not continuing
					return false;
					break;

				case '/createchat':
					$dm->error($dm->app->phrase('dbtech_vbshout_invalid_chatroom_name'));
					return false;
					break;

				case '/resetshouts':
					if (!$dm->get('chatroomid'))
					{
						if (!$instance['permissions_parsed']['canprune'])
						{
							// We has an error
							$dm->error($dm->app->phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}
					else
					{
						if ($chatroomCache[$dm->get('chatroomid')]['creator'] != $dm->app->getUserInfo('userid') AND !$instance['permissions_parsed']['canprune'])
						{
							// Only chat room creators can prune
							$dm->error($dm->app->phrase('dbtech_vbshout_cannot_prune'));
							return false;
						}
					}

					// Reset all users' lifetime shouts
					$dm->_getDb()->query('UPDATE $user SET dbtech_vbshout_shouts_lifetime = dbtech_vbshout_shouts', array(), 'query_write');

					// Log the removesticky command
					$shoutbox->logCommand('resetshouts');

					// Blank out the message and change type
					$dm->set('type', 		$shoutbox->shouttypes['system']);
					$dm->set('message', 	$dm->app->phrase('dbtech_vbshout_shouts_reset'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}

					break;

				case '/removenotice':
				case '/removesticky':
				case '/sticky':
					if (!$instance['permissions_parsed']['cansticky'])
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_cannot_sticky'));
						return false;
					}

					// Remove the sticky note
					$shoutbox->setSticky('', $instance);

					// Log the removesticky command
					$shoutbox->logCommand('removesticky');

						// Blank out the message
					$dm->set('type', 		$shoutbox->shouttypes['system']);
					$dm->set('message', 	$dm->app->phrase('dbtech_vbshout_sticky_note_removed'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}
					break;

				case '/banlist':
					if (!$instance['permissions_parsed']['canban'])
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_cannot_ban'));
						return false;
					}

					$users = $dm->_getDb()->fetchAll('
						SELECT *
						FROM $user
						WHERE dbtech_vbshout_banned = 1
					');

					$bannedUsers = array();
					foreach ($users as $user)
					{
						switch ($dm->app->getSystem())
						{
							case 'XenForo':
								$user['musername'] = XenForo_Template_Helper_Core::callHelper('richusername', array($user));
								break;

							case 'vBulletin':
								// Grab the markup username for this user
								fetch_musername($user);

								
								break;
						}

						// Store silenced user
						$bannedUsers[] = $user['musername'];
					}

					// Blank out the message and change type
					$dm->set('userid', 	$dm->app->getUserInfo('userid'));
					$dm->set('id', 		$dm->app->getUserInfo('userid'));
					$dm->set('type', 	$shoutbox->shouttypes['pm']);
					$dm->set('message', (count($bannedUsers) ? implode(', ', $bannedUsers) : $dm->app->phrase('dbtech_vbshout_no_banned_users')));
					break;

				default:
					$return_value = true;
					$handled = false;

					

					return $return_value;
					break;
			}
		}
		else if (preg_match("#^(\/[a-z0-9]*?)\s(.+?)$#i", $message, $matches))
		{
			// 2-stage command
			switch ($matches[1])
			{
				case '/me':
					// ZE ME COMMAND, IT DOEZ NOZING
					break;

				case '/invite':
				case '/chatinvite':
					// Invite an user to chat
					$chatroomid = $dm->get('chatroomid');

					if (!isset($chatroomCache[$chatroomid]) OR $chatroomCache[$chatroomid]['membergroupids'])
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_invalid_chat_room'));
						return false;
					}

					if (!$userId = $dm->_getDb()->fetchAll('
						SELECT =user:userid=
						FROM $user AS user
						WHERE username = ?
					', array(htmlspecialchars($matches[2]))))
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_invalid_user'));
						return false;
					}

					// Invite to join the chat room
					$shoutbox->chatInvite($chatroomCache[$chatroomid], $userId, $dm->app->getUserInfo('userid'));

					return false;
					break;

				case '/ignore':
				case '/unignore':
					// Ignore an user
					if (!$exists = $dm->_getDb()->fetchRow('
						SELECT *, =user:userid= AS userid
						FROM $user AS user
						WHERE username = ?
					', array(htmlspecialchars($matches[2]))))
					{
						// We has an error
						$dm->error($dm->app->phrase('dbtech_vbshout_invalid_user'));
						return false;
					}

					if ($exists['userid'] == $dm->app->getUserInfo('userid'))
					{
						// Ourselves, duh
						$dm->error($dm->app->phrase('dbtech_vbshout_cannot_ignore_self'));
						return false;
					}

					$isProtected = false;
					try
					{
						$shoutbox->checkProtectedUserGroup($instance, $exists);
					}
					catch (Exception $e)
					{
						// Yeah
						$isProtected = true;
					}

					if ($isProtected)
					{
						// We had an error
						$dm->error($dm->app->phrase('dbtech_vbshout_protected_usergroup'));
						return false;
					}

					if ($matches[1] == '/ignore')
					{
						// Ignore the user
						$dm->_getDb()->replace('dbtech_vbshout_ignorelist', array(
							'userid' => $dm->app->getUserInfo('userid'),
							'ignoreuserid' => $exists['userid']
						));
					}
					else
					{
						// Unignore the user
						$dm->_getDb()->delete('dbtech_vbshout_ignorelist', 'userid = ' . intval($dm->app->getUserInfo('userid')) . ' AND ignoreuserid = ' . intval($exists['userid']));
					}
					return false;
					break;

				case '/notice':
				case '/setnotice':
				case '/sticky':
				case '/setsticky':
					if (!$instance['permissions_parsed']['cansticky'])
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_cannot_sticky'));
						return false;
					}

					// Set the sticky note
					$shoutbox->setSticky($matches[2], $instance);

					// Log the setsticky command
					$shoutbox->logCommand('setsticky', $matches[2]);

					// Blank out the message
					$dm->set('type', 		$shoutbox->shouttypes['system']);
					$dm->set('message', 	$dm->app->phrase('dbtech_vbshout_sticky_note_set'));
					if (!$instance['permissions_parsed']['showaction'])
					{
						// We're not showing action
						$dm->set('userid', 	-1);
					}
					break;

				case '/ban':
				case '/unban':
					if (!$instance['permissions_parsed']['canban'])
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_cannot_ban'));
						return false;
					}

					// Banning an user
					if (!$exists = $dm->_getDb()->fetchRow('
						SELECT *, =user:userid= AS userid
						FROM $user AS user
						WHERE username = ?
					', array(htmlspecialchars($matches[2]))))
					{
						// We has an error
						$dm->error($dm->app->phrase('dbtech_vbshout_invalid_user'));
						return false;
					}

					if ($exists['userid'] == $dm->app->getUserInfo('userid'))
					{
						// Ourselves, duh
						$dm->error($dm->app->phrase('dbtech_vbshout_cannot_ban_self'));
						return false;
					}

					$isProtected = false;
					try
					{
						$shoutbox->checkProtectedUserGroup($instance, $exists);
					}
					catch (Exception $e)
					{
						// Yeah
						$isProtected = true;
					}

					if ($isProtected)
					{
						// We had an error
						$dm->error($dm->app->phrase('dbtech_vbshout_protected_usergroup'));
						return false;
					}

					// Log the ban command
					$shoutbox->logCommand(($matches[1] == '/ban' ? 'ban' : 'unban'), $exists['userid']);

					// Ban the user
					$dm->_getDb()->update('user', array('dbtech_vbshout_banned' => ($matches[1] == '/ban' ? 1 : 0)), '=user:userid= = ' . $exists['userid']);

					if (!$instance['permissions_parsed']['showaction'])
					{
						return false;
					}

					// Print success message
					$dm->set('type', 		$shoutbox->shouttypes['system']);
					$dm->set('message', 	($matches[1] == '/ban' ? $dm->app->phrase('dbtech_vbshout_banned_successfully', array('param1' => $matches[2])) : $dm->app->phrase('dbtech_vbshout_unbanned_successfully', array('param1' => $matches[2]))));
					break;

				case '/createchat':
					if (!$instance['permissions_parsed']['cancreatechat'])
					{
						$dm->error($dm->app->phrase('dbtech_vbshout_cant_create_chat'));
						return false;
					}

					if ($instance['options']['maxchats'])
					{
						$i = 0;
						foreach ($chatroomCache as $chatroomid => $chatroom)
						{
							if (!$chatroom['active'])
							{
								// Don't count closed rooms
								continue;
							}

							if ($chatroom['creator'] == $dm->app->getUserInfo('userid'))
							{
								// We're the creator
								$i++;
							}
						}

						if ($i >= $instance['options']['maxchats'])
						{
							// Waaaay too many chats, slow down tiger!
							$dm->error($dm->app->phrase('dbtech_vbshout_too_many_chats'));
							return false;
						}
					}

					// init data manager
					$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_ARRAY);
						$chatroomDm->bulkSet(array(
							'title' => $matches[2],
							'instanceid' => $instance['instanceid'],
							'creator' => $dm->app->getUserInfo('userid'),
							'members' => array($dm->app->getUserInfo('userid') => '1')
						));
					$chatroomid = $chatroomDm->save();
					unset($chatroomDm);

					// Insert the chat member
					$dm->_getDb()->insert('dbtech_vbshout_chatroommember', array(
						'chatroomid' => $chatroomid,
						'userid' => $dm->app->getUserInfo('userid'),
						'status' => 1
					));

					// Set chat room info
					$shoutbox->fetched['chatroom'] = array(
						'chatroomid' 	=> $chatroomid,
						'title' 		=> $matches[2]
					);

					$shoutbox->fetched['stopSave'] = true;
					return false;
					break;


				case '/joinchat':

					$hasMatch = false;
					foreach ($chatroomCache as $chatroom)
					{
						if (!$chatroom['active'])
						{
							// Don't count closed rooms
							continue;
						}

						if (
							!$chatroom['membergroupids']
							OR $chatroom['autojoin']
						)
						{
							// This is someone's private room, or a UG room with auto join
							continue;
						}

						if (
							$chatroom['membergroupids'] != '-1'
							AND !$dm->app->isMemberOf($dm->app->getUserInfo(), explode(',', $chatroom['membergroupids']))
						)
						{
							// No permission to join
							continue;
						}

						if ($chatroom['title'] == $matches[2])
						{
							// Keep the chatroom variable
							$hasMatch = true;
							break;
						}
					}

					if ($hasMatch)
					{
						// Join the chat
						$shoutbox->joinChatroom($chatroom, $dm->app->getUserInfo('userid'));

						// Set chat room info
						$shoutbox->fetched['chatroom'] = [
							'chatroomid' 	=> $chatroom['chatroomid'],
							'title' 		=> $matches[2]
						];
					}

					$shoutbox->fetched['stopSave'] = true;
					return false;
					break;

				default:
					$return_value = true;
					$handled = false;

					

					return $return_value;
					break;
			}
		}

		return true;
	}

	/**
	 * Verifies that the forumid is valid.
	 *
	 * @param string $forumid
	 *
	 * @return boolean
	 */
	public static function _verifyImageCount(&$message, array $instance, DBTech_Shout_DataManager $dm)
	{
		switch ($dm->app->getSystem())
		{
			case 'XenForo':
				$maxImages = $instance['options']['maximages'] ? $instance['options']['maximages'] : $dm->app->option('messageMaxImages');

				if ($maxImages AND !$dm->getInfo('is_automated'))
				{
					$formatter = XenForo_BbCode_Formatter_Base::create('ImageCount', false);
					$parser = XenForo_BbCode_Parser::create($formatter);
					$parser->render($message);

					// Grab image count
					$imageCount = $formatter->getImageCount();
				}
				break;

			case 'vBulletin':
				$maxImages = $instance['options']['maximages'] ? $instance['options']['maximages'] : $dm->app->option('maximages');

				if ($maxImages AND !$dm->getInfo('is_automated'))
				{
					// check max images
					require_once(DIR . '/includes/functions_misc.php');
					require_once(DIR . '/includes/class_bbcode_alt.php');
					$bbcode_parser = new vB_BbCodeParser_ImgCheck($GLOBALS['vbulletin'], fetch_tag_list());
					$bbcode_parser->set_parse_userinfo($dm->app->getUserInfo());

					// Grab image count
					$imageCount = fetch_character_count($bbcode_parser->parse($message, 'nonforum', $instance['options']['allowsmilies'], true), '<img');
				}
				break;
		}

		if ($imageCount > $maxImages)
		{
			$dm->error($dm->app->phrase('dbtech_vbshout_too_many_images', array('param1' => $imageCount, 'param2' => $maxImages)));
			return false;
		}

		return true;
	}
}