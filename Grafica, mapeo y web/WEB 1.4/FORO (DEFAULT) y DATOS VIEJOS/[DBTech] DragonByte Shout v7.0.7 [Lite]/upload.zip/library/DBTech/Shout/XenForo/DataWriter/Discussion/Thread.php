<?php
class DBTech_Shout_XenForo_DataWriter_Discussion_Thread extends XFCP_DBTech_Shout_XenForo_DataWriter_Discussion_Thread
{
	/**
	 * Specific discussion post-save behaviors.
	 */
	protected function _discussionPostSave()
	{
		// Do parent stuff
		$previous = parent::_discussionPostSave();

		// Get user model
		$userModel = $this->getModelFromCache('XenForo_Model_User');

		if ($this->isUpdate())
		{
			return $previous;
		}

		if (!$this->get('user_id'))
		{
			return $previous;
		}

		if (!$shoutUserInfo = $userModel->getUserById($this->get('user_id')))
		{
			return $previous;
		}

		// Shorthand
		$app = DBTech_Shout_Core::getInstance();
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();
		$instanceCache = DBTech_Shout_Cache::getInstance()->get('instance');

		if (
			!$shoutUserInfo['dbtech_vbshout_banned']
			AND $this->get('discussion_state') == 'visible'
		)
		{
			$thread = $this->getModelFromCache('XenForo_Model_Thread')->getThreadById($this->get('thread_id'));

			// This will need to be updated once we figure out the parent/child tree in xF
			$noticeForum = $this->get('node_id');

			foreach ($instanceCache as $instanceid => $instance)
			{
				if (!isset($instance['notices'][$noticeForum]))
				{
					// Make sure this is set
					$instance['notices'][$noticeForum] = 0;
				}

				if (!(intval($instance['options']['notices']) & 1) OR
					!(intval($instance['notices'][$noticeForum]) & 1)
				)
				{
					// Not showing this
					continue;
				}

				//if ($instance['bbcodepermissions_parsed']['bit'] & 64)
				if (true)
				{
					// We can use BBCode
					$notif = '[URL=' . XenForo_Link::buildPublicLink('full:threads', array('thread_id' => $this->get('thread_id'), 'title' => $thread['title'])) . ']' . $thread['title'] . '[/URL]';
				}
				else
				{
					// We can't, so don't even bother
					$notif = $thread['title'];
				}

				// init data manager
				$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
					$shoutDm->setInfo('is_automated', true);
					$shoutDm->setInfo('instance', $instance);
					$shoutDm->bulkSet(array(
						'instanceid' => $instanceid,
						'message' => $app->phrase('dbtech_vbshout_notif_thread', array('param1' => $notif)),
						'userid' => $shoutUserInfo['user_id'],
						'forumid' => $this->get('node_id'),
						'type' => $shoutbox->shouttypes['notif']
					));
				$shoutId = $shoutDm->save();
				unset($shoutDm);

				
			}
		}

		if ($this->_forumCountsMessages())
		{
			foreach ($instanceCache as $instanceid => $instance)
			{
				if (!$instance['options']['postping_interval'])
				{
					// Not having notices here
					continue;
				}

				if (($shoutUserInfo['message_count'] + 1) % $instance['options']['postping_interval'] != 0)
				{
					// We only want matching intervals
					continue;
				}

				$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
					$shoutDm->setInfo('is_automated', true);
					$shoutDm->setInfo('instance', $instance);
					$shoutDm->bulkSet(array(
						'message' => $app->phrase('dbtech_vbshout_has_reached_x_posts', array('param1' => ($shoutUserInfo['message_count'] + 1))),
						'instanceid' => $instanceid,
						'type' => $shoutbox->shouttypes['notif']
					));
				$shoutDm->save();
				unset($shoutDm);
			}

			$threadCount = $app->_getDb()->fetchOne('
				SELECT COUNT(*) AS threads
				FROM $thread
				WHERE user_id = ?
			', array($shoutUserInfo['user_id']), 'threads');
			foreach ($instanceCache as $instanceid => $instance)
			{
				if (!$instance['options']['threadping_interval'])
				{
					// Not having notices here
					continue;
				}

				if (($threadCount + 1) % $instance['options']['threadping_interval'] != 0)
				{
					// We only want matching intervals
					continue;
				}

				$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
					$shoutDm->setInfo('is_automated', true);
					$shoutDm->setInfo('instance', $instance);
					$shoutDm->bulkSet(array(
						'message' => $app->phrase('dbtech_vbshout_has_reached_x_threads', array('param1' => ($threadCount + 1))),
						'instanceid' => $instanceid,
						'type' => $shoutbox->shouttypes['notif']
					));
				$shoutDm->save();
				unset($shoutDm);
			}
		}

		return $previous;
	}
}