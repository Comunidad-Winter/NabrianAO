<?php
abstract class DBTech_Shout_DataManager extends DBTech_Shout_Application_DataManager
{
}