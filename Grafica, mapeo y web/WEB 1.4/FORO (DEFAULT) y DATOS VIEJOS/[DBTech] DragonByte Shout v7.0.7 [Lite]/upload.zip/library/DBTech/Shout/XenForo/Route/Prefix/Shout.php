<?php

/**
 * Route prefix handler for categories in the public system.
 *
 * @package DBTech_Shout_XenForo_Route_Prefix_Profile
 */
class DBTech_Shout_XenForo_Route_Prefix_Shout implements XenForo_Route_Interface
{
	/**
	 * Match a specific route for an already matched prefix.
	 *
	 * @see XenForo_Route_Interface::match()
	 */
	public function match($routePath, Zend_Controller_Request_Http $request, XenForo_Router $router)
	{
		$action = $router->resolveActionWithIntegerParam($routePath, $request, 'id');

		$request->setParam('_dbtechAction', $action);
		return $router->getRouteMatch('DBTech_Shout_XenForo_ControllerPublic_Shout', 'index');
	}

	/**
	 * Method to build a link to the specified page/action with the provided
	 * data and params.
	 *
	 * @see XenForo_Route_BuilderInterface
	 */
	public function buildLink($originalPrefix, $outputPrefix, $action, $extension, $data, array &$extraParams)
	{
		return XenForo_Link::buildBasicLinkWithIntegerParam($outputPrefix, $action, $extension, $data, 'id', 'title');
	}
}