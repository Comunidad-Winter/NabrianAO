<?php
class DBTech_Shout_XenForo_ControllerPublic_Shout extends XenForo_ControllerPublic_Abstract
{
	public function actionIndex()
	{
		// Get the instance
		$app = DBTech_Shout_Core::getInstance();

		if (!isset($_REQUEST['do']))
		{
			if ($this->_request->isPost())
			{
				$_POST['do'] = $this->_request->getParam('_dbtechAction');
				$_POST['id'] = $this->_input->filterSingle('id', XenForo_Input::UINT);
			}
			else
			{
				$_GET['do'] = $this->_request->getParam('_dbtechAction');
				$_GET['id'] = $this->_input->filterSingle('id', XenForo_Input::UINT);
			}
		}

		try
		{
			// Run the action based on URL params
			$app->runAction();
		}
		catch (XenForo_Exception $e)
		{
			if ($e->isUserPrintable())
			{
				// User printable message
				return $this->responseMessage($e->getMessages());
			}
			else
			{
				// An error
				return $this->responseError($e->getMessages());
			}
		}

		$viewParams = array_merge($this->_getTemplate()->getParams('output'), array(
			'html' => $this->_getTemplate()->getOutput(),
		));

		$containerParams = array_merge($this->_getTemplate()->getParams('output'), array(
			'majorSection' => 'forums'
		));

		return $this->responseView('DBTech_Shout_ViewPublic_Shout', 'dbtech_shout', $viewParams, $containerParams);
	}

	protected function _getTemplate()
	{
		return DBTech_Shout_Template::getInstance();
	}
}