<?php
class DBTech_Shout_Application_ResponseMessageException extends Exception {}