<?php
class DBTech_Shout_ActionAdmin_Options extends DBTech_Shout_ActionAdmin
{
	public function actionIndex() {}

	public function actionUpdate() {}
}
?>