<?php
class DBTech_Shout_Application_Core
{
	protected static $jQueryVersion = '1.11.0';

	protected static $_instance;

	protected $system;
	protected $_modelCache = [];
	protected static $_actionCache = [];
	protected $_input;
	protected $_controller;

	protected $_hasPhrases = false;

	public $db;
	public $versionnumber;
	public $userinfo = [];
	public $usergroupcache = [];
	public $forumcache = [];

	/**
	 * [__construct description]
	 */
	public function __construct()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				try
				{
					$fc = XenForo_Application::get('fc');
				}
				catch (Exception $e)
				{
					if (isset($GLOBALS['dependencies']))
					{
						// Grab from global
						$dependencies = $GLOBALS['dependencies'];
					}
					else if (isset($GLOBALS['bridge']) AND $GLOBALS['bridge'] instanceof Tapatalk_Bridge)
					{
						// If Tapatalk could go away, I would be very happy.
						$dependencies = $GLOBALS['bridge']->getDependencies();
					}
					else
					{
						// Store this
						$dependencies = new XenForo_Dependencies_Public();
						$dependencies->preLoadData();
					}

					$fc = new XenForo_FrontController($dependencies);
					$fc->setup();
					$fc->setRequestPaths();

					// Now set this
					XenForo_Application::set('fc', $fc);
				}

				$startTime = microtime(true);

				// Set the version number
				$this->versionnumber = XenForo_Application::$version;

				if (!defined('TYPE_ARRAY'))
				{
					// Define important constants
					define('TYPE_ARRAY', 		XenForo_Input::ARRAY_SIMPLE);
					define('TYPE_ARRAY_JSON', 	XenForo_Input::JSON_ARRAY);
					define('TYPE_UINT', 		XenForo_Input::UINT);
					define('TYPE_INT', 			XenForo_Input::INT);
					define('TYPE_UNUM', 		XenForo_Input::UNUM);
					define('TYPE_NUM', 			XenForo_Input::NUM);
					define('TYPE_STR', 			XenForo_Input::STRING);
					define('TYPE_BOOL', 		XenForo_Input::BOOLEAN);
					define('TYPE_UNIXTIME', 	'unixtime');
					define('TYPE_NOHTML', 		'nohtml');
				}
				break;

			case 'vBulletin':
				// Set the version number
				$this->versionnumber = $GLOBALS['vbulletin']->versionnumber;

				if (!defined('TYPE_ARRAY_JSON'))
				{
					define('TYPE_ARRAY_JSON', 	'json_array');
				}
				break;
		}
	}

	/**
	 * [getSystem description]
	 * @return [type] [description]
	 */
	public function getSystem()
	{
		if (!isset($this->system) OR !$this->system OR $this->system === NULL)
		{
			$this->system = class_exists('XenForo_Application') ? 'XenForo' : 'vBulletin';
		}

		return $this->system;
	}

	/**
	 * [getUserInfo description]
	 * @param  string $name [description]
	 * @return [type]       [description]
	 */
	public function getUserInfo($name = '')
	{
		if (!$this->userinfo)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					$visitor = XenForo_Visitor::getInstance()->toArray();
					$this->userinfo = $visitor;
					$this->userinfo['userid'] =& $this->userinfo['user_id'];
					$this->userinfo['usergroupid'] =& $this->userinfo['user_group_id'];
					$this->userinfo['membergroupids'] =& $this->userinfo['secondary_group_ids'];
					$this->userinfo['is_staff'] = ($this->userinfo['is_moderator'] OR $this->userinfo['is_admin']);
					break;

				case 'vBulletin':
					// Set caches
					$this->userinfo =& $GLOBALS['vbulletin']->userinfo;
					$this->userinfo['is_moderator'] = $this->usergroupPermission('adminpermissions', 'ismoderator', $this->userinfo['permissions'], $this->userinfo);
					$this->userinfo['is_admin'] = $this->usergroupPermission('adminpermissions', 'cancontrolpanel', $this->userinfo['permissions'], $this->userinfo);
					$this->userinfo['is_staff'] = ($this->userinfo['is_moderator'] OR $this->userinfo['is_admin']);
					break;
			}
		}

		if ($name)
		{
			if (array_key_exists($name, $this->userinfo))
			{
				return $this->userinfo[$name];
			}
			else
			{
				return false;
			}
		}
		else
		{
			return $this->userinfo;
		}
	}

	/**
	 * [setUserInfo description]
	 * @param [type] $name  [description]
	 * @param [type] $value [description]
	 */
	public function setUserInfo($name, $value)
	{
		// Make sure we've fetched the old stuff
		$this->getUserInfo($name);

		// Set new value
		$this->userinfo[$name] = $value;
	}

	/**
	 * [getUserGroupCache description]
	 * @param  integer $userGroupId [description]
	 * @return [type]               [description]
	 */
	public function getUserGroupCache($userGroupId = 0)
	{
		if (!$this->usergroupcache)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					// Set usergroup cache
					$this->usergroupcache = $this->createModel('XenForo_Model_UserGroup')->getAllUserGroups();
					foreach ($this->usergroupcache as $key => $arr)
					{
						// Make it usable with vB code
						$this->usergroupcache[$key]['usergroupid'] =& $this->usergroupcache[$key]['user_group_id'];
					}
					break;

				case 'vBulletin':
					// Set caches
					$this->usergroupcache = $GLOBALS['vbulletin']->usergroupcache;
					break;
			}
		}

		if ($userGroupId)
		{
			if (array_key_exists($userGroupId, $this->usergroupcache))
			{
				return $this->usergroupcache[$userGroupId];
			}
			else
			{
				return false;
			}
		}
		else
		{
			return $this->usergroupcache;
		}
	}

	/**
	 * [getForumCache description]
	 * @param  string $forumId [description]
	 * @return [type]          [description]
	 */
	public function getForumCache($forumId = '')
	{
		if (!$this->forumcache)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					// Set forum cache
					$this->forumcache = $this->createModel('XenForo_Model_Forum')->getForums();
					foreach ($this->forumcache as $key => $arr)
					{
						// Make it usable with vB code
						$this->forumcache[$key]['forumid'] =& $this->forumcache[$key]['node_id'];
					}
					break;

				case 'vBulletin':
					// Set caches
					$this->forumcache = $GLOBALS['vbulletin']->forumcache;
					break;
			}
		}

		if ($forumId)
		{
			if (array_key_exists($forumId, $this->forumcache))
			{
				return $this->forumcache[$forumId];
			}
			else
			{
				return false;
			}
		}
		else
		{
			return $this->forumcache;
		}
	}

	/**
	 * [runAction description]
	 * @return [type] [description]
	 */
	public function runAction()
	{
		// Default value
		$class = 'main';

		if (isset($_POST['do']) AND !empty($_POST['do']))
		{
			// $_POST requests take priority
			$class = $_POST['do'];
		}
		else if (isset($_GET['do']) AND !empty($_GET['do']))
		{
			// We had a GET request instead
			$class = $_GET['do'];
		}

		// Strip non-valid characters
		$class = preg_replace('/[^\w-_\/]/i', '', strtolower($class));

		$class = implode('_', array_map('ucfirst', explode('/', $class)));
		$class = str_replace('-', ' ', $class);
		$class = str_replace(' ', '', ucwords($class));
		if ($class === '')
		{
			// No request
			$class = 'Main';
		}

		// Shorthand
		$class = $this->_getActionClassName($class);

		try
		{
			// Grab this
			$actionClass = $this->getActionFromCache($class);

			if (isset($_POST['action']) AND !empty($_POST['action']))
			{
				// $_POST requests take priority
				$action = $_POST['action'];
			}
			else if (isset($_GET['action']) AND !empty($_GET['action']))
			{
				// We had a GET request instead
				$action = $_GET['action'];
			}
			else
			{
				$action = '';
			}

			// Strip non-valid characters
			$action = preg_replace('/[^\w-]/i', '', strtolower($action));

			$action = str_replace(['-', '/'], ' ', $action);
			$action = str_replace(' ', '', ucwords($action));
			if ($action === '')
			{
				$action = 'Index';
			}

			// Shorthand
			$action = 'action' . $action;

			if (!method_exists($actionClass, $action))
			{
				// Action class didn't exist
				throw new DBTech_Shout_Application_ResponseErrorException("Method <b>$action</b> cannot be found in <b>$class</b>.");
			}

			// Shorthand
			$actionClass->$action();

			if (strpos(get_called_class(), '_Admin') !== false)
			{
				// Make sure we got this
				print_cp_footer();
			}
		}
		catch (DBTech_Shout_Application_ResponseErrorException $e)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					// Error exception
					throw new XenForo_Exception($e->getMessage());
					break;

				case 'vBulletin':
					// Trigger error
					eval(standard_error($e->getMessage()));
					break;
			}
		}
		catch (DBTech_Shout_Application_ResponseMessageException $e)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					// User printable exception
					throw new XenForo_Exception($e->getMessage(), true);
					break;

				case 'vBulletin':
					// Trigger error
					eval(standard_error($e->getMessage()));
					break;
			}
		}
		catch (DBTech_Shout_Application_ResponseRedirectException $e)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					// User printable exception
					throw new XenForo_Exception($e->getMessage(), true);
					break;

				case 'vBulletin':
					// Trigger error
					eval(standard_error($e->getMessage()));
					break;
			}
		}
		catch (Exception $e)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					// Error exception
					throw new XenForo_Exception($e->getMessage());
					break;

				case 'vBulletin':
					// Trigger error
					eval(standard_error($e->getMessage()));
					break;
			}
		}
	}

	/**
	 * [error description]
	 * @param  [type] $message [description]
	 * @param  array  $params  [description]
	 * @return [type]          [description]
	 */
	public function error($message, array $params = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				if (isset($_REQUEST['_xfResponseType']) AND $_REQUEST['_xfResponseType'] == 'json')
				{
					$params['error'] = ['title' => $message];
					$params['templateHtml'] = $this->_getTemplate()->renderTemplate('error', ['error' => [$message], 'showHeading' => true]);
					die(json_encode($params));
				}
				else
				{

					if (isset($params['_exception']))
					{
						$exception = $this->traceHtml($params['_exception']);
						$message = "<div class=\"baseHtml exception\"><p>$exception[error]</p> <ol class=\"traceHtml\">\n$exception[traceHtml]</ol></div>";
						$this->_getTemplate()->renderOutput($message);
					}
					else if (XenForo_Application::debugMode())
					{
						// Make sure we throw an exception if we're in debug mode
						throw new Exception($message);
					}
					else
					{
						$this->_getTemplate()->renderOutput($message);
					}
				}
				break;

			case 'vBulletin':
				eval(standard_error($message));
				break;
		}
	}

	/**
	 * [redirect description]
	 * @param  [type]  $message        [description]
	 * @param  [type]  $url            [description]
	 * @param  array   $redirectParams [description]
	 * @param  boolean $forceRedirect  [description]
	 * @return [type]                  [description]
	 */
	public function redirect($message, $url, array $redirectParams = [], $forceRedirect = false)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				if (isset($_REQUEST['_xfResponseType']) AND $_REQUEST['_xfResponseType'] == 'json')
				{
					$redirectParams['_redirectTarget'] = $url;
					$redirectParams['_redirectMessage'] = $message ? $message : $this->phrase('redirect_changes_saved_successfully');
					die(json_encode($redirectParams));
				}
				else if ($forceRedirect)
				{
					$paths = XenForo_Application::get('requestPaths');
					$this->_getTemplate()->renderOutput(
						$this->_getTemplate()->renderTemplate('dbtech_vbshout_standard_redirect', ['basePath' => $paths['fullBasePath'], 'url' => $url, 'message' => $message])
					);
				}
				else
				{
					$paths = XenForo_Application::get('requestPaths');
					header('Location: ' . $paths['fullBasePath'] . $url);
					die();
				}
				break;

			case 'vBulletin':
				// Set redirect URL
				$GLOBALS['vbulletin']->url = $url ? $url : ($this->option('forumhome') . '.php');
				eval(standard_redirect($message, $forceRedirect));
				break;
		}
	}

	/**
	 * [option description]
	 * @param  [type] $option [description]
	 * @return [type]         [description]
	 */
	public function option($option)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				switch ($option)
				{
					case 'bbtitle': $option = 'boardTitle'; break;
					case 'bburl': 	$option = 'boardUrl'; 	break;
				}
				return XenForo_Application::get('options')->get($option);
				break;

			case 'vBulletin':
				return isset($GLOBALS['vbulletin']->options[$option]) ? $GLOBALS['vbulletin']->options[$option] : null;
				break;
		}
	}

	/**
	 * [phrase description]
	 * @param  [type] $phrase [description]
	 * @param  array  $params [description]
	 * @return [type]         [description]
	 */
	public function phrase($phrase, array $params = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				if (!$this->_hasPhrases)
				{
					// Shorthand
					$db = XenForo_Application::getDb();
					$visitor = XenForo_Visitor::getInstance()->toArray();

					// Set language
					XenForo_Phrase::setLanguageId($visitor['language_id'] ? $visitor['language_id'] : $this->option('defaultLanguageId'));

					// Pre-cache phrases
					XenForo_Phrase::setPhrases($db->fetchPairs('
						SELECT title, phrase_text
						FROM xf_phrase_compiled
						WHERE language_id = ?
							AND title LIKE \'dbtech_vbshout_%\'
					', XenForo_Phrase::getLanguageId()));

					$this->_hasPhrases = true;
				}
				XenForo_Phrase::setEscapeCallback(false);
				$phrase = new XenForo_Phrase($phrase, $params);
				return $phrase->render();
				break;

			case 'vBulletin':
				if (!isset($GLOBALS['vbphrase'][$phrase]))
				{
					// Return plain text
					return $phrase;
				}

				return preg_replace_callback('/\{([a-z0-9_-]+)\}/i', function($match) use ($params)
				{
					$paramName = $match[1];

					if (!array_key_exists($paramName, $params))
					{
						return $match[0];
					}

					return $params[$paramName];
				}, $GLOBALS['vbphrase'][$phrase]);
				break;
		}
	}

	/**
	 * [isDebugMode description]
	 * @return boolean [description]
	 */
	public function isDebugMode()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return XenForo_Application::debugMode();
				break;

			case 'vBulletin':
				return $GLOBALS['vbulletin']->debug;
				break;
		}
	}

	/**
	 * [isAjaxRequest description]
	 * @return boolean [description]
	 */
	public function isAjaxRequest()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return XenForo_Application::get('fc')->getRequest()->isXmlHttpRequest();
				break;

			case 'vBulletin':
				return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
				break;
		}
	}

	/**
	 * [isConfirmedPost description]
	 * @return boolean [description]
	 */
	public function isConfirmedPost()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return (XenForo_Application::get('fc')->getRequest()->isPost() AND $this->filterSingle('_xfConfirm', TYPE_UINT));
				break;

			case 'vBulletin':
				return (isset($_SERVER['REQUEST_METHOD']) AND strtolower($_SERVER['REQUEST_METHOD']) === 'post');
				break;
		}
	}

	/**
	 * [getTime description]
	 * @return [type] [description]
	 */
	public function getTime()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return XenForo_Application::$time;
				break;

			case 'vBulletin':
				return TIMENOW;
				break;
		}
	}

	/**
	 * [getIpAddress description]
	 * @return [type] [description]
	 */
	public function getIpAddress()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return XenForo_Application::get('fc')->getRequest()->getClientIp();
				break;

			case 'vBulletin':
				return IPADDRESS;
				break;
		}
	}

	/**
	 * [getUserByName description]
	 * @param  [type] $username     [description]
	 * @param  array  $fetchOptions [description]
	 * @return [type]               [description]
	 */
	public function getUserByName($username, array $fetchOptions = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$user = $this->createModel('XenForo_Model_User')->getUserByName($username, $fetchOptions);

				if ($user)
				{
					// Set flags
					$user['userid'] =& $user['user_id'];
					$user['usergroupid'] =& $user['user_group_id'];
					$user['membergroupids'] =& $user['secondary_group_ids'];
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);
				}

				return $user;
				break;

			case 'vBulletin':
				$user = $this->_getDb()->fetchRow('
					SELECT *
					FROM $user AS user
					WHERE username = ?
				', [htmlspecialchars_uni($username)]);

				if ($user)
				{
					// Set flags
					$user['is_moderator'] = $this->usergroupPermission('adminpermissions', 'ismoderator', $user['permissions'], $user);
					$user['is_admin'] = $this->usergroupPermission('adminpermissions', 'cancontrolpanel', $user['permissions'], $user);
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);
				}

				return $user;
				break;
		}
	}

	/**
	 * [getUserByEmail description]
	 * @param  [type] $email        [description]
	 * @param  array  $fetchOptions [description]
	 * @return [type]               [description]
	 */
	public function getUserByEmail($email, array $fetchOptions = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$user = $this->createModel('XenForo_Model_User')->getUserByEmail($email, $fetchOptions);

				if ($user)
				{
					// Set flags
					$user['userid'] =& $user['user_id'];
					$user['usergroupid'] =& $user['user_group_id'];
					$user['membergroupids'] =& $user['secondary_group_ids'];
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);
				}

				return $user;
				break;

			case 'vBulletin':
				$user = $this->_getDb()->fetchRow('
					SELECT *
					FROM $user AS user
					WHERE email = ?
				', [htmlspecialchars_uni($email)]);

				if ($user)
				{
					// Set flags
					$user['is_moderator'] = $this->usergroupPermission('adminpermissions', 'ismoderator', $user['permissions'], $user);
					$user['is_admin'] = $this->usergroupPermission('adminpermissions', 'cancontrolpanel', $user['permissions'], $user);
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);
				}

				return $user;
				break;
		}
	}

	/**
	 * [getUserById description]
	 * @param  [type] $userId [description]
	 * @return [type]         [description]
	 */
	public function getUserById($userId)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$user = $this->createModel('XenForo_Model_User')->getUserById($userId);

				if ($user)
				{
					// Set flags
					$user['userid'] =& $user['user_id'];
					$user['usergroupid'] =& $user['user_group_id'];
					$user['membergroupids'] =& $user['secondary_group_ids'];
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);
				}

				return $user;

			case 'vBulletin':
				$user = fetch_userinfo($userId);

				if ($user)
				{
					// Set flags
					$user['is_moderator'] = $this->usergroupPermission('adminpermissions', 'ismoderator', $user['permissions'], $user);
					$user['is_admin'] = $this->usergroupPermission('adminpermissions', 'cancontrolpanel', $user['permissions'], $user);
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);
				}

				return $user;
				break;
		}
	}

	/**
	 * [getUsersByIds description]
	 * @param  array   $userIds        [description]
	 * @param  boolean $markUpUserName [description]
	 * @return [type]                  [description]
	 */
	public function getUsersByIds(array $userIds, $markUpUserName = false)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$users = $this->createModel('XenForo_Model_User')->getUsersByIds(array_unique($userIds));
				foreach ($users as &$user)
				{
					$user['userid'] =& $user['user_id'];
					$user['usergroupid'] =& $user['user_group_id'];
					$user['membergroupids'] =& $user['secondary_group_ids'];
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);

					if ($markUpUserName)
					{
						// hack
						$user['musername'] = $user['username'];
					}
				}
				return $users;
				break;

			case 'vBulletin':
				$users = $this->_getDb()->fetchAllKeyed('
					SELECT
						userfield.*, usertextfield.*, user.*, UNIX_TIMESTAMP(passworddate) AS passworddate, user.languageid AS saved_languageid,
						IF(displaygroupid=0, user.usergroupid, displaygroupid) AS displaygroupid' .
						($this->option('avatarenabled') ? ', avatar.avatarpath, NOT ISNULL(customavatar.userid) AS hascustomavatar, customavatar.dateline AS avatardateline, customavatar.width AS avwidth, customavatar.height AS avheight, customavatar.height_thumb AS avheight_thumb, customavatar.width_thumb AS avwidth_thumb, customavatar.filedata_thumb' : '').
						'
					FROM $user AS user
					LEFT JOIN $userfield AS userfield ON (user.userid = userfield.userid)
					LEFT JOIN $usertextfield AS usertextfield ON (usertextfield.userid = user.userid) ' .
					($this->option('avatarenabled') ? 'LEFT JOIN $avatar AS avatar ON (avatar.avatarid = user.avatarid) LEFT JOIN $customavatar AS customavatar ON (customavatar.userid = user.userid) ' : '') .
					'
					WHERE user.userid :userIds
				', 'userid', [
					':userIds' => $this->_getDb()->queryList(array_unique($userIds))
				]);

				foreach ($users as &$user)
				{
					if ($markUpUserName)
					{
						// Sort markup username
						$user = fetch_muserinfo($user);
					}

					// Set flags
					$user['is_moderator'] = $this->usergroupPermission('adminpermissions', 'ismoderator', $user['permissions'], $user);
					$user['is_admin'] = $this->usergroupPermission('adminpermissions', 'cancontrolpanel', $user['permissions'], $user);
					$user['is_staff'] = ($user['is_moderator'] OR $user['is_admin']);
				}

				return $users;
				break;
		}
	}

	/**
	 * [getUserNamesByIds description]
	 * @param  array  $userIds [description]
	 * @return [type]          [description]
	 */
	public function getUserNamesByIds(array $userIds)
	{
		return $this->_getDb()->fetchAllSingleKeyed('
			SELECT =user:userid= AS userid, username
			FROM $user WHERE =user:userid= :userIds
		', 'userid', 'username', [
			':userIds' => $this->_getDb()->queryList(array_unique($userIds))
		]);
	}

	/**
	 * [getPostById description]
	 * @param  [type] $postId [description]
	 * @return [type]         [description]
	 */
	public function getPostById($postId)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return $this->createModel('XenForo_Model_Post')->getPostById($postId);
				break;

			case 'vBulletin':
				return fetch_postinfo($postId);
				break;
		}
	}

	/**
	 * [getThreadById description]
	 * @param  [type] $threadId [description]
	 * @return [type]           [description]
	 */
	public function getThreadById($threadId)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				if (!$threadInfo = $this->createModel('XenForo_Model_Thread')->getThreadById($threadId))
				{
					return [];
				}
				$threadInfo['threadid'] = $threadInfo['thread_id'];
				$threadInfo['forumid'] = $threadInfo['node_id'];
				$threadInfo['postuserid'] = $threadInfo['user_id'];
				switch ($threadInfo['discussion_state'])
				{
					case 'deleted': 	$threadInfo['visible'] = 2; break;
					case 'moderated': 	$threadInfo['visible'] = 0; break;
					case 'visible': 	$threadInfo['visible'] = 1; break;
				}
				return $threadInfo;
				break;

			case 'vBulletin':
				return fetch_threadinfo($threadId);
				break;
		}
	}

	/**
	 * [getForumById description]
	 * @param  [type] $forumId [description]
	 * @return [type]          [description]
	 */
	public function getForumById($forumId)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				if (!$forumInfo = $this->createModel('XenForo_Model_Forum')->getForumById($forumId))
				{
					return [];
				}
				$forumInfo['forumid'] = $forumInfo['node_id'];
				$forumInfo['cancontainthreads'] = $forumInfo['allow_posting'];
				$forumInfo['link'] = 0;
				return $forumInfo;
				break;

			case 'vBulletin':
				return fetch_foruminfo($forumId);
				break;
		}
	}

	/**
	* Sends a PM to a specified user
	*
	* @param	mixed	The UserID or userinfo to send the PM to
	* @param	string	Title of the PM
	* @param	string	Body of the PM
	* @param	mixed	Userinfo or vBOption key to send the PM from
	*/
	public function sendPM($recipient, $title, $message, $sender = NULL, $parentPmId = NULL)
	{
		if (!is_array($recipient))
		{
			// Who's the PM to
			$recipient = $this->getUserById($recipient);
		}

		if (is_string($sender))
		{
			if ($this->option($sender))
			{
				// Who's the PM from
				$sender = $this->getUserById($this->option($sender));
			}
			else
			{
				// Null this out since we had no defined sender
				$sender = NULL;
			}
		}

		if ($sender === NULL)
		{
			// We're using the recipient
			$sender = $this->getUserInfo();
		}

		switch ($this->getSystem())
		{
			case 'XenForo':
				if ($sender['user_id'] == $recipient['user_id'])
				{
					// We can't do that
					return false;
				}

				if ($parentPmId === NULL)
				{
					$conversationDw = XenForo_DataWriter::create('XenForo_DataWriter_ConversationMaster', XenForo_DataWriter::ERROR_EXCEPTION);
					$conversationDw->setExtraData(XenForo_DataWriter_ConversationMaster::DATA_ACTION_USER, $sender);
					$conversationDw->setExtraData(XenForo_DataWriter_ConversationMaster::DATA_MESSAGE, $message);
					$conversationDw->set('user_id', $sender['user_id']);
					$conversationDw->set('username', $sender['username']);
					$conversationDw->set('title', $title);
					$conversationDw->set('open_invite', 0);
					$conversationDw->set('conversation_open', 0);
					$conversationDw->addRecipientUserIds(array($recipient['user_id']));

					$messageDw = $conversationDw->getFirstMessageDw();
					$messageDw->set('message', $message);

					$conversationDw->preSave();

					if ($conversationDw->hasErrors())
					{
						return $conversationDw->getErrors();
					}
					else
					{
						$conversationDw->save();
						$conversation = $conversationDw->getMergedData();

						if ($sender['user_id'] != $recipient['user_id'])
						{
							$this->createModel('XenForo_Model_Conversation')->markConversationAsRead(
								$conversation['conversation_id'], $sender['user_id'], $this->getTime()
							);
						}

						return $conversation['conversation_id'];
					}
				}
				else
				{
					$messageDw = XenForo_DataWriter::create('XenForo_DataWriter_ConversationMessage');
					$messageDw->setExtraData(XenForo_DataWriter_ConversationMessage::DATA_MESSAGE_SENDER, $sender);
					$messageDw->set('conversation_id', $parentPmId);
					$messageDw->set('user_id', $sender['user_id']);
					$messageDw->set('username', $sender['username']);
					$messageDw->set('message', $message);

					$messageDw->preSave();

					if ($messageDw->hasErrors())
					{
						return $messageDw->getErrors();
					}
					else
					{
						$messageDw->save();
						$message = $messageDw->getMergedData();

						$this->createModel('XenForo_Model_Conversation')->markConversationAsRead(
							$parentPmId, $sender['user_id'], $this->getTime(), 0, false
						);

						return $message['message_id'];
					}
				}
				break;

			case 'vBulletin':
				// Send pm
				$pmdm =& datamanager_init('PM', $GLOBALS['vbulletin'], ERRTYPE_ARRAY);
					$pmdm->set_info('is_automated', true); // implies overridequota
					$pmdm->set('fromuserid', 	$sender['userid']);
					$pmdm->set('fromusername', 	unhtmlspecialchars($sender['username']));
					$pmdm->set_recipients(unhtmlspecialchars($recipient['username']), $sender['permissions'], 'cc');
					$pmdm->setr('title', 		$title);
					$pmdm->setr('message', 		$message);
					$pmdm->set('dateline', 		$this->getTime());
					$pmdm->set('showsignature', 1);
					$pmdm->set('allowsmilie', 	1);
				if (!$pmdm->pre_save())
				{
					return $pmdm->errors;
				}
				else
				{
					return $pmdm->save();
				}
				break;
		}
	}

	/**
	 * [usergroupPermission description]
	 * @param  [type]     $group                 [description]
	 * @param  [type]     $permission            [description]
	 * @param  array|null &$usergroupPermissions [description]
	 * @param  array|null &$userInfo             [description]
	 * @return [type]                            [description]
	 */
	public function usergroupPermission($group, $permission, array &$usergroupPermissions = NULL, array &$userInfo = NULL)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				if (!$usergroupPermissions)
				{
					// We had no predefined forum permissions
					if (!$userInfo)
					{
						// We had no user info either, revert to default
						$usergroupPermissions = $this->getUserInfo('permissions');
					}
					else
					{
						if (!isset($userInfo['permission_combination_id']))
						{
							if (!$userInfo[$this->_getDb()->lookup('userid')])
							{
								// Guests never have permission
								return false;
							}

							// Grab user info
							$userInfo = $this->getUserById($this->_getDb()->lookup('userid'));
						}

						if (!isset($userInfo['permissions']))
						{
							$perms = $this->createModel('XenForo_Model_Permission')->rebuildPermissionCombinationById(
								$userInfo['permission_combination_id']
							);
							$userInfo['permissions'] = $perms ? $perms : [];
						}

						// Now set this
						$usergroupPermissions = $userInfo['permissions'];
					}
				}

				$retval = XenForo_Permission::hasPermission($usergroupPermissions, $group, $permission);
				return $retval === 'unset' ? false : $retval;
				break;

			case 'vBulletin':
				if (!$usergroupPermissions)
				{
					// We had no predefined forum permissions
					if (!$userInfo)
					{
						// We had no user info either, revert to default
						$usergroupPermissions = $this->getUserInfo('permissions');
					}
					else
					{
						if (!isset($userInfo['permissions']))
						{
							// Cache permissions
							cache_permissions($userInfo);
						}

						// Now set this
						$usergroupPermissions =& $userInfo['permissions'];
					}
				}

				$bit = $GLOBALS['vbulletin']->bf_ugp[$group][$permission];
				return (!$bit ? $usergroupPermissions[$group][$permission] : ($usergroupPermissions[$group] & $bit ? 1 : 0));
				break;
		}
	}

	/**
	 * [forumPermission description]
	 * @param  [type]     $forum             [description]
	 * @param  [type]     $permission        [description]
	 * @param  array|null &$forumPermissions [description]
	 * @param  array|null &$userInfo         [description]
	 * @return [type]                        [description]
	 */
	public function forumPermission($forum, $permission, array &$forumPermissions = NULL, array &$userInfo = NULL)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$forumModel = $this->createModel('XenForo_Model_Forum');
				$forumModel->standardizeViewingUserReferenceForNode($forum['node_id'], $userInfo, $forumPermissions);
				$errorPhraseKey = '';
				switch ($permission)
				{
					case 'canview':
						return $forumModel->canViewForum($forum, $errorPhraseKey, $forumPermissions, $userInfo);
						break;
					case 'canviewthreads':
						return $forumModel->canViewForumContent($forum, $errorPhraseKey, $forumPermissions, $userInfo);
						break;
					case 'canviewothers':
						return XenForo_Permission::hasContentPermission($forumPermissions, 'viewOthers');
						break;
				}
				break;

			case 'vBulletin':
				if ($forumPermissions === NULL)
				{
					// We had no predefined forum permissions
					if ($userInfo === NULL)
					{
						// We had no user info either, revert to default
						$forumPermissions =& $this->userinfo['forumpermissions'][$forum['forumid']];
					}
					else
					{
						if (!isset($userInfo['forumpermissions']))
						{
							// Cache permissions
							cache_permissions($userInfo);
						}

						// Now set this
						$forumPermissions =& $userInfo['forumpermissions'][$forum['forumid']];
					}
				}

				return ((int)$forumPermissions & (int)$GLOBALS['vbulletin']->bf_ugp_forumpermissions[$permission]);
				break;
		}
	}

	/**
	* Check if we have permissions to perform an action
	*
	* @param	array		User info
	* @param	array		Permissions info
	*/
	public function customPermission($permission, array $customPermissions, array &$userInfo = NULL)
	{
		if (!is_array($userInfo))
		{
			// We had no user info
			$userInfo = $this->getUserInfo();
		}

		if ($userInfo[$this->_getDb()->lookup('user', 'userid')])
		{
			// Store user and member group IDs
			$memberGroupIds = !empty($userInfo[$this->_getDb()->lookup('user', 'membergroupids')]) ? explode(',', str_replace(' ', '', $userInfo[$this->_getDb()->lookup('user', 'membergroupids')])) : [];
			$memberGroupIds[] = $userInfo[$this->_getDb()->lookup('user', 'usergroupid')];
			$memberGroupIds = array_unique($memberGroupIds);
		}
		else
		{
			// This was a guest
			$memberGroupIds = [1];
		}

		foreach ($memberGroupIds as $userGroupId)
		{
			$value = isset($customPermissions[$userGroupId][$permission]) ? $customPermissions[$userGroupId][$permission] : -1;

			switch ($value)
			{
				case 1:
					// Allow
					return true;
					break;

				case -1:
					// Forum Default
					//if ($this->option('dbtech_vbshout_permission_defaults_' . $permission))
					{
						// Allow by default
						return true;
					}
					break;
			}
		}

		// We didn't make it
		return false;
	}

	/**
	 * [date description]
	 * @param  [type]  $timestamp  [description]
	 * @param  [type]  $format     [description]
	 * @param  boolean $doyestoday [description]
	 * @param  boolean $locale     [description]
	 * @return [type]              [description]
	 */
	public function date($timestamp, $format = null, $doyestoday = false, $locale = true)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$format = $format == 'dateformat' ? null : $format;
				return XenForo_Locale::date($timestamp, $format);
				break;

			case 'vBulletin':
				$format = $format ? $format : 'dateformat';
				$format = isset($GLOBALS['vbulletin']->options[$format]) ? $GLOBALS['vbulletin']->options[$format] : $format;
				return vbdate($format, $timestamp, $doyestoday, $locale);
				break;
		}

	}

	/**
	 * [time description]
	 * @param  [type] $timestamp [description]
	 * @param  [type] $format    [description]
	 * @return [type]            [description]
	 */
	public function time($timestamp, $format = null)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$format = $format == 'timeformat' ? null : $format;
				return XenForo_Locale::time($timestamp, $format);
				break;

			case 'vBulletin':
				$format = $format ? $format : 'timeformat';
				$format = isset($GLOBALS['vbulletin']->options[$format]) ? $GLOBALS['vbulletin']->options[$format] : $format;
				return vbdate($format, $timestamp);
				break;
		}

	}

	/**
	 * [dateTime description]
	 * @param  [type]  $timestamp [description]
	 * @param  [type]  $format    [description]
	 * @param  boolean $logFormat [description]
	 * @return [type]             [description]
	 */
	public function dateTime($timestamp, $format = null, $logFormat = true)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$format = $format == 'logdateformat' ? 'absolute' : $format;
				return XenForo_Locale::dateTime($timestamp, $format);
				break;

			case 'vBulletin':
				if ($logFormat)
				{
					$format = $format ? $format : 'logdateformat';
					$format = isset($GLOBALS['vbulletin']->options[$format]) ? $GLOBALS['vbulletin']->options[$format] : $format;
					return vbdate($format, $timestamp);
				}
				else
				{
					return vbdate($this->option('dateformat'), $timestamp) . ' ' . vbdate($this->option('timeformat'), $timestamp);
				}
				break;
		}
	}

	/**
	 * [numberFormat description]
	 * @param  [type]  $number    [description]
	 * @param  integer $precision [description]
	 * @return [type]             [description]
	 */
	public function numberFormat($number, $precision = 0)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return XenForo_Locale::numberFormat($number, $precision);
				break;

			case 'vBulletin':
				return vb_number_format($number, $precision);
				break;
		}
	}

	/**
	 * [filter description]
	 * @param  array  $params     [description]
	 * @param  array  $sourceData [description]
	 * @return [type]             [description]
	 */
	public function filter(array $params, array $sourceData = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$request = XenForo_Application::get('fc')->getRequest();

				$paramsNew = $params;
				foreach ($params as $key => $val)
				{
					switch ($val)
					{
						case 'nohtml':
							$paramsNew[$key] = XenForo_Input::STRING;
							break;

						case 'unixtime':
							$paramsNew[$key] = is_array($request->getParam($key)) ? XenForo_Input::ARRAY_SIMPLE : XenForo_Input::DATE_TIME;
							break;
					}
				}

				if (!$this->getInput())
				{
					// Ensure this is set
					$this->setInput(new XenForo_Input(count($sourceData) ? $sourceData : $request));
				}

				$retval = $this->getInput()->filter($paramsNew);

				foreach ($params as $key => $val)
				{
					switch ($val)
					{
						case 'nohtml':
							$retval[$key] = htmlspecialchars($retval[$key]);
							break;

						case 'unixtime':
							$val = $retval[$key];
							if (is_array($val))
							{
								$val['hour'] 	= isset($val['hour']) 	? intval($val['hour']) 		: 0;
								$val['minute'] 	= isset($val['minute']) ? intval($val['minute']) 	: 0;
								$val['second'] 	= isset($val['second']) ? intval($val['second']) 	: 0;
								$val['month'] 	= isset($val['month']) 	? intval($val['month']) 	: 0;
								$val['day'] 	= isset($val['day']) 	? intval($val['day']) 		: 0;
								$val['year'] 	= isset($val['year']) 	? intval($val['year']) 		: 0;

								if ($val['month'] AND $val['day'] AND $val['year'])
								{
									$val = mktime(intval($val['hour']), intval($val['minute']), intval($val['second']), intval($val['month']), intval($val['day']), intval($val['year'])) + XenForo_Locale::getTimeZoneOffset();
								}
								else
								{
									$val = 0;
								}
							}
							else
							{
								$val = ($val = intval($val)) < 0 ? 0 : $val;
							}

							$retval[$key] = $val;
							break;
					}
				}

				return $retval;
				break;

			case 'vBulletin':
				$retval = [];

				$paramsNew = $params;
				foreach ($params as $key => $val)
				{
					switch ($val)
					{
						case 'json_array':
							$paramsNew[$key] = TYPE_NOCLEAN;
							break;
					}
				}

				$GLOBALS['vbulletin']->input->clean_array_gpc('r', $paramsNew);
				foreach ($params as $key => $val)
				{
					// Because vB doesn't like to just return the cleaned array -.-
					$retval[$key] = $GLOBALS['vbulletin']->GPC[$key];
				}


				foreach ($params as $key => $val)
				{
					switch ($val)
					{
						case 'json_array':
							if (is_string($retval[$key]))
							{
								$retval[$key] = json_decode($retval[$key], true);
							}
							if (!is_array($retval[$key]))
							{
								$retval[$key] = [];
							}
							break;
					}
				}

				return $retval;
				break;
		}
	}

	/**
	 * [filterSingle description]
	 * @param  [type] $key   [description]
	 * @param  [type] $const [description]
	 * @return [type]        [description]
	 */
	public function filterSingle($key, $const)
	{
		$cleaned = $this->filter([$key => $const]);
		return $cleaned[$key];
	}

	/**
	 * [link description]
	 * @param  [type] $action     [description]
	 * @param  array  $linkParams [description]
	 * @param  array  $linkData   [description]
	 * @return [type]             [description]
	 */
	public function link($action, array $linkParams = [], array $linkData = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$url = XenForo_Link::buildPublicLink('dbtech-shout/' . $action, $linkData, $linkParams);
				break;

			case 'vBulletin':
				$linkParams = array_merge($linkParams, $linkData);
				$url = 'vbshout.php' . ($action ? ('?do=' . $action) : '') . ($linkParams ? ($action ? '&' : '?') . http_build_query($linkParams) : '');
				break;
		}

		return $url;
	}

	/**
	 * [fullLink description]
	 * @param  [type] $action     [description]
	 * @param  array  $linkParams [description]
	 * @param  array  $linkData   [description]
	 * @return [type]             [description]
	 */
	public function fullLink($action, array $linkParams = [], array $linkData = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$url = XenForo_Link::buildPublicLink('full:dbtech-shout/' . $action, $linkData, $linkParams);
				break;

			case 'vBulletin':
				$linkParams = array_merge($linkParams, $linkData);
				$url = $GLOBALS['vbulletin']->options['bburl'] . '/vbshout.php' . ($action ? ('?do=' . $action) : '') . ($linkParams ? ($action ? '&' : '?') . http_build_query($linkParams) : '');
				break;
		}

		return $url;
	}

	/**
	 * [profileLink description]
	 * @param  [type] $user [description]
	 * @return [type]       [description]
	 */
	public function profileLink($user)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return XenForo_Link::buildPublicLink('members', $user);
				break;

			case 'vBulletin':
				return 'member.php?u=' . $user['userid'];
				break;
		}
	}

	/**
	 * [downloadFile description]
	 * @param  [type] $output   [description]
	 * @param  [type] $fileName [description]
	 * @param  [type] $mimeType [description]
	 * @return [type]           [description]
	 */
	public function downloadFile($output, $fileName, $mimeType)
	{
		XenForo_Application::get('fc')->getResponse()->setHeader('Content-type', $mimeType, true);
		XenForo_Application::get('fc')->getResponse()->setHeader('Content-Disposition', 'attachment; filename="' . str_replace('"', '', $fileName) . '"', true);
		XenForo_Application::get('fc')->getResponse()->sendHeaders();
		echo $output;
		die();
	}

	/**
	 * [fetchBitfield description]
	 * @param  [type] $bitfield [description]
	 * @return [type]           [description]
	 */
	public function fetchBitfield($bitfield)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				// Parse CPNav file
				$document = XenForo_Helper_DevelopmentXml::scanFile(XenForo_Application::getInstance()->getRootDir() . '/includes/xml/bitfield_dbtech_vbshout.xml');

				$keys = preg_split('#\|#si', $bitfield, -1, PREG_SPLIT_NO_EMPTY);

				$retval = [];
				foreach ($document->xpath("//group[@name='" . $keys[0] . "']/group[@name='" . $keys[1] . "']/bitfield") as $bitfield)
				{
					$retval[(string)$bitfield['name']] = (int)$bitfield[0];
				}

				return $retval ? $retval : NULL;
				break;

			case 'vBulletin':
				// Ensure we can fetch bitfields
				require_once(DIR . '/includes/adminfunctions_options.php');
				return fetch_bitfield_definitions($bitfield);
				break;
		}
	}

	/**
	 * [isMemberOf description]
	 * @param  array   $user        [description]
	 * @param  [type]  $userGroupId [description]
	 * @param  [type]  $multipleIds [description]
	 * @return boolean              [description]
	 */
	public function isMemberOf(array $user, $userGroupId, $multipleIds = null)
	{
		if (!is_null($multipleIds))
		{
			// check multiple groups
			$userGroupId = array_slice(func_get_args(), 1);
		}

		switch ($this->getSystem())
		{
			case 'XenForo':
				return $this->createModel('XenForo_Model_User')->isMemberOfUserGroup($user, $userGroupId);
				break;

			case 'vBulletin':
				return is_member_of($user, $userGroupId);
				break;
		}
	}

	/**
	 * [stripBbCode description]
	 * @param  [type]  $string         [description]
	 * @param  boolean $stripQuotes    [description]
	 * @param  boolean $fast_and_dirty [description]
	 * @param  boolean $showlinks      [description]
	 * @param  boolean $stripimg       [description]
	 * @param  boolean $keepquotetags  [description]
	 * @return [type]                  [description]
	 */
	public function stripBbCode($string, $stripQuotes = false, $fast_and_dirty = false, $showlinks = true, $stripimg = false, $keepquotetags = false)
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				return XenForo_Helper_String::bbCodeStrip($string, $stripQuotes);
				break;

			case 'vBulletin':
				return strip_bbcode($string, $stripQuotes, $fast_and_dirty, $showlinks, $stripimg, $keepquotetags);
				break;
		}
	}

	/**
	 * [parseBbCode description]
	 * @param  [type] $string  [description]
	 * @param  array  $options [description]
	 * @return [type]          [description]
	 */
	public function parseBbCode($string, array $options = [])
	{
		// Store the unparsed string also
		$string = trim($string);

		switch ($this->getSystem())
		{
			case 'XenForo':
				// Convert URLs to links
				$string = XenForo_Helper_String::autoLinkBbCode($string);

				// Setup formatter
				$formatter = XenForo_BbCode_Formatter_Base::create('XenForo_BbCode_Formatter_Base');
				$parser = XenForo_BbCode_Parser::create($formatter);

				// parse BBCode
				$string = $parser->render($string);
				break;

			case 'vBulletin':
				// Ensure we got BBCode Parser
				require_once(DIR . '/includes/class_bbcode.php');
				if (!function_exists('convert_url_to_bbcode'))
				{
					require_once(DIR . '/includes/functions_newpost.php');
				}

				// Initialise the parser (use proper BBCode)
				$parser = new vB_BbCodeParser($GLOBALS['vbulletin'], fetch_tag_list());

				if ($this->option('allowedbbcodes') & 64)
				{
					// We can use the URL BBCode, so convert links
					$string = convert_url_to_bbcode($string);
				}

				// BBCode parsing
				$string = $parser->parse($string, 'nonforum');

				break;
		}

		return $string;
	}

	/**
	 * Determines the path to jQuery based on browser settings
	 * @return [type] [description]
	 */
	public function jQueryPath()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				// XenForo already has jQuery built in
				return '';
				break;

			case 'vBulletin':
				// create the path to jQuery depending on the version
				if ($this->option('customjquery_path'))
				{
					$path = str_replace('{version}', self::$jQueryVersion, $this->option('customjquery_path'));
					if (!preg_match('#^https?://#si', $this->option('customjquery_path')))
					{
						$path = REQ_PROTOCOL . '://' . $path;
					}
					return $path;
				}
				else
				{
					switch ($this->option('remotejquery'))
					{
						case 1:
						default:
							// Google CDN
							return REQ_PROTOCOL . '://ajax.googleapis.com/ajax/libs/jquery/' . self::$jQueryVersion . '/jquery.min.js';
							break;

						case 2:
							// jQuery CDN
							return REQ_PROTOCOL . '://code.jquery.com/jquery-' . self::$jQueryVersion . '.min.js';
							break;

						case 3:
							// Microsoft CDN
							return REQ_PROTOCOL . '://ajax.aspnetcdn.com/ajax/jquery/jquery-' . self::$jQueryVersion . '.min.js';
							break;
					}
				}
				break;
		}
	}

	/**
	* Escapes a string and makes it JavaScript-safe
	*
	* @param	mixed	The string or array to make JS-safe
	*/
	public function jsEscapeString(&$arr)
	{
		$find = [
			"\r\n",
			"\n",
			"\t",
			'"'
		];

		$replace = [
			'\r\n',
			'\n',
			'\t',
			'\"',
		];

		$arr = str_replace($find, $replace, $arr);
	}

	/**
	* Encodes a string as a JSON object (consistent behaviour instead of relying on PHP built-in functions)
	*
	* @param	mixed	The string or array to encode
	* @param	boolean	(Optional) Whether this is an associative array
	* @param	boolean	(Optional) Whether we should escape the string or if they have already been escaped
	*/
	public function encodeJSON($arr, $assoc = true, $doescape = true)
	{
		if ($doescape)
		{
			$this->jsEscapeString($arr);
		}
		if (!$assoc)
		{
			// Not associative, simple return
			return '{"' . implode('","', $arr) . '"}';
		}

		$content = [];
		foreach ((array)$arr as $key => $val)
		{
			if (is_array($val))
			{
				// Recursion, definition: see recursion
				$val = $this->encodeJSON($val);
				$content[] = '"' . $key . '":' . $val;
			}
			else
			{
				$content[] = '"' . $key . '":"' . $val . '"';
			}
		}

		return '{' . implode(',', $content) . '}';
	}

	/**
	* Outputs a JSON string to the browser
	*
	* @param	mixed	array to output
	*/
	public function outputJSON($json, $full_shutdown = false)
	{
		if (headers_sent($file, $line))
		{
			die("Cannot send response, headers already sent. File: $file Line: $line");
		}

		switch ($this->getSystem())
		{
			// XenForo is UTF-8 by default
			case 'vBulletin':
				// Init this, we don't need this code for XF
				$charsetApp = DBTech_Shout_Application_Charset::getInstance();

				// Store the charset
				$charset = strtoupper($charsetApp->getCharset());

				// We need to convert $json charset if we're not using UTF-8
				if ($charset != 'UTF-8')
				{
					$json = $charsetApp->toCharset($json, $charset, 'UTF-8');
				}
				break;
		}

		//If this is IE9, IE10, or IE11 -- we also need to work around the deliberate attempt to break "is IE" logic by the
		//IE dev team -- we need to send type "text/plain". Yes, we know that's not the standard.
		if (
			isset($_SERVER['HTTP_USER_AGENT']) && (
				(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false) OR
				(strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== false)
			)
		)
		{
			header('Content-type: text/plain; charset=UTF-8');
		}
		else
		{
			header('Content-type: application/json; charset=UTF-8');
		}

		// IE will cache ajax requests, and we need to prevent this - VBV-148
		header('Cache-Control: max-age=0,no-cache,no-store,post-check=0,pre-check=0');
		header('Expires: Sat, 1 Jan 2000 01:00:00 GMT');
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Pragma: no-cache");

		// Create JSON
		$json = $this->encodeJSON($json);

		switch ($this->getSystem())
		{
			case 'XenForo':
				// Not sure if we need something here yet.
				break;

			case 'vBulletin':
				// Turn off debug output
				$GLOBALS['vbulletin']->debug = false;

				if (defined('VB_API') AND VB_API === true)
				{
					print_output($json);
				}

				//run any registered shutdown functions
				if (intval($GLOBALS['vbulletin']->versionnumber) > 3)
				{
					$GLOBALS['vbulletin']->shutdown->shutdown();
				}
				exec_shut_down();
				$GLOBALS['vbulletin']->db->close();

				$sendHeader = false;
				switch($this->option('ajaxheader'))
				{
					case 0:
						$sendHeader = true;

					case 1:
						$sendHeader = false;

					case 2:
					default:
						$sendHeader = (strpos($_SERVER['SERVER_SOFTWARE'], 'Microsoft-IIS') !== false);
				}

				if ($sendHeader)
				{
					// this line is causing problems with mod_gzip/deflate, but is needed for some IIS setups
					@header('Content-Length: ' . strlen($json));
				}
				break;
		}

		// Finally spit out JSON
		echo $json;
		die();
	}

	/**
	 * [createModel description]
	 * @param  [type] $class [description]
	 * @return [type]        [description]
	 */
	public function createModel($class)
	{
		if (!isset($this->_modelCache[$class]))
		{
			$this->_modelCache[$class] = XenForo_Model::create($class);
		}

		return $this->_modelCache[$class];
	}

	/**
	 * [_getActionClassName description]
	 * @param  [type] $class [description]
	 * @return [type]        [description]
	 */
	protected function _getActionClassName($class)
	{
		

		return 'DBTech_Shout_Action_' . ucfirst($class);
	}

	/**
	 * [traceHtml description]
	 * @param  [type] $e [description]
	 * @return [type]    [description]
	 */
	protected function traceHtml($e)
	{
		$traceHtml = '';

		if (isset($e) && $e instanceof Exception)
		{
			$error = $e->getMessage();
			$cwd = str_replace('\\', '/', getcwd());

			foreach ($e->getTrace() AS $traceEntry)
			{
				$function = (isset($traceEntry['class']) ? $traceEntry['class'] . $traceEntry['type'] : '') . $traceEntry['function'];
				if (isset($traceEntry['file']))
				{
					$file = str_replace("$cwd/library/", '', str_replace('\\', '/', $traceEntry['file']));
				}
				else
				{
					$file = '';
				}
				$traceHtml .= "\t<li><b class=\"function\">" . htmlspecialchars($function) . "()</b>" . (isset($traceEntry['file']) && isset($traceEntry['line']) ? ' <span class="shade">in</span> <b class="file">' . $file . "</b> <span class=\"shade\">at line</span> <b class=\"line\">$traceEntry[line]</b>" : '') . "</li>\n";
			}
		}
		else
		{
			$error = '';
		}

		return [
			'error' => htmlspecialchars($error),
			'traceHtml' => $traceHtml
		];
	}

	/**
	 * [setController description]
	 * @param [type] $controller [description]
	 */
	public function setController($controller)
	{
		$this->_controller = $controller;
	}

	/**
	 * [getController description]
	 * @return [type] [description]
	 */
	public function getController()
	{
		return $this->_controller;
	}

	/**
	 * [setInput description]
	 * @param [type] $input [description]
	 */
	public function setInput($input)
	{
		$this->_input = $input;
	}

	/**
	 * [getInput description]
	 * @return [type] [description]
	 */
	public function getInput()
	{
		return $this->_input;
	}

	/**
	 * Gets the specified action object from the cache. If it does not exist,
	 * it will be instantiated.
	 *
	 * @param string $class Name of the class to load
	 *
	 * @return XenForo_Model
	 */
	public static function getActionFromCache($class)
	{
		if (!isset(self::$_actionCache[$class]))
		{
			self::$_actionCache[$class] = self::create($class);
		}

		return self::$_actionCache[$class];
	}

	/**
	 * [_getTemplate description]
	 * @return [type] [description]
	 */
	public function _getTemplate()
	{
		return DBTech_Shout_Application_Template::getInstance();
	}

	/**
	 * [_getDb description]
	 * @return [type] [description]
	 */
	public function _getDb()
	{
		if (!$this->db)
		{
			switch ($this->getSystem())
			{
				case 'XenForo':
					// Init DB
					$this->db = new DBTech_Shout_Application_Database(XenForo_Application::getDb());
					break;

				case 'vBulletin':
					$this->db = new DBTech_Shout_Application_Database($GLOBALS['vbulletin']->db);
					break;
			}
		}

		return $this->db;
	}

	/**
	* Factory method to get the named action. The class must exist or be autoloadable
	* or an exception will be thrown.
	*
	* @param string     $class Class to load
	*
	* @throws Exception
	*
	* @return mixed
	*/
	public static function create($class)
	{
		$app = static::getInstance();
		switch ($app->getSystem())
		{
			case 'XenForo':
				$createClass = XenForo_Application::resolveDynamicClass($class, '');

				if (!$createClass)
				{
					throw new Exception("Invalid action class '$class' specified");
				}
				break;

			case 'vBulletin':
				// Simple
				$createClass = $class;

				if (!$createClass OR !class_exists($class))
				{
					throw new Exception("Invalid action class '$class' specified");
				}
				break;
		}

		return new $createClass();
	}

	/**
	 * [getInstance description]
	 * @return [type] [description]
	 */
	public static final function getInstance()
	{
		if (!self::$_instance)
		{
			self::$_instance = new static();
		}

		return self::$_instance;
	}

	/**
	 * [destroyInstance description]
	 * @return [type] [description]
	 */
	public static final function destroyInstance()
	{
		if (self::$_instance)
		{
			self::$_instance = NULL;
		}
	}
}
?>