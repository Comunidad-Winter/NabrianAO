<?php
class DBTech_Shout_Action_Ajax_Styleprops extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 128))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter(array(
			'editor' 		=> TYPE_ARRAY,
		));

		// Set shout styles array
		$cleanedInput['editor']['color'] = preg_replace('/[^A-Za-z0-9 #(),]/', '', $cleanedInput['editor']['color']);
		$this->shoutbox->shoutstyle[$instance['instanceid']] = $cleanedInput['editor'];

		// Update the user's editor styles
		$this->_getDb()->update('user', array(
			'dbtech_vbshout_shoutstyle' => trim(serialize($this->shoutbox->shoutstyle))
		), '=user:userid= = ' . intval($this->app->getUserInfo('userid')));

		// Set the AOP
		$this->shoutbox->setAop('shouts', $instance['instanceid'], false, true);

		// Fetch the shouts again
		$this->shoutbox->fetchShouts($instance, $chatroom, $args);
	}
}