<?php
class DBTech_Shout_Action_Main extends DBTech_Shout_Action
{
}
?>