<?php
class DBTech_Shout_Cache extends DBTech_Shout_Application_Cache
{
	/**
	* Array of DB table joins / other commands
	*
	* @protected	array
	*/
	protected $_tables		= [
		'button'			=> '',
		'chatroom' 			=> '',
		'command' 			=> 'ORDER BY `command` ASC',
		'instance'			=> 'ORDER BY `displayorder` ASC',
	];

	/**
	* Array of defaults
	*
	* @protected	array
	*/
	protected $_defaults	= [
		'button' => [
			'title' 			=> 'Example Button',
			'active' 			=> 1,
			'image' 			=> '',
			'link' 				=> '',
			'instanceid' 		=> 0,
		],
		'chatroom' => [
			'title' 			=> 'Example Chatroom',
			'description' 		=> 'Example chatroom description.',
			'active' 			=> 1,
			'image' 			=> '',
			'membergroupids' 	=> '-1',
			'instanceid' 		=> 0,
			'autojoin' 			=> 1,
		],
		'command' => [
			'command' 			=> '/example',
			'output' 			=> 'This is an example!',
			'useinput' 			=> 0,
		],
		'instance' => [
			'varname' 			=> 'shoutbox',
			'name' 				=> 'Shoutbox',
			'description' 		=> 'A shoutbox instance.',
			'active' 			=> 1,
			'displayorder' 		=> 10,
			'sticky_raw' 		=> 'The default sticky note.',
			'autodisplay'		=> 1,
			'options'			=> [],
		]
	];

	/**
	* Array of callbacks
	*
	* @protected	array
	*/
	protected $_loadCallbacks		= [
		'instance'			=> '_loadInstanceData',
	];

	/**
	* Array of cached items
	*
	* @public	array
	*/
	public $unserialize		= [
		'chatroom' => [
			'members',
		],
		'instance' => [
			'permissions',
			'bbcodepermissions',
			'notices',
			'options',
			'forumids',
		],
	];

	/**
	* Array of items to NOT fetch
	*
	* @protected	array
	*/
	protected $_idColumns	= [];


	protected static function _loadInstanceData(&$data)
	{
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();
		foreach ($data as $instanceid => $instance)
		{
			// Load default options
			$shoutbox->loadDefaultInstanceOptions($data[$instanceid]);

			// Load instance permissions
			$shoutbox->loadInstancePermissions($data[$instanceid]);

			// Load instance permissions
			$shoutbox->loadInstanceBbcodePermissions($data[$instanceid]);
		}
	}
}