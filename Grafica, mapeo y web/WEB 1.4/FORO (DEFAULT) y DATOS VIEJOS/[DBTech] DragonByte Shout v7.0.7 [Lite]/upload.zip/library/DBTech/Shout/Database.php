<?php
class DBTech_Shout_Database extends DBTech_Shout_Application_Database
{
}
?>