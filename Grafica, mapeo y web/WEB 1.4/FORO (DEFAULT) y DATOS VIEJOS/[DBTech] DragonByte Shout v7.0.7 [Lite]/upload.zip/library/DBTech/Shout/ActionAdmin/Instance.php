<?php
class DBTech_Shout_ActionAdmin_Instance extends DBTech_Shout_ActionAdmin
{
	// Store the bitfield defs we need
	protected $bitfields = array(
		'logging' 			=> 'nocache|dbtech_vbshout_commands',
		'editors' 			=> 'nocache|dbtech_vbshout_editors',
		'notices' 			=> 'nocache|dbtech_vbshout_notices',
		'shoutboxtabs' 		=> 'nocache|dbtech_vbshout_shoutboxtabs',
		
	);

	// #############################################################################
	public function actionIndex()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$displays = array(
			0 => $this->app->phrase('disabled'),
			1 => $this->app->phrase('dbtech_vbshout_after_navbar'),
			2 => $this->app->phrase('dbtech_vbshout_above_footer')
		);

		print_cp_header($this->app->phrase('dbtech_vbshout_instance_management'));

//		print_table_start();
//		print_table_header($this->app->phrase('dbtech_vbshout_additional_functions'));
//		print_description_row("<b>
//			<a href=\"" . $this->app->link('instance', array('action' => 'permissions')) . "\">" . $this->app->phrase('dbtech_vbshout_view_instance_permissions') . "</a>"
			
//		. "</b>", 0, 2, '', 'center');
//		print_table_footer();

		// Table header
		$headings = array();
		$headings[] = $this->app->phrase('dbtech_vbshout_varname_short');
		$headings[] = $this->app->phrase('title');
		//$headings[] = $this->app->phrase('description');
		$headings[] = $this->app->phrase('dbtech_vbshout_active');
		$headings[] = $this->app->phrase('display_order');
		//$headings[] = $this->app->phrase('dbtech_vbshout_sticky');
		$headings[] = $this->app->phrase('dbtech_vbshout_auto_display');
		$headings[] = $this->app->phrase('edit');
		$headings[] = $this->app->phrase('delete');

		if (count($instanceCache))
		{
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'mass-update');
			print_table_header($this->app->phrase('dbtech_vbshout_instance_management'), count($headings), false, '', 'center', false);

			print_cells_row($headings, true);
			foreach ($instanceCache as $instanceid => $instance)
			{
				// Table data
				$cell = array();
				$cell[] = $instance['varname'];
				$cell[] = $instance['name'];
				//$cell[] = $instance['description'];
				$cell[] = construct_checkbox_code("instance[$instanceid][active]", $instance['active'], $this->app->phrase('dbtech_vbshout_active'));
				$cell[] = "<input type=\"text\" class=\"bginput textCtrl\" name=\"instance[$instanceid][displayorder]\" value=\"$instance[displayorder]\" tabindex=\"1\" size=\"3\" title=\"" . $this->app->phrase('edit_display_order') . "\" />";
				//$cell[] = $instance['sticky'];
				$cell[] = $displays[$instance['autodisplay']];
				$cell[] = construct_link_code($this->app->phrase('edit'), $this->app->link('instance', array('action' => 'modify', 'instanceid' => $instanceid)));
				$cell[] = ($instanceid != 1 ? construct_link_code($this->app->phrase('delete'), $this->app->link('instance', array('action' => 'delete', 'instanceid' => $instanceid)), false, '', true) : '[N/A]');

				// Print the data
				print_cells_row($cell, false, false, -5, 'middle', false, true);
			}
			print_cells_row(false);
			print_submit_row($this->app->phrase('save'), false, count($headings), false, construct_button_code($this->app->phrase('dbtech_vbshout_add_new_instance'), $this->app->link('instance', array('action' => 'modify'))));
		}
		else
		{
			print_table_start();
			print_table_header($this->app->phrase('dbtech_vbshout_instance_management'), count($headings));
			print_description_row($this->app->phrase('dbtech_vbshout_no_instances'), false, count($headings));
			print_table_footer(count($headings), construct_button_code($this->app->phrase('dbtech_vbshout_add_new_instance'), $this->app->link('instance', array('action' => 'modify'))));
		}
	}

	// #############################################################################
	public function actionModify()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'instanceid' => TYPE_UINT,
		));

		$instanceid = $cleanedInput['instanceid'];
		$instance = ($instanceid ? $instanceCache[$instanceid] : false);

		if (!is_array($instance))
		{
			// Non-existing instance
			$instanceid = 0;
		}

		$permissions = array();
		$bbcodepermissions = array();

		foreach ($this->app->getUserGroupCache() as $usergroupid => $usergroup)
		{
			$bit = 10300;
			$bit2 = 67;
			if ($this->app->getSystem() == 'vBulletin')
			{
				if ($usergroup['adminpermissions'] & $vbulletin->bf_ugp_adminpermissions['cancontrolpanel'])
				{
					// Admin
					$bit = 61436;
				}
				else if ($usergroup['adminpermissions'] & $vbulletin->bf_ugp_adminpermissions['ismoderator'])
				{
					// SMod
					$bit = 61436;
				}
				else if ($usergroupid == 5)
				{
					$bit = 61308;
				}
				else if (!($usergroup['genericoptions'] & $vbulletin->bf_ugp_genericoptions['isnotbannedgroup']) OR in_array($usergroupid, array(1, 3, 4)))
				{
					// Banned, guest, email conf, COPPA
					$bit 	= 0;
					$bit2 	= 0;
				}
			}

			$permissions[$usergroupid] 			= $bit;
			$bbcodepermissions[$usergroupid] 	= $bit2;
		}


		$displays = array(
			0 => $this->app->phrase('disabled'),
			1 => $this->app->phrase('dbtech_vbshout_after_navbar'),
			2 => $this->app->phrase('dbtech_vbshout_above_footer'),
		);

		$hasSuhosin = false;
		if (extension_loaded('suhosin') AND (ini_get('suhosin.post.max_vars') > 0) AND (ini_get('suhosin.post.max_vars') < 2048))
		{
			$hasSuhosin = '
				You appear to have <strong>Suhosin</strong> installed on your server and configured to be too restrictive for DragonByte Shout to work correctly.<br />
				<br />
				Please note that if you have a large number of usergroups, certain parts of this page may not work as intended.<br />
				<br />
				If you encounter this issue, you can work around this by adding the following code to your .htaccess file:<br />
				<br />
	<pre>php_flag suhosin.cookie.encrypt Off
	php_value suhosin.request.max_vars 2048
	php_value suhosin.get.max_vars 2048
	php_value suhosin.post.max_vars 2048</pre>';
		}

		if (version_compare(PHP_VERSION, '5.3.9') >= 0 AND ini_get('max_input_vars') < 10000)
		{
			$hasSuhosin = '
				You appear to have <strong>PHP 5.3.9</strong> or higher installed on your server and configured to be too restrictive for DragonByte Shout to work correctly.<br />
				<br />
				Please note that if you have a large number of usergroups, certain parts of this page may not work as intended.<br />
				<br />
				If you encounter this issue, you may be able to work around this by adding the following code to your .htaccess file:<br />
				<br />
	<pre>php_value max_input_vars 10000</pre>
				<br />
				or altering your php.ini file to increase max_input_vars to 10000.';
		}

		if ($instanceid)
		{
			// Shorthand
			$titlePhrase = $this->app->phrase('dbtech_vbshout_editing_x_y', ['param1' => $this->app->phrase('dbtech_vbshout_instance'), 'param2' => '%s']);
			$titlePhraseParsed = $this->app->phrase('dbtech_vbshout_editing_x_y', ['param1' => $this->app->phrase('dbtech_vbshout_instance'), 'param2' => $instance['name']]);

			// Edit
			print_cp_header(strip_tags($titlePhraseParsed));
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'update');
			construct_hidden_code('instanceid', $instanceid);
			if ($hasSuhosin)
			{
				print_notice_row($hasSuhosin);
			}
			print_table_header($titlePhraseParsed, 2, false, ' ', 'center', false);
		}
		else
		{
			// Shorthand
			$titlePhrase = $this->app->phrase('dbtech_vbshout_add_new_instance') . ': <em>%s</em>';
			$titlePhraseParsed = $this->app->phrase('dbtech_vbshout_add_new_instance');

			// Add
			print_cp_header($titlePhraseParsed);
			print_form_header('vbshout', 'instance');
			construct_hidden_code('action', 'update');
			if ($hasSuhosin)
			{
				print_notice_row($hasSuhosin);
			}
			print_table_header($titlePhraseParsed, 2, false, ' ', 'center', false);

			// Used for programmatically set defaults
			$defaults = [
				'permissions'		=> $permissions,
				'bbcodepermissions'	=> $bbcodepermissions,
			];

			// Load defaults from cache
			$instance = $this->cache->loadDefaults('instance', $defaults);
		}

		// Ensure we always have the default options
		DBTech_Shout_Shoutbox::getInstance()->loadDefaultInstanceOptions($instance);

		print_description_row($this->app->phrase('dbtech_vbshout_main_settings'), false, 2, 'optiontitle');
		if ($instanceid)
		{
			print_label_row($this->app->phrase('dbtech_vbshout_varname'), 																										$instance['varname']);
		}
		else
		{
			print_input_row($this->app->phrase('dbtech_vbshout_varname'), 						'instance[varname]', 																$instance['varname']);
		}
		print_title_row($this->app->phrase('title'), 											'instance[name]', 																	$instance['name'], 			$titlePhrase);
		print_textarea_row($this->app->phrase('description'),									'instance[description]',															$instance['description']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_active'),							'instance[active]',																	$instance['active']);
		print_input_row($this->app->phrase('display_order'),									'instance[displayorder]',															$instance['displayorder']);
		print_textarea_row($this->app->phrase('dbtech_vbshout_sticky'),							'instance[sticky_raw]',																$instance['sticky_raw']);
		print_description_row($this->app->phrase('dbtech_vbshout_display_settings'), false, 2, 'optiontitle');
		print_select_row($this->app->phrase('dbtech_vbshout_auto_display_descr'),				'instance[autodisplay]', 					$displays, 								$instance['autodisplay']);
		print_description_row($this->app->phrase('dbtech_vbshout_sound_settings'), false, 2, 'optiontitle');
		print_yes_no_row($this->app->phrase('dbtech_vbshout_enable_shout_sound'),				'instance[options][enableshoutsound]', 												$instance['options']['enableshoutsound']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_enable_invite_sound'),				'instance[options][enableinvitesound]', 											$instance['options']['enableinvitesound']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_enable_pm_sound'),					'instance[options][enablepmsound]', 												$instance['options']['enablepmsound']);
		print_description_row($this->app->phrase('options'), false, 2, 'optiontitle');
		print_bitfield_row($this->app->phrase('dbtech_vbshout_logging_descr'), 					'instance[options][logging]', 				$this->bitfields['logging'], 			$instance['options']['logging']);
		print_bitfield_row($this->app->phrase('dbtech_vbshout_editors_descr'), 					'instance[options][editors]', 				$this->bitfields['editors'], 			$instance['options']['editors']);
		print_bitfield_row($this->app->phrase('dbtech_vbshout_notices_descr'), 					'instance[options][notices]', 				$this->bitfields['notices'], 			$instance['options']['notices']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_optimisation_descr'), 				'instance[options][optimisation]', 													$instance['options']['optimisation']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_allowsmilies_descr'), 				'instance[options][allowsmilies]', 													$instance['options']['allowsmilies']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_activeusers_descr'), 				'instance[options][activeusers]', 													$instance['options']['activeusers']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_sounds_descr'), 					'instance[options][sounds]', 														$instance['options']['sounds']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_altshouts_descr'), 					'instance[options][altshouts]', 													$instance['options']['altshouts']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_enableaccess_descr'), 				'instance[options][enableaccess]', 													$instance['options']['enableaccess']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_anonymise_descr'), 					'instance[options][anonymise]', 													$instance['options']['anonymise']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_allcaps_descr'), 					'instance[options][allcaps]', 														$instance['options']['allcaps']);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_invis_descr'), 						'instance[options][invis]', 														$instance['options']['invis']);
		print_input_row($this->app->phrase('dbtech_vbshout_maxshouts_descr'), 					'instance[options][maxshouts]', 													$instance['options']['maxshouts']);
		print_input_row($this->app->phrase('dbtech_vbshout_maxarchiveshouts_descr'), 			'instance[options][maxarchiveshouts]', 												$instance['options']['maxarchiveshouts']);
		print_input_row($this->app->phrase('dbtech_vbshout_height_descr'), 						'instance[options][height]', 														$instance['options']['height']);
		print_input_row($this->app->phrase('dbtech_vbshout_floodchecktime_descr'), 				'instance[options][floodchecktime]', 												$instance['options']['floodchecktime']);
		print_input_row($this->app->phrase('dbtech_vbshout_maxchars_descr'), 					'instance[options][maxchars]', 														$instance['options']['maxchars']);
		print_input_row($this->app->phrase('dbtech_vbshout_maximages_descr'), 					'instance[options][maximages]', 													$instance['options']['maximages']);
		print_input_row($this->app->phrase('dbtech_vbshout_idletimeout_descr'), 				'instance[options][idletimeout]', 													$instance['options']['idletimeout']);
		print_input_row($this->app->phrase('dbtech_vbshout_refresh_descr'), 					'instance[options][refresh]', 														$instance['options']['refresh']);
		print_input_row($this->app->phrase('dbtech_vbshout_maxchats_descr'), 					'instance[options][maxchats]', 														$instance['options']['maxchats']);
		print_select_row($this->app->phrase('dbtech_vbshout_shoutarea_descr'),					'instance[options][shoutarea]', 			array(
																											'above' => $this->app->phrase('dbtech_vbshout_above_shouts'),
																											'below' => $this->app->phrase('dbtech_vbshout_below_shouts'),
																										),																					$instance['options']['shoutarea']);
		print_select_row($this->app->phrase('dbtech_vbshout_shoutorder_descr'),					'instance[options][shoutorder]', 			array(
																											'DESC' 	=> $this->app->phrase('dbtech_vbshout_newest_first'),
																											'ASC' 	=> $this->app->phrase('dbtech_vbshout_oldest_first')
																										),																					$instance['options']['shoutorder']);
		print_select_row($this->app->phrase('dbtech_vbshout_maxsize_descr'),					'instance[options][maxsize]', 				array(
																											3 => 3,
																											4 => 4,
																											5 => 5,
																											6 => 6,
																											7 => 7
																										),																					$instance['options']['maxsize']);
		print_description_row($this->app->phrase('dbtech_vbshout_forum_milestones'), false, 2, 'optiontitle');
		print_input_row($this->app->phrase('dbtech_vbshout_postping_interval_descr'), 			'instance[options][postping_interval]', 											$instance['options']['postping_interval']);
		print_input_row($this->app->phrase('dbtech_vbshout_threadping_interval_descr'), 		'instance[options][threadping_interval]', 											$instance['options']['threadping_interval']);
		print_input_row($this->app->phrase('dbtech_vbshout_memberping_interval_descr'), 		'instance[options][memberping_interval]', 											$instance['options']['memberping_interval']);

		

		if ($hasSuhosin)
		{
			print_submit_row(($instanceid ? $this->app->phrase('save') : $this->app->phrase('dbtech_vbshout_add_new_instance')), false);
		}
		else
		{
			print_table_break();
		}

		if ($instanceid OR !$hasSuhosin)
		{
			// Bitfields
			$permissions = $this->app->fetchBitfield('nocache|dbtech_vbshoutpermissions');

			// Table header
			$headings = array();
			$headings[] = $this->app->phrase('dbtech_vbshout_usergroup');
			foreach ((array)$permissions as $permissionname => $bit)
			{
				$headings[] = $this->app->phrase("dbtech_vbshout_permission_{$permissionname}");
			}

			if ($hasSuhosin)
			{
				print_form_header('vbshout', 'instance');
				construct_hidden_code('action', 'updateinstancepermissions');
				construct_hidden_code('instanceid', $instanceid);
			}
			print_table_header($this->app->phrase('dbtech_vbshout_instance_permissions'), count($headings));
			print_cells_row($headings, true);

			foreach ($this->app->getUserGroupCache() as $usergroupid => $usergroup)
			{
				// Table data
				$cell = array();
				$cell[] = $usergroup['title'];
				foreach ((array)$permissions as $permissionname => $bit)
				{
					$cell[] = '<center>
						<input type="hidden" name="permissions[' . $usergroupid . '][' . $permissionname . ']" value="0" />
						<input type="checkbox" name="permissions[' . $usergroupid . '][' . $permissionname . ']" value="1"' . ((isset($instance['permissions'][$usergroupid]) AND ($instance['permissions'][$usergroupid] & $bit)) ? ' checked="checked"' : '') . ' title="name=&quot;permissions[' . $usergroupid . '][' . $permissionname . ']&quot;"' . '/>
					</center>';
				}

				// Print the data
				print_cells_row($cell, false, false, -5, 'middle', false, true);
			}
			print_cells_row(false);
			if ($hasSuhosin)
			{
				print_submit_row(($instanceid ? $this->app->phrase('save') : $this->app->phrase('dbtech_vbshout_add_new_instance')), false, count($headings));
			}
			else
			{
				print_table_break();
			}

			if ($this->app->getSystem() == 'vBulletin')
			{
				// Bitfields
				$permissions = $this->app->fetchBitfield('nocache|allowedbbcodesfull');

				// Table header
				$headings = array();
				$headings[] = $this->app->phrase('dbtech_vbshout_usergroup');
				foreach ((array)$permissions as $permissionname => $bit)
				{
					$headings[] = $this->app->phrase($permissionname);
				}

				if ($hasSuhosin)
				{
					print_form_header('vbshout', 'instance');
					construct_hidden_code('action', 'updatebbcodepermissions');
					construct_hidden_code('instanceid', $instanceid);
				}
				print_table_header($this->app->phrase('dbtech_vbshout_bbcode_permissions'), count($headings));
				print_cells_row($headings, true);

				foreach ($this->app->getUserGroupCache() as $usergroupid => $usergroup)
				{
					// Table data
					$cell = array();
					$cell[] = $usergroup['title'];
					foreach ((array)$permissions as $permissionname => $bit)
					{
						$cell[] = '<center>
							<input type="hidden" name="bbcodepermissions[' . $usergroupid . '][' . $permissionname . ']" value="0" />
							<input type="checkbox" name="bbcodepermissions[' . $usergroupid . '][' . $permissionname . ']" value="1"' . ($instance['bbcodepermissions'][$usergroupid] & $bit ? ' checked="checked"' : '') . ' title="name=&quot;bbcodepermissions[' . $usergroupid . '][' . $permissionname . ']&quot;"' . '/>
						</center>';
					}

					// Print the data
					print_cells_row($cell, false, false, -5, 'middle', false, true);
				}
				print_cells_row(false);
				if ($hasSuhosin)
				{
					print_submit_row(($instanceid ? $this->app->phrase('save') : $this->app->phrase('dbtech_vbshout_add_new_instance')), false, count($headings));
				}
				else
				{
					print_table_break();
				}
			}
		}

		if (!$hasSuhosin)
		{
			print_submit_row(($instanceid ? $this->app->phrase('save') : $this->app->phrase('dbtech_vbshout_add_new_instance')), false);
		}
	}

	// #############################################################################
	public function actionUpdate()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'instanceid' 		=> TYPE_UINT,
			'instance' 			=> TYPE_ARRAY,
			'permissions' 		=> TYPE_ARRAY,
			'bbcodepermissions' => TYPE_ARRAY,
		));

		

		// Store raw sticky
		$sticky_raw = $cleanedInput['instance']['sticky'] = $cleanedInput['instance']['sticky_raw'];

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				// @TODO:
				break;

			case 'vBulletin':
				// Ensure we got BBCode Parser
				require_once(DIR . '/includes/class_bbcode.php');
				if (!function_exists('convert_url_to_bbcode'))
				{
					require_once(DIR . '/includes/functions_newpost.php');
				}


				// Initialise the parser (use proper BBCode)
				$parser = new vB_BbCodeParser($vbulletin, fetch_tag_list());

				// BBCode parsing
				$cleanedInput['instance']['sticky'] = $parser->parse(convert_url_to_bbcode($cleanedInput['instance']['sticky_raw']), 'nonforum');
				unset($parser);
				break;
		}

		foreach ($this->bitfields as $key => $fieldname)
		{
			$bit = 0;

			if (isset($cleanedInput['instance']['options'][$key]) AND is_array($cleanedInput['instance']['options'][$key]))
			{
				foreach ($cleanedInput['instance']['options'][$key] as $value)
				{
					// Update the options array
					$bit += $value;
				}
			}

			$cleanedInput['instance']['options'][$key] = $bit;
		}

		$bitfields = $this->app->fetchBitfield('nocache|dbtech_vbshoutpermissions');
		if ($this->app->getSystem() == 'vBulletin')
		{
			$bitfields2 = $this->app->fetchBitfield('nocache|allowedbbcodesfull');

			if (count($cleanedInput['bbcodepermissions']))
			{
				$permarray = array();
				foreach ($cleanedInput['bbcodepermissions'] as $usergroupid => $permvalues)
				{
					$permarray[$usergroupid] = 0;
					foreach ($permvalues as $bitfield => $bit)
					{
						// Update the permissions array
						$permarray[$usergroupid] += ($bit ? $bitfields2[$bitfield] : 0);
					}
				}

				// Set the perm array
				$cleanedInput['instance']['bbcodepermissions'] = $permarray;
			}
		}

		if (count($cleanedInput['permissions']))
		{
			$permarray = array();
			foreach ($cleanedInput['permissions'] as $usergroupid => $permvalues)
			{
				$permarray[$usergroupid] = 0;
				foreach ($permvalues as $bitfield => $bit)
				{
					// Update the permissions array
					$permarray[$usergroupid] += ($bit ? $bitfields[$bitfield] : 0);
				}
			}

			// Set the perm array
			$cleanedInput['instance']['permissions'] = $permarray;
		}

		// init data manager
		$instanceDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Instance', DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['instanceid'])
		{
			if (!$existing = $instanceCache[$cleanedInput['instanceid']])
			{
				// Couldn't find the instance
				print_stop_message('dbtech_vbshout_invalid_x', $this->app->phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
			}

			// Set existing
			$instanceDm->setExistingData($existing);

			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$instanceDm->bulkSet($cleanedInput['instance']);

		// Save! Hopefully.
		$instanceDm->save();

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', array(
			'param1' => $this->app->phrase('dbtech_vbshout_instance'),
			'param2' => $phrase
		)), $this->app->link('instance'));
	}

	// #############################################################################
	public function actionMassUpdate()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'instance' => TYPE_ARRAY
		));

		foreach ($cleanedInput['instance'] as $instanceid => $instance)
		{
			if (!$existing = $instanceCache[$instanceid])
			{
				// Couldn't find the instance
				continue;
			}

			// init data manager
			$instanceDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Instance', DBTech_Shout_DataManager::ERROR_EXCEPTION);
				$instanceDm->setExistingData($existing);
				$instanceDm->bulkSet($instance);
			$instanceDm->save();
			unset($instanceDm);
		}

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', array(
			'param1' => $this->app->phrase('dbtech_vbshout_instance'),
			'param2' => $this->app->phrase('dbtech_vbshout_edited')
		)), $this->app->link('instance'));
	}

	// #############################################################################
	public function actionDelete()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'instanceid' => TYPE_UINT,
		));

		print_cp_header($this->app->phrase('dbtech_vbshout_delete_x', array('param1' => $this->app->phrase('dbtech_vbshout_instance'))));
		print_delete_confirmation('dbtech_vbshout_instance', $cleanedInput['instanceid'], 'vbshout', 'instance', 'dbtech_vbshout_instance', array('action' => 'kill'), '', 'name');
		print_cp_footer();
	}

	// #############################################################################
	public function actionKill()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'instanceid' => TYPE_UINT,
			'kill' 		 => TYPE_BOOL
		));

		if (!$existing = $instanceCache[$cleanedInput['instanceid']])
		{
			// Couldn't find the instance
			print_stop_message('dbtech_vbshout_invalid_x', $this->app->phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
		}

		// init data manager
		$instanceDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Instance', DBTech_Shout_DataManager::ERROR_EXCEPTION);
			$instanceDm->setExistingData($existing);
		$instanceDm->delete();

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', array(
			'param1' => $this->app->phrase('dbtech_vbshout_instance'),
			'param2' => $this->app->phrase('dbtech_vbshout_deleted')
		)), $this->app->link('instance'));
	}

	// #############################################################################
	public function actionUpdateinstancepermissions()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'instanceid'		=> TYPE_UINT,
			'permissions' 		=> TYPE_ARRAY,
		));

		$bitfields = $this->app->fetchBitfield('nocache|dbtech_vbshoutpermissions');

		$permarray = array();
		foreach ((array)$cleanedInput['permissions'] as $usergroupid => $permvalues)
		{

			$permarray[$usergroupid] = 0;
			foreach ((array)$permvalues as $bitfield => $bit)
			{
				// Update the permissions array
				$permarray[$usergroupid] += ($bit ? $bitfields[$bitfield] : 0);
			}
		}

		// Set the perm array
		$cleanedInput['instance']['permissions'] = $permarray;

		// init data manager
		$instanceDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Instance', DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['instanceid'])
		{
			if (!$existing = $instanceCache[$cleanedInput['instanceid']])
			{
				// Couldn't find the instance
				print_stop_message('dbtech_vbshout_invalid_x', $this->app->phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
			}

			// Set existing
			$instanceDm->setExistingData($existing);

			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$instanceDm->bulkSet($cleanedInput['instance']);

		// Save! Hopefully.
		$instanceDm->save();

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', array(
			'param1' => $this->app->phrase('dbtech_vbshout_instance'),
			'param2' => $this->app->phrase('dbtech_vbshout_edited')
		)), $this->app->link('instance'));
	}

	// #############################################################################
	public function actionUpdatebbcodepermissions()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'instanceid'		=> TYPE_UINT,
			'bbcodepermissions' => TYPE_ARRAY,
		));

		// Ensure we can fetch bitfields
		$bitfields = $this->app->fetchBitfield('nocache|allowedbbcodesfull');

		$permarray = array();
		foreach ((array)$cleanedInput['bbcodepermissions'] as $usergroupid => $permvalues)
		{
			$permarray[$usergroupid] = 0;
			foreach ((array)$permvalues as $bitfield => $bit)
			{
				// Update the permissions array
				$permarray[$usergroupid] += ($bit ? $bitfields[$bitfield] : 0);
			}
		}

		// Set the perm array
		$cleanedInput['instance']['bbcodepermissions'] = $permarray;

		// init data manager
		$instanceDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Instance', DBTech_Shout_DataManager::ERROR_EXCEPTION);

		// set existing info if this is an update
		if ($cleanedInput['instanceid'])
		{
			if (!$existing = $instanceCache[$cleanedInput['instanceid']])
			{
				// Couldn't find the instance
				print_stop_message('dbtech_vbshout_invalid_x', $this->app->phrase('dbtech_vbshout_instance'), $cleanedInput['instanceid']);
			}

			// Set existing
			$instanceDm->setExistingData($existing);

			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_edited');
		}
		else
		{
			// Added
			$phrase = $this->app->phrase('dbtech_vbshout_added');
		}

		// Bulk set values
		$instanceDm->bulkSet($cleanedInput['instance']);

		// Save! Hopefully.
		$instanceDm->save();

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', array(
			'param1' => $this->app->phrase('dbtech_vbshout_instance'),
			'param2' => $this->app->phrase('dbtech_vbshout_edited')
		)), $this->app->link('instance'));
	}

	// #############################################################################
	public function actionPermissions()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$permissions = $this->app->fetchBitfield('nocache|dbtech_vbshoutpermissions');

		print_cp_header($this->app->phrase('dbtech_vbshout_instance_permissions'));

		// Table header
		$headings = array();
		$headings[] = $this->app->phrase('dbtech_vbshout_usergroup');
		foreach ((array)$permissions as $permissionname => $bit)
		{
			$headings[] = $this->app->phrase("dbtech_vbshout_permission_{$permissionname}");
		}
		$headings[] = $this->app->phrase('edit');

		if (count($instanceCache))
		{
			print_table_start();
			print_table_header($this->app->phrase('dbtech_vbshout_instance_permissions'), count($headings));
			print_cells_row($headings, true);

			foreach ($instanceCache as $instanceid => $instance)
			{
				print_description_row($instance['name'] . ' - ' . $instance['description'], false, count($headings), 'optiontitle');

				foreach ($this->app->getUserGroupCache() as $usergroupid => $usergroup)
				{
					// Table data
					$cell = array();
					$cell[] = $usergroup['title'];
					foreach ((array)$permissions as $permissionname => $bit)
					{
						$cell[] = ($instance['permissions'][$usergroupid] & $bit ? $this->app->phrase('yes') : '<span class="col-i"><strong>' . $this->app->phrase('no') . '</strong></span>');
					}
					$cell[] = construct_link_code($this->app->phrase('edit'), $this->app->link('instance', array('action' => 'modify', 'instanceid' => $instanceid)));

					// Print the data
					print_cells_row($cell, false, false, -5, 'middle', false, true);
				}
			}
			print_cells_row(false);
			print_table_footer();
		}
		else
		{
			print_table_start();
			print_table_header($this->app->phrase('dbtech_vbshout_instance_management'), count($headings));
			print_description_row($this->app->phrase('dbtech_vbshout_no_instances'), false, count($headings));
			print_table_footer(count($headings), construct_button_code($this->app->phrase('dbtech_vbshout_add_new_instance'), $this->app->link('instance', array('action' => 'modify'))));
		}
	}

	
}
?>