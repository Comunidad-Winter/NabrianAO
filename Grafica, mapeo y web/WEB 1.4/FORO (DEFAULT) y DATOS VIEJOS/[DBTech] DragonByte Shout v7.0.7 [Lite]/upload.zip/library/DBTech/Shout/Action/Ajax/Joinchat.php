<?php
class DBTech_Shout_Action_Ajax_Joinchat extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 8))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		// Chat join
		$this->shoutbox->joinChatroom($chatroom, $this->app->getUserInfo('userid'));
	}
}