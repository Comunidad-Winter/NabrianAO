<?php
class DBTech_Shout_ActionAdmin_Download extends DBTech_Shout_ActionAdmin
{
	public function actionIndex()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		print_cp_header($this->app->phrase('dbtech_vbshout_download_archive'));

		$instances = array();
		$instances[0] = $this->app->phrase('dbtech_vbshout_all_instances');
		foreach ($instanceCache as $instanceid => $instance)
		{
			// Store the instance
			$instances["$instanceid"] = $instance['name'];
		}
		asort($instances);

		print_form_header('vbshout', 'download', false, true, 'cpform2');
		construct_hidden_code('action', 'file');
		print_table_header($this->app->phrase('dbtech_vbshout_download_archive'));
		print_select_row($this->app->phrase('dbtech_vbshout_file_format'), 'format', array('csv' => 'CSV', 'xml' => 'XML', 'txt' => 'TXT'), 'txt');
		print_time_row($this->app->phrase('start_date'), 'startdate', 0, false);
		print_time_row($this->app->phrase('end_date'), 'enddate', 0, false);
		print_yes_no_row($this->app->phrase('dbtech_vbshout_include_bbcode'), 'bbcode', 1);
		print_select_row($this->app->phrase('dbtech_vbshout_instance'), 'instanceid', $instances, 0);
		print_submit_row($this->app->phrase('dbtech_vbshout_download_archive'), 0);
	}

	public function actionFile()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$cleanedInput = $this->app->filter(array(
			'startdate'  => TYPE_UNIXTIME,
			'enddate'    => TYPE_UNIXTIME,
			'instanceid' => TYPE_STR,
			'format'     => TYPE_STR,
			'bbcode'	 => TYPE_BOOL
		));

		$sqlconds = array();
		if ($cleanedInput['startdate'])
		{
			$sqlconds[] = "vbshout.dateline >= " . $cleanedInput['startdate'];
		}

		if ($cleanedInput['enddate'])
		{
			$sqlconds[] = "vbshout.dateline <= " . $cleanedInput['enddate'];
		}

		if ($cleanedInput['instanceid'])
		{
			$sqlconds[] = "vbshout.instanceid = " . $cleanedInput['instanceid'];
		}

		// ###########################################################
		$logs = $this->_getDb()->fetchAll('
			SELECT vbshout.*, user.username
			FROM $dbtech_vbshout_shout AS vbshout
			LEFT JOIN $user AS user ON (user.=user:userid= = vbshout.userid)
			' . (!empty($sqlconds) ? "WHERE " . implode("\r\n\tAND ", $sqlconds) : "") . '
			ORDER BY instanceid ASC, dateline ASC
		');

		if (!count($logs))
		{
			print_stop_message('dbtech_vbshout_no_results_matched_your_query');
		}

		switch ($cleanedInput['format'])
		{
			case 'txt':
			case 'csv':
				$output = '';
				break;

			case 'xml':
				$document = new DOMDocument('1.0', 'utf-8');
				$document->formatOutput = true;

				$rootNode = $document->createElement('archive');
				break;
		}

		$lastinstanceid = -1;
		foreach ($logs as $log)
		{
			if ($log['userid'] == -1)
			{
				// System user
				$log['username'] = $this->app->phrase('dbtech_vbshout_system');
			}

			/*
			@TODO:
			if ($log['type'] == VBSHOUT::$shouttypes['pm'])
			{
				// Add PM flag
				$log['username'] .= ' (' . $this->app->phrase('dbtech_vbshout_pm') . ')';
			}

			// Strip bbcode if needed
			$log['message'] = (!$cleanedInput['bbcode'] ? strip_bbcode($log['message']) : $log['message']);
			*/

			$time = $this->app->dateTime($log['dateline']);

			switch ($cleanedInput['format'])
			{
				case 'txt':
					if ($log['instanceid'] != $lastinstanceid)
					{
						$lastinstanceid = $log['instanceid'];
						$output .= "\t\t" . (isset($instanceCache[$log['instanceid']]['name']) ? $instanceCache[$log['instanceid']]['name'] : 'N/A') . "\n";
					}
					$output .= "[$time] $log[username]: $log[message]\n";
					break;

				case 'csv':
					$output .= (isset($instanceCache[$log['instanceid']]['name']) ? $instanceCache[$log['instanceid']]['name'] : 'N/A') . "\t$time\t$log[username]\t$log[message]\n";
					break;

				case 'xml':
					$shoutNode = $document->createElement('shout');

						$shoutDataNode = $document->createElement('instance');
							$shoutDataNode->appendChild($document->createCDATASection((isset($instanceCache[$log['instanceid']]['name']) ? $instanceCache[$log['instanceid']]['name'] : 'N/A')));
						$shoutNode->appendChild($shoutDataNode);

						$shoutDataNode = $document->createElement('timestamp');
							$shoutDataNode->appendChild($document->createCDATASection($time));
						$shoutNode->appendChild($shoutDataNode);

						$shoutDataNode = $document->createElement('username');
							$shoutDataNode->appendChild($document->createCDATASection($log['username']));
						$shoutNode->appendChild($shoutDataNode);

						$shoutDataNode = $document->createElement('message');
							$shoutDataNode->appendChild($document->createCDATASection($log['message']));
						$shoutNode->appendChild($shoutDataNode);

					$rootNode->appendChild($shoutNode);
					break;
			}
		}

		switch ($cleanedInput['format'])
		{
			case 'txt':
				$mimetype = 'text/plain';
				$extension = 'txt';
				break;

			case 'csv':
				$mimetype = 'text/csv';
				$extension = 'csv';
				break;

			case 'xml':
				$mimetype = 'text/xml';
				$extension = 'xml';

				$document->appendChild($rootNode);

				$output = $document->saveXML();
				break;
		}

		if ($this->app->getSystem() == 'vBulletin')
		{
			require_once(DIR . '/includes/functions_file.php');
			file_download($output, 'shoutbox-archive.' . $extension, $mimetype);
		}
		else
		{
			$this->app->downloadFile($output, 'shoutbox-archive.' . $extension, $mimetype);
		}
	}
}
?>