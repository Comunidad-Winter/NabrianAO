<?php
class DBTech_Shout_ActionAdmin_Commandlog extends DBTech_Shout_ActionAdmin
{
	public function actionIndex()
	{
		print_cp_header($this->app->phrase('dbtech_vbshout_command_log'));

		// ###########################################################
		$users = $this->_getDb()->fetchAll('
			SELECT DISTINCT commandlog.userid, IFNULL(user.username, commandlog.username) AS username
			FROM $dbtech_vbshout_log AS commandlog
			LEFT JOIN $user AS user ON(user.=user:userid= = commandlog.username)
			ORDER BY username ASC
		');

		$userlist = array('no_value' => $this->app->phrase('dbtech_vbshout_all_log_entries'));
		foreach ($users as $user)
		{
			$userlist[$user['userid']] = $user['username'];
		}

		print_form_header('vbshout', 'commandlog', false, true, 'cpform2');
		construct_hidden_code('action', 'view');
		print_table_header($this->app->phrase('dbtech_vbshout_command_log_viewer'));
		print_input_row($this->app->phrase('dbtech_vbshout_log_entries_to_show_per_page'), 'perpage', 15);
		print_select_row($this->app->phrase('dbtech_vbshout_show_only_entries_generated_by'), 'userid', $userlist);
		print_time_row($this->app->phrase('start_date'), 'startdate', '', false);
		print_time_row($this->app->phrase('end_date'), 'enddate', '', false);
		print_select_row($this->app->phrase('order_by'), 'orderby', array('date' => $this->app->phrase('date'), 'user' => $this->app->phrase('username')), 'date');
		print_submit_row($this->app->phrase('view'), 0);

		print_form_header('vbshout', 'commandlog');
		construct_hidden_code('action', 'prune');
		print_table_header($this->app->phrase('dbtech_vbshout_prune_log_entries'));
		print_yes_no_row($this->app->phrase('dbtech_vbshout_are_you_sure', array('param1' => '')), 'doprune', 0);
		print_submit_row($this->app->phrase('dbtech_vbshout_prune_log_entries'), false);
	}

	public function actionPrune()
	{
		$cleanedInput = $this->app->filter(array(
			'doprune'    => TYPE_BOOL,
		));

		if (!$cleanedInput['doprune'])
		{
			print_stop_message('dbtech_vbshout_nothing_to_do');
		}

		$this->_getDb()->query('TRUNCATE TABLE $dbtech_vbshout_log', array(), 'query_write');

		$this->app->redirect($this->app->phrase('dbtech_vbshout_pruned_command_log_successfully'), $this->app->link('commandlog'));
	}

	public function actionView()
	{
		print_cp_header($this->app->phrase('dbtech_vbshout_command_log'));

		$cleanedInput = $this->app->filter(array(
			'perpage'    => TYPE_UINT,
			'page' => TYPE_UINT,
			'userid'     => TYPE_UINT,
			'modaction'  => TYPE_STR,
			'orderby'    => TYPE_NOHTML,
			'product'    => TYPE_STR,
			'startdate'  => TYPE_UNIXTIME,
			'enddate'    => TYPE_UNIXTIME,
		));

		$sqlconds = array();

		if ($cleanedInput['perpage'] < 1)
		{
			$cleanedInput['perpage'] = 15;
		}

		if ($cleanedInput['userid'] OR $cleanedInput['modaction'])
		{
			if ($cleanedInput['userid'])
			{
				$sqlconds[] = "commandlog.userid = " . $cleanedInput['userid'];
			}
			if ($cleanedInput['modaction'])
			{
				$sqlconds[] = "commandlog.command LIKE " . $this->_getDb()->quoteLike($cleanedInput['modaction'], 'lr');
			}
		}

		if ($cleanedInput['startdate'])
		{
			$sqlconds[] = "commandlog.dateline >= " . $cleanedInput['startdate'];
		}

		if ($cleanedInput['enddate'])
		{
			$sqlconds[] = "commandlog.dateline <= " . $cleanedInput['enddate'];
		}

		$counter = $this->_getDb()->fetchRow('
			SELECT COUNT(*) AS total
			FROM $dbtech_vbshout_log AS commandlog
			' . (!empty($sqlconds) ? "WHERE " . implode("\r\n\tAND ", $sqlconds) : "")
		);
		$totalpages = ceil($counter['total'] / $cleanedInput['perpage']);

		if ($cleanedInput['page'] < 1)
		{
			$cleanedInput['page'] = 1;
		}
		$startat = ($cleanedInput['page'] - 1) * $cleanedInput['perpage'];

		switch($cleanedInput['orderby'])
		{
			case 'user':
				$order = 'user.username ASC, dateline DESC';
				break;
			case 'modaction':
				$order = 'command ASC, dateline DESC';
				break;
			case 'date':
			default:
				$order = 'dateline DESC';
		}

		$logusers = array();
		$users = $this->_getDb()->fetchAll('
			SELECT user.=user:userid= AS userid, user.username
			FROM $dbtech_vbshout_log AS commandlog
			LEFT JOIN $user AS user ON (user.=user:userid= = commandlog.comment)
			WHERE command IN(\'ban\', \'unban\', \'pruneuser\', \'resetshoutsuser\', \'silence\', \'unsilence\')
		');
		foreach ($users as $user)
		{
			// Cache the users mentioned in the command
			$logusers[$user['userid']] = ($user['username'] ? $user['username'] : 'N/A');
		}

		$logs = $this->_getDb()->fetchAll('
			SELECT commandlog.*, commandlog.username AS cmdusername, user.username
			FROM $dbtech_vbshout_log AS commandlog
			LEFT JOIN $user AS user ON (user.=user:userid= = commandlog.userid)
			' . (!empty($sqlconds) ? "WHERE " . implode("\r\n\tAND ", $sqlconds) : "") . '
			ORDER BY ' . $order . '
			LIMIT ' . $startat . ', ' . $cleanedInput['perpage']
		);

		if (count($logs))
		{
			$cleanedInput['modaction'] = htmlspecialchars($cleanedInput['modaction']);

			$firstpage = $prevpage = $nextpage = $lastpage = '';
			if ($cleanedInput['page'] != 1)
			{
				$prv = $cleanedInput['page'] - 1;
				$firstpage = construct_button_code("&laquo; " . $this->app->phrase('dbtech_vbshout_first_page'), $this->app->link('commandlog', array('action' => 'view', 'modaction' => $cleanedInput['modaction'], 'userid' => $cleanedInput['userid'], 'perpage' => $cleanedInput['perpage'], 'orderby' => $cleanedInput['orderby'], 'page' => 1)));
				$prevpage = construct_button_code("&lt; " . $this->app->phrase('dbtech_vbshout_prev_page'), $this->app->link('commandlog', array('action' => 'view', 'modaction' => $cleanedInput['modaction'], 'userid' => $cleanedInput['userid'], 'perpage' => $cleanedInput['perpage'], 'orderby' => $cleanedInput['orderby'], 'page' => $prv)));
			}

			if ($cleanedInput['page'] != $totalpages)
			{
				$nxt = $cleanedInput['page'] + 1;
				$nextpage = construct_button_code($this->app->phrase('dbtech_vbshout_next_page') . " &gt;", $this->app->link('commandlog', array('action' => 'view', 'modaction' => $cleanedInput['modaction'], 'userid' => $cleanedInput['userid'], 'perpage' => $cleanedInput['perpage'], 'orderby' => $cleanedInput['orderby'], 'page' => $nxt)));
				$lastpage = construct_button_code($this->app->phrase('dbtech_vbshout_last_page') . " &raquo;", $this->app->link('commandlog', array('action' => 'view', 'modaction' => $cleanedInput['modaction'], 'userid' => $cleanedInput['userid'], 'perpage' => $cleanedInput['perpage'], 'orderby' => $cleanedInput['orderby'], 'page' => $totalpages)));
			}

			$headings = array();
			$headings[] = "<a href=\"" . $this->app->link('commandlog', array('action' => 'view', 'modaction' => $cleanedInput['modaction'], 'userid' => $cleanedInput['userid'], 'perpage' => $cleanedInput['perpage'], 'orderby' => 'user', 'page' => $cleanedInput['page'])) . "\">" . str_replace(' ', '&nbsp;', $this->app->phrase('dbtech_vbshout_username')) . "</a>";
			$headings[] = "<a href=\"" . $this->app->link('commandlog', array('action' => 'view', 'modaction' => $cleanedInput['modaction'], 'userid' => $cleanedInput['userid'], 'perpage' => $cleanedInput['perpage'], 'orderby' => 'date', 'page' => $cleanedInput['page'])) . "\">" . $this->app->phrase('date') . "</a>";
			$headings[] = "<a href=\"" . $this->app->link('commandlog', array('action' => 'view', 'modaction' => $cleanedInput['modaction'], 'userid' => $cleanedInput['userid'], 'perpage' => $cleanedInput['perpage'], 'orderby' => 'modaction', 'page' => $cleanedInput['page'])) . "\">" . $this->app->phrase('action') . "</a>";
			$headings[] = $this->app->phrase('dbtech_vbshout_info');
			$headings[] = str_replace(' ', '&nbsp;', $this->app->phrase('ip_address'));

			print_table_start();
			//print_description_row(construct_link_code($this->app->phrase('restart'), $this->app->link('commandlog')), false, count($headings), 'thead', 'right');
			print_table_header($this->app->phrase('dbtech_vbshout_command_log_viewer_page_x_y_there_are_z_total_log_entries', array(
				'param1' => $this->app->numberFormat($cleanedInput['page']),
				'param2' => $this->app->numberFormat($totalpages),
				'param3' => $this->app->numberFormat($counter['total']))
			), count($headings), false, ' ');
			print_cells_row($headings, true);

			foreach ($logs as $log)
			{
				$cell = array();
				if ($log['username'])
				{
					// This user still exists
					$cell[] = "<b>$log[username]</b>";
				}
				else
				{
					// User has been deleted
					$cell[] = ($log['cmdusername'] ? $log['cmdusername'] : 'N/A');
				}
				$cell[] = '<span class="smallfont">' . $this->app->dateTime($log['dateline']) . '</span>';
				$cell[] = $this->app->phrase("dbtech_vbshout_logcommand_$log[command]");

				$celldata = '';
				switch ($log['command'])
				{
					case 'ban':
					case 'unban':
						$celldata = $this->app->phrase("dbtech_vbshout_log_$log[command]", array('param1' => $logusers[$log['comment']]));
						break;

					case 'shoutedit':
						$shouts = unserialize($log['comment']);
						$celldata = $this->app->phrase("dbtech_vbshout_log_$log[command]", array('param1' => $shouts['old'], 'param2' => $shouts['new']));
						break;

					case 'shoutdelete':
						$celldata = $this->app->phrase("dbtech_vbshout_log_$log[command]", array('param1' => $log['comment']));
						break;
				}

				

				$cell[] = $celldata;
				$cell[] = '<span class="smallfont">' . $log['ipaddress'] . '</span>';

				print_cells_row($cell, 0, 0, -4);
			}
			print_cells_row(false);
			print_table_footer(count($headings), "$firstpage $prevpage &nbsp; $nextpage $lastpage");
		}
		else
		{
			print_stop_message('dbtech_vbshout_dbtech_vbshout_no_results_matched_your_query');
		}
	}
}
?>