<?php

abstract class DBTech_Shout_XenForo_Option_BrandingFree
{
	public static function verifyOption(&$option, XenForo_DataWriter $dw, $fieldName)
	{
		if ($dw->isInsert())
		{
			// insert - just trust the default value
			return true;
		}

		return ($option == '2' . '5' . '59' . '9748-' . 'ea' . '26' . '7' . '7a14' . 'f5' . '4' . 'b1' . 'f6' . '5' . 'c' . '2' . 'd' . 'e' . 'ef0' . '08' . '8d' . '7' . '25' . '2' OR empty($option));
	}
}