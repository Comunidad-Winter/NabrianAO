<?php

class DBTech_Shout_XenForo_Install
{
	/**
	 * Database object
	 *
	 * @var Zend_Db_Adapter_Abstract
	 */
	protected $_db;

	/**
	 * Helper method to get the database object.
	 *
	 * @return Zend_Db_Adapter_Abstract
	 */
	protected function _getDb()
	{
		if ($this->_db === null)
		{
			$this->_db = XenForo_Application::get('db');
		}

		return $this->_db;
	}

	/**
	 * Begins the installation process and picks the proper install routine.
	 *
	 * See see XenForo_Model_Addon::installAddOnXml() for more details about
	 * the arguments passed to this method.
	 *
	 * @param array Information about the existing version (if upgrading)
	 * @param array Information about the current version being installed
	 *
	 * @return void
	 */
	public static function install($existingAddOn, $addOnData)
	{
		// the version IDs from which we should start/end the install process
		$currentVersionId = 20160328;
		$endVersionId = intval($addOnData['version_id']);

		if ($existingAddOn)
		{
			if ($existingAddOn['version_id'] > $currentVersionId)
			{
				// we are upgrading, run every install method since last upgrade
				$currentVersionId = date('Ymd', strtotime(intval($existingAddOn['version_id']) . ' + 1 day'));
			}
			else
			{
				// we are upgrading, but from an old style installer
				$currentVersionId = 20160329;
			}
		}

		while ($currentVersionId <= $endVersionId)
		{
			$class = 'DBTech_Shout_XenForo_Install_' . $currentVersionId;
			if (class_exists($class) !== false)
			{
				// create our install object
				$install = new $class();
				$install->_install();
				unset($install);
			}

			$currentVersionId = date('Ymd', strtotime(intval($currentVersionId) . ' + 1 day'));
		}

		@unlink(XenForo_Helper_File::getExternalDataPath() . '/dbtechShoutUpgrade.lock');
	}

}