<?php
class DBTech_Shout_Template extends DBTech_Shout_Application_Template
{
}
?>