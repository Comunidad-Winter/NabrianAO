<?php
/**
* DataManager for Instances.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Helper_Instance
{
	/**
	 * Verifies that the instance ID is valid.
	 *
	 * @param string $instanceId
	 *
	 * @return boolean
	 */
	public static function _verifyVarname(&$varname, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		$varname = strval($varname);
		if ($varname === '')
		{
			// Invalid
			return false;
		}

		// Check for existing instance of this name
		if ($existing = $dm->_getDb()->fetchRow('
			SELECT `varname`
			FROM `$dbtech_vbshout_instance`
			WHERE `varname` = ?
				' . ($dm->getExisting('instanceid') ? ("AND `instanceid` != " . $dm->_getDb()->quote($dm->getExisting('instanceid'))) : '') . '
		', array(
			$varname
		)))
		{
			// Whoopsie, exists
			$dm->error($dm->app->phrase('dbtech_vbshout_varname_already_exists'), $fieldName);
			return false;
		}

		return true;
	}


	/**
	* Verifies that the instanceid is valid
	*
	* @param	integer	instanceid of the shout
	*
	* @return	boolean
	*/
	public static function _verifyInstance(&$instanceid, DBTech_Shout_DataManager $dm, $fieldName = false, array $fieldData = array())
	{
		// Init this
		$instanceCache = $dm->cache->get('instance');

		return (!$instanceid OR (isset($instanceCache[$instanceid]) AND is_array($instanceCache[$instanceid])));
	}
}