<?php
class DBTech_Shout_XenForo_ControllerAdmin_Option extends XFCP_DBTech_Shout_XenForo_ControllerAdmin_Option
{
	/**
	 * Lists all the options that belong to a particular group.
	 *
	 * @return XenForo_ControllerResponse_Abstract
	 */
	public function actionList()
	{
		$input = $this->_input->filter(array(
			'group_id' => XenForo_Input::STRING
		));

		if ($input['group_id'] == 'dbtech_shout')
		{
			return $this->responseRedirect(
				XenForo_ControllerResponse_Redirect::SUCCESS,
				XenForo_Link::buildAdminLink('dbtech-shout/options')
			);
		}

		return parent::actionList();
	}
}