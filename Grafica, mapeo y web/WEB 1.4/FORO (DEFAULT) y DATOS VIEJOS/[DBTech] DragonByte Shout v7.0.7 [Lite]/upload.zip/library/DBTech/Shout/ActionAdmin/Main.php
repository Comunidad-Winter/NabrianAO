<?php
class DBTech_Shout_ActionAdmin_Main extends DBTech_Shout_ActionAdmin
{
}
?>