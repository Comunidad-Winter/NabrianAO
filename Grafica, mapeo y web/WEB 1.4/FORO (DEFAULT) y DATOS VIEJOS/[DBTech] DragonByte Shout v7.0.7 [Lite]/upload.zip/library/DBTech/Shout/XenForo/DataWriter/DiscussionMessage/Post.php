<?php
class DBTech_Shout_XenForo_DataWriter_DiscussionMessage_Post extends XFCP_DBTech_Shout_XenForo_DataWriter_DiscussionMessage_Post
{
	protected function _messagePostSave()
	{
		// Do parent stuff
		$previous = parent::_messagePostSave();

		// Get user model
		$userModel = $this->getModelFromCache('XenForo_Model_User');

		if ($this->isUpdate() OR $this->isDiscussionFirstMessage())
		{
			return $previous;
		}

		if (!$this->get('user_id'))
		{
			return $previous;
		}

		if (!$shoutUserInfo = $userModel->getUserById($this->get('user_id')))
		{
			return $previous;
		}

		// Shorthand
		$app = DBTech_Shout_Core::getInstance();
		$shoutbox = DBTech_Shout_Shoutbox::getInstance();
		$instanceCache = DBTech_Shout_Cache::getInstance()->get('instance');

		if (
			!$shoutUserInfo['dbtech_vbshout_banned']
			AND $this->get('message_state') == 'visible'
		)
		{
			$page = floor($this->get('position') / XenForo_Application::get('options')->messagesPerPage) + 1;
			$thread = $this->getModelFromCache('XenForo_Model_Thread')->getThreadById($this->get('thread_id'));

			// This will need to be updated once we figure out the parent/child tree in xF
			$forum = $this->_getForumInfo();
			$noticeForum = $forum['node_id'];

			foreach ($instanceCache as $instanceid => $instance)
			{
				if (!isset($instance['notices'][$noticeForum]))
				{
					// Make sure this is set
					$instance['notices'][$noticeForum] = 0;
				}

				if (!(intval($instance['options']['notices']) & 1) OR
					!(intval($instance['notices'][$noticeForum]) & 1)
				)
				{
					// Not showing this
					continue;
				}

				//if ($instance['bbcodepermissions_parsed']['bit'] & 64)
				if (true)
				{
					// We can use BBCode
					$notif = '[URL=' . XenForo_Link::buildPublicLink('full:threads',
						array(
							'thread_id' => $this->get('thread_id'),
							'title' => $thread['title']
						),
						array('page' => $page)
					) . '#post-' . $this->get('post_id') . ']' . $thread['title'] . '[/URL]';
				}
				else
				{
					// We can't, so don't even bother
					$notif = $thread['title'];
				}

				// The shout we want to insert
				$shout = $app->phrase('dbtech_vbshout_notif_reply', array('param1' => $notif));

				// init data manager
				$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
					$shoutDm->setInfo('instance', $instance);
					$shoutDm->bulkSet(array(
						'instanceid' => $instanceid,
						'message' => $shout,
						'userid' => $shoutUserInfo['user_id'],
						'forumid' => $forum['node_id'],
						'type' => $shoutbox->shouttypes['notif']
					));
				$shoutId = $shoutDm->save();
				unset($shoutDm);

				
			}
		}

		if ($this->_forumCountsMessages())
		{
			foreach ($instanceCache as $instanceid => $instance)
			{
				if (!$instance['options']['postping_interval'])
				{
					// Not having notices here
					continue;
				}

				if (($shoutUserInfo['message_count'] + 1) % $instance['options']['postping_interval'] != 0)
				{
					// We only want matching intervals
					continue;
				}

				$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
					$shoutDm->setInfo('is_automated', true);
					$shoutDm->setInfo('instance', $instance);
					$shoutDm->bulkSet(array(
						'message' => $app->phrase('dbtech_vbshout_has_reached_x_posts', array('param1' => ($shoutUserInfo['message_count'] + 1))),
						'instanceid' => $instanceid,
						'type' => $shoutbox->shouttypes['notif']
					));
				$shoutDm->save();
				unset($shoutDm);
			}
		}

		return $previous;
	}

	/**
	 * Grabs the Cache model from the cache.
	 *
	 * @return XenForo_Model_DataRegistry
	 */
	protected function _getCacheModel()
	{
		return $this->getModelFromCache('XenForo_Model_DataRegistry');
	}
}