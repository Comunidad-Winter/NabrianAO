<?php
class DBTech_Shout_Action_Ajax_Unidle extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 1024))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$this->shoutbox->fetchActiveUsers($instance, $chatroom);
		$this->shoutbox->fetched['activeusers']['count'] = count($this->shoutbox->activeusers);

		if ($instance['options']['activeusers'])
		{
			if (isset($args['chatroomid']) AND $args['chatroomid'])
			{
				// Array of all active users
				$this->shoutbox->fetched['activeusers']['usernames'] = (count($this->shoutbox->activeusers) ? implode('<br />', $this->shoutbox->activeusers) : $this->app->phrase('dbtech_vbshout_no_chat_users'));
				if ($instance['options']['enableaccess'])
				{
					//$this->shoutbox->fetched['activeusers']['usernames'] .= '<br /><br /><a href="' . $this->app->link('chataccess', array('chatroomid' => $args['chatroomid']), array('id' => $instance['instanceid'], 'title' => $instance['name'])) . '" target="_blank"><b>' . $this->app->phrase('dbtech_vbshout_chat_access') . '</b></a>';
				}

			}
			else
			{
				// Array of all active users
				$this->shoutbox->fetched['activeusers']['usernames'] = (count($this->shoutbox->activeusers) ? implode('<br />', $this->shoutbox->activeusers) : $this->app->phrase('dbtech_vbshout_no_active_users'));
			}
		}
	}
}