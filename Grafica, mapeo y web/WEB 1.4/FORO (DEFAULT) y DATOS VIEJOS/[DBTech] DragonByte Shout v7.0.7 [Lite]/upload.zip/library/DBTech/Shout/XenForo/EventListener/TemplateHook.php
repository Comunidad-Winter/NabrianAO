<?php
class DBTech_Shout_XenForo_EventListener_TemplateHook
{
	public static function listen($hookName, &$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		if (
			file_exists(XenForo_Helper_File::getExternalDataPath() . '/dbtechShoutUpgrade.lock')
			AND !XenForo_Application::debugMode()
			AND $hookName != 'page_container_notices'
		)
		{
			return;
		}

		if (method_exists(__CLASS__, $hookName))
		{
			// Run the hook function
			self::$hookName($contents, $hookParams, $template);
		}
	}

	public static function page_container_notices(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		if (
			!file_exists(XenForo_Helper_File::getExternalDataPath() . '/dbtechShopUpgrade.lock')
			OR XenForo_Application::debugMode()
		)
		{
			return;
		}

		if (!XenForo_Application::isRegistered('config'))
		{
			$path = 'data';
		}
		else
		{
			$path = XenForo_Application::get('config')->externalDataPath;
		}

		// Shorthand
		$app = DBTech_Shout_Core::getInstance();

		$contents .= $template->create('notices', [
			'notices' => [
				'block' => [
					'dbtech_shout_upgrade' => [
						'noticeId' => 'dbtech_shout_upgrade',
						'imageUrl' => '',
						'dismissible' => false,
						'wrap' => true,
						'message' => $app->phrase('dbtech_shout_pending_upgrade', [
							'param1' => $path . '/dbtechShopUpgrade.lock'
						])
					]
				],
			]
		]
		)->render();
	}

	public static function footer($hookName, &$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$branding = XenForo_Application::isRegistered('dbtech_branding') ? XenForo_Application::get('dbtech_branding') : [];

		// Show branding or not
		$showBranding = XenForo_Application::get('options')->get('dbtech_vbshout_branding_free') != '2' . '5' . '599' . '7' . '4' . '8' . '-' . 'e' . 'a2677' . 'a' . '1' . '4' . 'f' . '5' . '4' . 'b' . '1' . 'f' . '6' . '5c' . '2de' . 'ef' . '0' . '0' . '88d7' . '252';

		if ($showBranding OR XenForo_Application::get('options')->get('dbtech_vbshout_include_details'))
		{
			// Add productid to the array
			$branding[] = 333;

			// Store the branding
			XenForo_Application::set('dbtech_branding', $branding);
		}
	}

	public static function footer_after_copyright(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$branding = XenForo_Application::isRegistered('dbtech_branding') ? XenForo_Application::get('dbtech_branding') : [];

		if (count($branding))
		{
			$brandingVariables = [
				'utm_source' 		=> str_replace('www.', '', htmlspecialchars($_SERVER['HTTP_HOST'])),
				'utm_content' 		=> 'footer',
				'referrerid' 		=> XenForo_Application::get('options')->get('dbtech_vbshout_referral'),
			];

			// Create this long string
			$str = '<div id="copyright" style="clear:both;">
				Parts of this site powered by <a class="concealed" rel="nofollow" href="http://www.dragonbyte-tech.com/store/5-xenforo/?utm_source=' . $brandingVariables['utm_source'] . '&utm_campaign=site&utm_medium=footer&utm_content=' . $brandingVariables['utm_content'] . ($brandingVariables['referrerid'] ? '&referrerid=' . $brandingVariables['referrerid'] : '') . '" target="_blank">XenForo add-ons from DragonByte&#8482;</a>
				&copy;2011-' . date('Y') . ' <a class="concealed" rel="nofollow" href="http://www.dragonbyte-tech.com/?utm_source=' . $brandingVariables['utm_source'] . '&utm_campaign=site&utm_medium=footer&utm_content=' . $brandingVariables['utm_content'] . ($brandingVariables['referrerid'] ? '&referrerid=' . $brandingVariables['referrerid'] : '') . '" target="_blank">DragonByte Technologies Ltd.</a>
				(<a class="concealed" rel="nofollow" href="http://www.dragonbyte-tech.com/vbecommerce.php?do=productdetails&productids=' . implode(',', $branding) . '&utm_source=' . $brandingVariables['utm_source'] . '&utm_campaign=product&utm_medium=' . $brandingVariables['utm_medium'] . '&utm_content=' . $brandingVariables['utm_content'] . '" target="_blank">Details</a>)
			</div>';

			// Set the string now
			$contents = (trim($contents) != '' ? $str . '<br />' . $contents : $str);

			// Make sure we null this out
			XenForo_Application::set('dbtech_branding', []);
		}
	}

	

	public static function page_container_breadcrumb_top(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$options = XenForo_Application::getOptions();

		if ($options->boardActive)
		{
			// Call the real code
			self::breadcrumb(1, $contents, $hookParams, $template);
		}
	}

	public static function page_container_breadcrumb_bottom(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$options = XenForo_Application::getOptions();

		if ($options->boardActive)
		{
			// Call the real code
			self::breadcrumb(2, $contents, $hookParams, $template);
		}
	}

	private static function breadcrumb($autoDisplayKey, &$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		// Shorthand
		$app = DBTech_Shout_Core::getInstance();

		$requestPaths = XenForo_Application::get('requestPaths');
		if (
			(!$app->option('useFriendlyUrls') AND strpos($requestPaths['fullUri'], '?') !== false)
			OR ($app->option('useFriendlyUrls') AND $requestPaths['fullUri'] != $requestPaths['fullBasePath'])
		)
		{
			// Only load on index
			return false;
		}

		if (!$app->option('dbtech_vbshout_active') AND !$app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
		{
			// SB isn't even on!
			return false;
		}

		if ($app->getUserInfo('dbtech_vbshout_banned'))
		{
			// Bunned.
			return false;
		}

		// Init this
		$instanceCache = DBTech_Shout_Cache::getInstance()->get('instance');
		$includedInstances = [];

		foreach ($instanceCache as $instanceid => $instance)
		{
			if ($instance['autodisplay'] == $autoDisplayKey)
			{
				// Add to included instances
				$includedInstances[$instanceid] = $instance;
			}
		}

		if (!$includedInstances)
		{
			// We aren't auto-displaying anything
			return false;
		}

		// Indicate we have done this
		DBTech_Shout_Cache::getInstance()->hasIncludedJS = true;

		// Render the wrapper stuff
		if ($vBShout = DBTech_Shout_Shoutbox::getInstance()->renderWrapper($includedInstances))
		{
			if ($autoDisplayKey == 2)
			{
				$contents .= implode('', $vBShout['instances']) . $vBShout['js'];
			}
			else
			{
				$contents = implode('', $vBShout['instances']) . $vBShout['js'] . $contents;
			}
		}
	}

	public static function navigation_visitor_tabs_start(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$visitor = XenForo_Visitor::getInstance();
		$options = XenForo_Application::getOptions();

		if (
			$options->dbtech_shout_navbar['enabled'] == 2
			AND $options->dbtech_shout_navbar['right_position']
			AND $options->dbtech_shout_navbar['right_position'] == 'start'
		)
		{
			self::_navigation_visitor_tabs($contents, $hookParams, $template);
		}
	}

	public static function navigation_visitor_tabs_middle(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$visitor = XenForo_Visitor::getInstance();
		$options = XenForo_Application::getOptions();

		if (
			$options->dbtech_shout_navbar['enabled'] == 2
			AND $options->dbtech_shout_navbar['right_position']
			AND $options->dbtech_shout_navbar['right_position'] == 'middle'
		)
		{
			self::_navigation_visitor_tabs($contents, $hookParams, $template);
		}
	}

	public static function navigation_visitor_tabs_end(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$visitor = XenForo_Visitor::getInstance();
		$options = XenForo_Application::getOptions();

		if (
			$options->dbtech_shout_navbar['enabled'] == 2
			AND $options->dbtech_shout_navbar['right_position']
			AND $options->dbtech_shout_navbar['right_position'] == 'end'
		)
		{
			self::_navigation_visitor_tabs($contents, $hookParams, $template);
		}
	}


	protected static function _navigation_visitor_tabs(&$contents, array $hookParams, XenForo_Template_Abstract $template)
	{
		$visitor = XenForo_Visitor::getInstance();
		/*
		if (
			$visitor->user_id
			AND (
				$visitor->hasPermission('dbtech_shoutpermissions', 'ismanager')
				OR $visitor->hasPermission('dbtech_shoutpermissions', 'canview')
			)
		)
		*/
		{
			$params = $template->getParams();

			$params = array_merge([
				'extraTabId' => 'dbtech-shout',
				'extraTab' => $params['extraTabs']['_right']['dbtech-shout'],
				'permissions' => [
				]
			], $params);

			$contents .= $template->create('dbtech_shout_navbar_right', $params)->render();
		}
	}
}