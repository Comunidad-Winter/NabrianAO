<?php
class DBTech_Shout_Core extends DBTech_Shout_Application_Core
{
}
?>