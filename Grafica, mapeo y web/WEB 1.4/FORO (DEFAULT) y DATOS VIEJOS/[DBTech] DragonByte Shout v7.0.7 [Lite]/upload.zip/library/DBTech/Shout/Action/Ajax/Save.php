<?php
class DBTech_Shout_Action_Ajax_Save extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		// Un-idle us
		$this->shoutbox->unIdle($instance, $chatroom);

		// Initialise saving
		$cleanedInput = $this->app->filter(array(
			'shoutid' 		=> TYPE_INT,
			'message' 		=> TYPE_NOHTML,
			'type' 			=> TYPE_STR,
			'pmuserid' 		=> TYPE_UINT,
			'chatroomid' 	=> TYPE_UINT,
			'tabid' 		=> TYPE_STR,
			'source' 		=> TYPE_STR,
		));

		// Do url decode
		$cleanedInput['message'] = urldecode($cleanedInput['message']);

		// Set tabid
		$tabid = (in_array($cleanedInput['tabid'], array('aop', 'activeusers', 'shoutnotifs', 'systemmsgs')) ? 'shouts' : $cleanedInput['tabid']) . $instance['instanceid'];

		if (substr($tabid, 0, 2) == 'pm')
		{
			// Override this type
			$cleanedInput['type'] = 'pm';
		}

		// Make sure it's set
		$shouttype = (isset($this->shoutbox->shouttypes[$cleanedInput['type']]) ? $cleanedInput['type'] : 'shout');

		// Init the Shout DM
		$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
			$shoutDm->setInfo('instance', $instance);

		if ($cleanedInput['shoutid'])
		{
			if (!$shoutInfo = $this->_getDb()->fetchRow('
				SELECT *
				FROM $dbtech_vbshout_shout AS vbshout
				WHERE shoutid = ?
			', array(
				$cleanedInput['shoutid']
			)))
			{
				// Shout didn't exist
				return false;
			}

			// Set the existing data
			$shoutDm->setExistingData($shoutInfo);

			// Only thing that's changed
			$shoutInfo['message'] = $cleanedInput['message'];
		}
		else
		{
			// Construct the shout info on the fly
			$shoutInfo = array(
				'id' 			=> $cleanedInput['pmuserid'],
				'message' 		=> $cleanedInput['message'],
				'type'			=> $this->shoutbox->shouttypes[$shouttype],
				'instanceid' 	=> $instance['instanceid'],
				'chatroomid'	=> $cleanedInput['chatroomid'],
			);
		}

		// Grab this
		$chatroomCache = $this->cache->get('chatroom');

		// Shorthand
		if ($cleanedInput['chatroomid'] AND $chatroom = $chatroomCache[$cleanedInput['chatroomid']])
		{
			// Ensure the proper instance id is set
			$shoutInfo['instanceid'] = $chatroom['instanceid'];
		}

		// Set the shout info
		$shoutDm->bulkSet($shoutInfo);

		// Error checking
		$shoutDm->preSave();

		if (!isset($this->shoutbox->fetched['stopSave']))
		{
			// Now finally save
			$shoutDm->save();
		}

		if (isset($this->shoutbox->fetched['error']) AND $this->shoutbox->fetched['error'])
		{
			// We haz error
			return false;
		}

		if (!isset($this->shoutbox->fetched['stopSave']))
		{
			// Update the AOP
			$this->shoutbox->setAop('shouts', $instance['instanceid'], (substr($tabid, 0, 2) != 'pm'), true);

			if ($shouttype == $this->shoutbox->shouttypes['notif'])
			{
				// Update the AOP
				$this->shoutbox->setAop('shoutnotifs', $instance['instanceid'], false, true);
			}

			if ($shouttype == $this->shoutbox->shouttypes['system'])
			{
				// Update the AOP
				$this->shoutbox->setAop('systemmsgs', $instance['instanceid'], false, true);
			}
		}

		// Fetch the file in question
		$fetch = new DBTech_Shout_Action_Ajax_Fetch();
		$fetch->__handle($instance, $chatroom, $args);

		
	}
}