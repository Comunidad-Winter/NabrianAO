<?php
class DBTech_Shout_ActionAdmin_Notifications extends DBTech_Shout_ActionAdmin
{
	public function actionIndex()
	{
		// Init this
		$instanceCache = $this->cache->get('instance');

		$forumids = array();
		foreach ($this->app->getForumCache() as $forumid => $forum)
		{
			
			switch ($this->app->getSystem())
			{
				case 'XenForo':
					if ($forum['depth'] != 0)
					{
						// This forum isn't a parent forum
						continue;
					}
					break;

				case 'vBulletin':
					if ($forum['parentid'] != -1)
					{
						// This forum isn't a parent forum
						continue;
					}
					break;
			}
			

			$forumids[] = $forumid;
		}


		$headings = array();
		$headings[] = $this->app->phrase('forum');
		foreach ($instanceCache as $instanceid => $instance)
		{
			$headings[] = $instance['name'];
		}

		print_cp_header(strip_tags($this->app->phrase('dbtech_vbshout_editing_x_y', array('param1' => $this->app->phrase('dbtech_vbshout_notifications'), 'param2' => $this->app->phrase('dbtech_vbshout_instance')))));
		print_form_header('vbshout', 'notifications');
		construct_hidden_code('action', 'update');
		print_table_header($this->app->phrase('dbtech_vbshout_editing_x_y', array('param1' => $this->app->phrase('dbtech_vbshout_notifications'), 'param2' => $this->app->phrase('dbtech_vbshout_instance'))), count($headings));
		print_cells_row($headings, true);

		$forumCache = $this->app->getForumCache();
		foreach ($forumids as $forumid)
		{
			// Shorthand
			$forum = $forumCache[$forumid];
			$cell = array();
			$cell[] = construct_depth_mark($forum['depth'],'- - ') . $forum['title'];
			foreach ($instanceCache as $instanceid => $instance)
			{
				$cell[] = '
					<center>
						<input type="hidden" name="forum[' . $instanceid . '][' . $forumid . '][newthread]" value="0" />
						<label for="cb_forum_' . $instanceid . '_' . $forumid . '_newthread">
							<input type="checkbox" name="forum[' . $instanceid . '][' . $forumid . '][newthread]" id="cb_forum_' . $instanceid . '_' . $forumid . '_newthread" value="1"' . ((isset($instance['notices'][$forumid]) AND ($instance['notices'][$forumid] & 1)) ? ' checked="checked"' : '') . '/>
							' . $this->app->phrase('dbtech_vbshout_new_thread') . '
						</label>

						<input type="hidden" name="forum[' . $instanceid . '][' . $forumid . '][newreply]" value="0" />
						<label for="cb_forum_' . $instanceid . '_' . $forumid . '_newreply">
							<input type="checkbox" name="forum[' . $instanceid . '][' . $forumid . '][newreply]" id="cb_forum_' . $instanceid . '_' . $forumid . '_newreply" value="2"' . ((isset($instance['notices'][$forumid]) AND ($instance['notices'][$forumid] & 2)) ? ' checked="checked"' : '') . '/>
							' . $this->app->phrase('dbtech_vbshout_new_reply') . '
						</label>
					</center>
				';
			}
			print_cells_row($cell, false, false, -5, 'middle', false, true);
		}
		print_cells_row(false);
		print_submit_row($this->app->phrase('save'), false, count($headings));
	}

	public function actionUpdate()
	{
		// Grab stuff
		$cleanedInput = $this->app->filter(array(
			'forum' 	=> TYPE_ARRAY,
		));

		// Init this
		$instanceCache = $this->cache->get('instance');

		foreach ($cleanedInput['forum'] as $instanceid => $forum)
		{
			if (!$existing = $instanceCache[$instanceid])
			{
				// Invalid isntance
				continue;
			}

			$SQL = array();
			foreach ($forum as $forumid => $config)
			{
				if (!isset($SQL[$forumid]))
				{
					// Ensure this is set
					$SQL[$forumid] = 0;
				}

				foreach ($config as $val)
				{
					// Notice flag
					$SQL[$forumid] += $val;
				}
			}

			// init data manager
			$instanceDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Instance', DBTech_Shout_DataManager::ERROR_EXCEPTION);
				$instanceDm->setExistingData($existing);
				$instanceDm->set('notices', $SQL);
			$instanceDm->save();
			unset($instanceDm);
		}

		$this->app->redirect($this->app->phrase('dbtech_vbshout_x_y', array(
			'param1' => $this->app->phrase('dbtech_vbshout_notifications'),
			'param2' => $this->app->phrase('dbtech_vbshout_edited')
		)), $this->app->link('notifications'));
	}
}
?>