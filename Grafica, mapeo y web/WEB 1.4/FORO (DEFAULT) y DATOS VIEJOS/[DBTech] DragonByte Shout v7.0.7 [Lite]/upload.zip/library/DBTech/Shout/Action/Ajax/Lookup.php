<?php
class DBTech_Shout_Action_Ajax_Lookup extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 32))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter(array(
			'username' => TYPE_STR,
		));

		// Do url decode
		$cleanedInput['username'] = urldecode($cleanedInput['username']);

		if (!$instance['options']['enablepms'])
		{
			$this->shoutbox->fetched['error'] = $this->app->phrase('dbtech_vbshout_pms_disabled');
			return false;
		}

		if ($cleanedInput['username'] == $this->app->getUserInfo('username'))
		{
			$this->shoutbox->fetched['error'] = $this->app->phrase('dbtech_vbshout_invalid_username');
			return false;
		}

		if (!$userId = $this->_getDb()->fetchOne('
			SELECT =user:userid=
			FROM $user
			WHERE username = ?
		', array(
			$cleanedInput['username']
		)))
		{
			$this->shoutbox->fetched['error'] = $this->app->phrase('dbtech_vbshout_invalid_username');
			return false;
		}

		// Return the userid
		$this->shoutbox->fetched['pmuserid'] = $userId;
	}
}