<?php
class DBTech_Shout_Application_ResponseErrorException extends Exception {}