<?php
class DBTech_Shout_Application_ResponseRedirectException extends Exception {}