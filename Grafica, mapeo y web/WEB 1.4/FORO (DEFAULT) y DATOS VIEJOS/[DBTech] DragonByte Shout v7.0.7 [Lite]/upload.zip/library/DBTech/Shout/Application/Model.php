<?php
abstract class DBTech_Shout_Application_Model
{
	protected static $_instance;

	protected $app;
	protected $cache;

	public $debug = false;


	public function __construct()
	{
		// Get the instance
		$this->app = DBTech_Shout_Application_Core::getInstance();
		$this->cache = DBTech_Shout_Cache::getInstance();
	}

	public function sendAlert(array $toUser, array $fromUser, $contentType, $contentId, $action, array $extraData = null)
	{
		switch ($this->app->getSystem())
		{
			case 'XenForo':
				// Grab our user model
				$userModel = $this->app->createModel('XenForo_Model_User');

				if (!$userModel->isUserIgnored($toUser, $fromUser['user_id'])
					AND XenForo_Model_Alert::userReceivesAlert($toUser, 'dbtech_vbshout' . ($contentType ? ('_' . $contentType) : ''), $action)
				// check whether this is working
				)
				{
					// Now add the alert
					XenForo_Model_Alert::alert(
						$toUser['user_id'],
						$fromUser['user_id'],
						$fromUser['username'],
						'dbtech_vbshout' . ($contentType ? ('_' . $contentType) : ''),
						$contentId,
						$action,
						$extraData
					);
				}
				break;
		}
	}

	/**
	 * Applies a limit clause to the provided query if a limit value is specified.
	 * If the limit value is 0 or less, no clause is applied.
	 *
	 * @param string $query SQL query to run
	 * @param integer $limit Number of records to limit to; ignored if <= 0
	 * @param integer $offset Offset from the start of the records. 0+
	 *
	 * @return string Query with limit applied if necessary
	 */
	public function limitQueryResults($query, $limit, $offset = 0)
	{
		if ($limit > 0)
		{
			if ($offset < 0)
			{
				$offset = 0;
			}
			return $this->_getDb()->limit($query, $limit, $offset);
		}
		else
		{
			return $query;
		}
	}

	/**
	 * Adds a join to the set of fetch options. Join should be one of the constants.
	 *
	 * @param array $fetchOptions
	 * @param integer $join
	 */
	public function addFetchOptionJoin(array &$fetchOptions, $join)
	{
		if (isset($fetchOptions['join']))
		{
			$fetchOptions['join'] |= $join;
		}
		else
		{
			$fetchOptions['join'] = $join;
		}
	}

	/**
	 * Gets a list of SQL conditions in the format for a clause. This always returns
	 * a value that can be used in a clause such as WHERE.
	 *
	 * @param array $sqlConditions
	 *
	 * @return string
	 */
	public function getConditionsForClause(array $sqlConditions)
	{
		if ($sqlConditions)
		{
			return '(' . implode(') AND (', $sqlConditions) . ')';
		}
		else
		{
			return '1=1';
		}
	}

	/**
	 * Gets the order by clause for an SQL query.
	 *
	 * @param array $choices
	 * @param array $fetchOptions
	 * @param string $defaultOrderSql
	 *
	 * @return string Order by clause or empty string
	 */
	public function getOrderByClause(array $choices, array $fetchOptions, $defaultOrderSql = '')
	{
		$orderSql = null;

		if (!empty($fetchOptions['order']) && isset($choices[$fetchOptions['order']]))
		{
			$orderSql = $choices[$fetchOptions['order']];

			if (empty($fetchOptions['direction']))
			{
				$fetchOptions['direction'] = 'asc';
			}

			$dir = (strtolower($fetchOptions['direction']) == 'desc' ? 'DESC' : 'ASC');
			$orderSqlOld = $orderSql;
			$orderSql = sprintf($orderSql, $dir);
			if ($orderSql === $orderSqlOld)
			{
				$orderSql .= ' ' . $dir;
			}
		}

		if (!$orderSql)
		{
			$orderSql = $defaultOrderSql;
		}
		return ($orderSql ? 'ORDER BY ' . $orderSql : '');
	}

	/**
	 * Gets the group by clause for an SQL query.
	 *
	 * @param array $choices
	 * @param array $fetchOptions
	 * @param string $defaultGroupSql
	 *
	 * @return string Group by clause or empty string
	 */
	public function getGroupByClause(array $choices, array $fetchOptions, $defaultGroupSql = '')
	{
		$groupSql = null;

		if (!empty($fetchOptions['group']) && isset($choices[$fetchOptions['group']]))
		{
			$groupSql = $choices[$fetchOptions['group']];
		}

		if (!$groupSql)
		{
			$groupSql = $defaultGroupSql;
		}
		return ($groupSql ? 'GROUP BY ' . $groupSql : '');
	}

	/**
	 * Prepares the limit-related fetching options that can be applied to various queries.
	 * Includes: limit, offset, page, and perPage.
	 *
	 * @param array $fetchOptions Unprepared options
	 *
	 * @return array Limit options; keys: limit, offset
	 */
	public function prepareLimitFetchOptions(array $fetchOptions)
	{
		$limitOptions = array('limit' => 0, 'offset' => 0);
		if (isset($fetchOptions['limit']))
		{
			$limitOptions['limit'] = intval($fetchOptions['limit']);
		}
		if (isset($fetchOptions['offset']))
		{
			$limitOptions['offset'] = intval($fetchOptions['offset']);
		}

		if (isset($fetchOptions['perPage']) && $fetchOptions['perPage'] > 0)
		{
			$limitOptions['limit'] = intval($fetchOptions['perPage']);
		}

		if (isset($fetchOptions['page']))
		{
			$page = intval($fetchOptions['page']);
			if ($page < 1)
			{
				$page = 1;
			}

			$limitOptions['offset'] = intval(($page - 1) * $limitOptions['limit']);

			if (!empty($fetchOptions['pageExtra']) && $limitOptions['limit'])
			{
				$limitOptions['limit'] += max(0, intval($fetchOptions['pageExtra']));
			}
		}

		return $limitOptions;
	}

	/**
	 * Ensures that a valid cut-off operator is passed.
	 *
	 * @param string $operator
	 * @param boolean $allowBetween
	 */
	public function assertValidCutOffOperator($operator, $allowBetween = false)
	{
		switch ($operator)
		{
			case '<':
			case '<=':
			case '=':
			case '>':
			case '>=':
			case '!=':
				break;

			case '>=<':
				if ($allowBetween)
				{
					return;
				}
				// break missing intentionally

			default:
				throw new DBTech_Shout_Application_ResponseErrorException('Invalid cut off operator: ' . $operator);
		}
	}

	protected function getModelFromCache($class)
	{
		return DBTech_Shout_Application::getModelFromCache($class);
	}

	protected function getApplicationFromCache($class)
	{
		return DBTech_Shout_Application::getApplicationFromCache($class);
	}

	protected function _getDb()
	{
		return DBTech_Shout_Application_Core::getInstance()->_getDb();
	}

	protected function _getTemplate()
	{
		return DBTech_Shout_Application_Template::getInstance();
	}

	public static final function getInstance()
	{
		if (!self::$_instance)
		{
			self::$_instance = new static();
		}

		return self::$_instance;
	}
}