<?php
class DBTech_Shout_Core_Admin extends DBTech_Shout_Application_Core_Admin
{
}
?>