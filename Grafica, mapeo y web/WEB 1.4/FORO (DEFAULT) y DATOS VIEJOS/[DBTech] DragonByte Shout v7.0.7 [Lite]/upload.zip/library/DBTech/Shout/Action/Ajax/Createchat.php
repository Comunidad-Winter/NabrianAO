<?php
class DBTech_Shout_Action_Ajax_Createchat extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 1))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter([
			'title' => TYPE_NOHTML
		]);

		// Init the Shout DM
		$shoutDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Shout', DBTech_Shout_DataManager::ERROR_ARRAY);
			$shoutDm->setInfo('instance', $instance);
			$shoutDm->bulkSet([
				'instanceid' => $instance['instanceid'],
				'message' => '/createchat ' . urldecode($cleanedInput['title']),
			]);
		$shoutDm->save();
	}
}