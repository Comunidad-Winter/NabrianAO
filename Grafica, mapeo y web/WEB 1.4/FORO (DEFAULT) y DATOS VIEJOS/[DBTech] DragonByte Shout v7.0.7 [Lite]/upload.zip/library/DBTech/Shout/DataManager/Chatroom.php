<?php
/**
* DataManager for Chatrooms.
*
* @package DBTech_Shout
*/
class DBTech_Shout_DataManager_Chatroom extends DBTech_Shout_DataManager
{
	const TABLE_NAME = 'dbtech_vbshout_chatroom';
	const TABLE_ID = 'chatroomid';

	protected $_fields = [
		self::TABLE_ID		=> [
			'type'				=> 'uint',
			'autoIncrement' 	=> true
		],
		'title' 			=> [
			'type' 				=> 'string',
			'required' 			=> true,
		],
		'description' 		=> [
			'type' 				=> 'string',
			'required' 			=> false,
		],
		'active' 			=> [
			'type' 				=> 'boolean',
			'required' 			=> false,
		],
		'autojoin' 			=> [
			'type' 				=> 'boolean',
			'required' 			=> false,
		],
		'instanceid' 		=> [
			'type' 				=> 'uint',
			'required' 			=> false,
			'verification' 		=> ['DBTech_Shout_DataManager_Helper_Instance', '_verifyInstance'],
		],
		'membergroupids' 		=> [
			'type' 				=> 'unknown',
			'required' 			=> false,
			'verification' 		=> ['$this', 'verifyCommaList'],
		],
		'creator' 		=> [
			'type' 				=> 'uint',
			'required' 			=> false,
			'verification' 		=> ['$this', 'verifyUserId'],
		],
		'members' => [
			'type' 				=> 'serialized',
			'required' 			=> false,
		],
	];

	/**
	* Gets the actual existing data out of data that was passed in. See parent for explanation.
	*
	* @param mixed
	*
	* @return array|false
	*/
	protected function _getExistingData($data)
	{
		return $this->_getDb()->fetchRow('SELECT * FROM $' . self::TABLE_NAME . ' WHERE ' . self::TABLE_ID . ' = ' . $this->_getDb()->quote($data));
	}

	/**
	* Gets SQL condition to update the existing record.
	*
	* @return string
	*/
	protected function _getUpdateCondition()
	{
		return 'chatroomid = ' . $this->_getDb()->quote($this->getExisting('chatroomid'));
	}

	/**
	 * Post-save handling.
	 */
	protected function _postSave()
	{
		$this->cache->build('chatroom');
	}

	/**
	 * Post-delete handling.
	 */
	protected function _postDelete()
	{
		// remove shouts belonging to this instance
		$this->_getDb()->delete('dbtech_vbshout_shout', '`chatroomid` = ' . intval($this->getExisting('chatroomid')));

		// Rebuild the cache
		$this->cache->build('chatroom');

		// Rebuild shout counters
		DBTech_Shout_Shoutbox::getInstance()->buildShoutsCounter();
	}
}