<?php
class DBTech_Shout_Application_Core_Admin extends DBTech_Shout_Application_Core
{
	public function __construct()
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				try
				{
					$fc = XenForo_Application::get('fc');
				}
				catch (Exception $e)
				{
					if (isset($GLOBALS['dependencies']))
					{
						// Grab from global
						$dependencies = $GLOBALS['dependencies'];
					}
					else
					{
						// Store this
						$dependencies = new XenForo_Dependencies_Admin();
						$dependencies->preLoadData();
					}

					$fc = new XenForo_FrontController($dependencies);
					$fc->setup();
					$fc->setRequestPaths();

					// Now set this
					XenForo_Application::set('fc', $fc);
				}

				$startTime = microtime(true);

				// Set the version number
				$this->versionnumber = XenForo_Application::$version;

				if (!defined('TYPE_ARRAY'))
				{
					// Define important constants
					define('TYPE_ARRAY', 		XenForo_Input::ARRAY_SIMPLE);
					define('TYPE_UINT', 		XenForo_Input::UINT);
					define('TYPE_INT', 			XenForo_Input::INT);
					define('TYPE_UNUM', 		XenForo_Input::UNUM);
					define('TYPE_NUM', 			XenForo_Input::NUM);
					define('TYPE_STR', 			XenForo_Input::STRING);
					define('TYPE_BOOL', 		XenForo_Input::BOOLEAN);
					define('TYPE_UNIXTIME', 	'unixtime');
					define('TYPE_NOHTML', 		'nohtml');

					define('IN_CONTROL_PANEL',  true);
				}
				break;

			case 'vBulletin':
				// Set the version number
				$this->versionnumber = $GLOBALS['vbulletin']->versionnumber;
				break;
		}
	}

	public function error($message, array $params = [])
	{
		if (isset($params['_exception']))
		{
			$exception = $this->traceHtml($params['_exception']);
			$message = "<div class=\"baseHtml exception\"><p>$exception[error]</p> <ol class=\"traceHtml\">\n$exception[traceHtml]</ol></div>";
		}

		print_cp_message($message);
	}

	public function redirect($message, $url, array $redirectParams = [], $forceRedirect = false)
	{
		print_cp_message($message, $url);
	}

	public function link($action, array $linkParams = [], array $linkData = [])
	{
		switch ($this->getSystem())
		{
			case 'XenForo':
				$url = XenForo_Link::buildAdminLink('dbtech-shout/' . $action, $linkData, $linkParams);
				break;

			case 'vBulletin':
				$url = 'vbshout.php' . ($action ? ('?do=' . $action) : '') . ($linkParams ? ($action ? '&' : '?') . http_build_query($linkParams) : '');
				break;
		}

		return $url;
	}

	protected function _getActionClassName($class)
	{
		return 'DBTech_Shout_ActionAdmin_' . ucfirst($class);
	}
}
?>