<?php

class DBTech_Shout_XenForo_Install_Uninstall
{
	/**
	 * Instance manager.
	 *
	 * @var DBTech_Shout_XenForo_Install
	 */
	private static $_instance;

	/**
	 * Database object
	 *
	 * @var Zend_Db_Adapter_Abstract
	 */
	protected $_db;

	/**
	 * Gets the installer instance.
	 *
	 * @return DBTech_Shout_XenForo_Install
	 */
	public static final function getInstance()
	{
		if (!self::$_instance)
		{
			self::$_instance = new static();
		}

		return self::$_instance;
	}

	/**
	 * Begins the installation process and picks the proper install routine.
	 *
	 * See see XenForo_Model_Addon::installAddOnXml() for more details about
	 * the arguments passed to this method.
	 *
	 * @param array Information about the existing version (if upgrading)
	 * @param array Information about the current version being installed
	 *
	 * @return void
	 */
	public static function uninstall($addOnData)
	{
		// create our uninstall object
		$uninstall = self::getInstance();
		$uninstall->_uninstall();
	}

	/**
	 * Uninstall routine for all versions
	 *
	 * @return void
	 */
	protected function _uninstall()
	{
		$db = XenForo_Application::getDb();

		foreach (array(
			'button',
			'chatroom',
			'chatroommember',
			'command',
			'deeplog',
			'ignorelist',
			'instance',
			'log',
			'report',
			'session',
			'shout',
		) as $table)
		{
			try
			{
				// Quickly drop all tables
				$db->query("DROP TABLE IF EXISTS xf_dbtech_vbshout_{$table}");
			}
			catch (Zend_Db_Exception $e) {}
		}

		foreach (array(
			'banned',
			'displayorder',
			'invisiblesettings',
			'pm',
			'settings',
			'shoutboxsize',
			'shoutboxsize_detached',
			'shouts',
			'shouts_lifetime',
			'shoutstyle',
			'shoutarea',
			'silenced',
			'soundsettings',
		) as $column)
		{
			try
			{
				// Quickly drop all columns
				$db->query("ALTER TABLE `xf_user` DROP dbtech_vbshout_{$column}");
			}
			catch (Zend_Db_Exception $e) {}
		}

		try
		{
			$db->query("
				DELETE FROM `xf_data_registry`
				WHERE data_key LIKE 'dbtech_vbshout_%'
			");
		}
		catch (Zend_Db_Exception $e) {}
	}
}