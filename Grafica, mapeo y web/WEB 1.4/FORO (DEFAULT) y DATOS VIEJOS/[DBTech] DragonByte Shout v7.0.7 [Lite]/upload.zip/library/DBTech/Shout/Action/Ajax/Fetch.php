<?php
class DBTech_Shout_Action_Ajax_Fetch extends DBTech_Shout_Action_Ajax
{
	public function __handle(array $instance, array $chatroom = array(), array $args = array())
	{
		if (!($instance['options']['activitytriggers'] & 512))
		{
			// Un-idle us
			$this->shoutbox->unIdle($instance, $chatroom);
		}

		$cleanedInput = $this->app->filter(array(
			'tabs' 		=> TYPE_ARRAY,
			'pmtime' 	=> TYPE_UINT,
			'type' 		=> TYPE_STR,
			'shoutid' 	=> TYPE_UINT
		));

		// Grab this
		$chatroomCache = $this->cache->get('chatroom');

		$chatRooms = $this->_getDb()->fetchAllSingleKeyed('
			SELECT chatroomid, user.username
			FROM $dbtech_vbshout_chatroommember AS chatroommember
			LEFT JOIN $user AS user ON(user.=user:userid= = chatroommember.invitedby)
			WHERE chatroommember.userid = ?
				AND status = 0
		', 'chatroomid', 'username', array(
			$this->app->getUserInfo('userid')
		));
		foreach ($chatRooms as $chatRoomId => $username)
		{
			if (
				!$chatroomCache[$chatRoomId]['active']
				OR (
					$chatroomCache[$chatRoomId]['instanceid'] != $instance['instanceid']
					AND $chatroomCache[$chatRoomId]['instanceid'] != 0
				)
			)
			{
				// Inactive chat room
				continue;
			}

			// Store information regarding the chatroom
			$this->shoutbox->fetched['chatrooms'][] = array(
				'chatroomid' 	=> $chatRoomId,
				'instanceid' 	=> $chatroomCache[$chatRoomId]['instanceid'],
				'title' 		=> $chatroomCache[$chatRoomId]['title'],
				'username' 		=> ($username ? $username : 'N/A')
			);
		}

		foreach ($cleanedInput['tabs'] as $tabid => $enabled)
		{
			if ($tabid == 'activeusers')
			{
				// Shouldn't happen
				continue;
			}

			if (substr($tabid, 0, 8) == 'chatroom')
			{
				// Get the chatroom id
				$chatroomid = explode('_', $tabid);
				$chatroomid = $chatroomid[1];

				// Already set
				$instanceid = '';
			}
			else if (substr($tabid, 0, 2) == 'pm')
			{
				// Already set
				$instanceid = '';
			}
			else
			{
				// Just use the normal instance id
				$instanceid = $instance['instanceid'];
			}

			// File system
			$mtime = $this->shoutbox->fetchAopRaw($tabid, $instanceid);

			if ($mtime)
			{
				// Send back AOP times
				$this->shoutbox->fetched['aoptimes'][] = array(
					'aoptime' 	=> $mtime,
					'tabid' 	=> $tabid,
					'nosound' 	=> 0,
				);
			}
		}

		if ($this->app->getUserInfo('dbtech_vbshout_pm') !== false AND $this->app->getUserInfo('dbtech_vbshout_pm') > $cleanedInput['pmtime'])
		{
			// Set new PM time
			$this->shoutbox->fetched['pmtime'] = $this->app->getUserInfo('dbtech_vbshout_pm');
		}

		if (substr($cleanedInput['type'], 0, 2) == 'pm')
		{
			// Fetch AOP time
			$this->shoutbox->fetchAop($cleanedInput['type'], '');

			// Fetch the userid from the PM type
			$userid = explode('_', $cleanedInput['type']);
			$userid = $userid[1];

			// Set shout args to only include shouts made between self and result of substr
			//$args['userids'] 	= array($this->app->getUserInfo('userid'), $userid);
			$args['types']		= $this->shoutbox->shouttypes['pm'];
			$args['onlyuser']	= $userid;

			// Override type
			$cleanedInput['type'] = 'shouts';
		}

		if ($cleanedInput['type'] == 'chatrooms')
		{
			$userid = $this->app->getUserInfo('userid');

			$this->shoutbox->fetched['content'] = '';
			foreach ($chatroomCache as $chatroomId => $chatroom)
			{
				if (
					$chatroom['membergroupids']
					AND !$chatroom['autojoin']
					AND (
						$chatroom['membergroupids'] == '-1'
						OR $this->app->isMemberOf($this->app->getUserInfo(), explode(',', $chatroom['membergroupids']))
					)
				)
				{
					$this->shoutbox->fetched['content'] .= $this->_getTemplate()->renderTemplate('dbtech_shout_chatroom_bit', [
						'chatroom' => $chatroom,
						'members' => count($chatroom['members']),
						'joined' => isset($chatroom['members'][$userid])
					]);
				}
			}
		}
		else if (substr($cleanedInput['type'], 0, 8) == 'chatroom')
		{
			// Fetch the chatroomid from the chatroom type
			$chatroomid = explode('_', $cleanedInput['type']);
			$chatroomid = $chatroomid[1];

			// Set shout args to only include shouts posted to said chat room
			$args['chatroomid']	= $chatroomid;

			$userid = $this->app->getUserInfo('userid');

			if (
				!isset($chatroomCache[$chatroomid])
				OR !$chatroom = $chatroomCache[$chatroomid]
				OR !$chatroom['active']
				OR (
					(
						!$chatroom['membergroupids']
						OR !$chatroom['autojoin']
					)
					AND !isset($chatroom['members'][$userid])
				)
				OR (
					$chatroom['membergroupids']
					AND $chatroom['membergroupids'] != '-1'
					AND !$this->app->isMemberOf($this->app->getUserInfo(), explode(',', $chatroom['membergroupids']))
				)
			)
			{
				// Wrong chatroom
				$this->shoutbox->leaveChatroom($chatroom, $this->app->getUserInfo('userid'));
				$this->shoutbox->fetched['error'] = 'disband_' . $chatroomid;
				unset($args['chatroomid']);
				return false;
			}

			// Fetch AOP time
			$this->shoutbox->fetchAop('chatroom_' . $chatroomid . '_', $chatroom['instanceid']);

			$cleanedInput['type'] = 'shouts';
		}

		if ((
			!isset($instance['options']['shoutboxtabs']) OR ($instance['options']['shoutboxtabs'] & 4)) AND
			$instance['permissions_parsed']['canmodchat']
		)
		{
			$this->shoutbox->fetched['activereports'] = $this->_getDb()->fetchOne('
				SELECT COUNT(*) AS numunhandled
				FROM $dbtech_vbshout_report
				WHERE handled = 0
					AND instanceid = ?
			', array(
				$instance['instanceid']
			));
		}

		if ($cleanedInput['type'] == 'shoutnotifs')
		{
			// Fetch AOP time
			$this->shoutbox->fetchAop($cleanedInput['type'], $instance['instanceid']);

			$args['types']		= $this->shoutbox->shouttypes['notif'];

			// Override type
			$cleanedInput['type'] = 'shouts';
		}

		if ($cleanedInput['type'] == 'systemmsgs')
		{
			// Fetch AOP time
			$this->shoutbox->fetchAop($cleanedInput['type'], $instance['instanceid']);

			$args['types']		= $this->shoutbox->shouttypes['system'];

			// Override type
			$cleanedInput['type'] = 'shouts';
		}

		if ($cleanedInput['type'] == 'shouts' OR isset($this->shoutbox->fetched['pmtime']))
		{
			// Fetch AOP time
			$this->shoutbox->fetchAop('shouts', $instance['instanceid']);

			// Fetch shouts
			$this->shoutbox->fetchShouts($instance, $chatroom, $args);
		}

		if ($cleanedInput['type'] == 'shout')
		{
			// What shout we want to be editing
			if (!$existing = $this->_getDb()->fetchRow('
				SELECT *
				FROM $dbtech_vbshout_shout AS vbshout
				WHERE shoutid = ?
			', array(
				$cleanedInput['shoutid']
			)))
			{
				// Shout didn't exist
				$this->shoutbox->fetched['error'] = $this->app->phrase('dbtech_vbshout_invalid_shout');
				return false;
			}

			if ($exists['userid'] == $this->app->getUserInfo('userid') AND !$instance['permissions_parsed']['caneditown'])
			{
				// We can't edit our own shouts
				$this->shoutbox->fetched['error'] = $this->app->phrase('dbtech_vbshout_may_not_edit_own');
				return false;
			}

			if ($exists['userid'] != $this->app->getUserInfo('userid') AND !$instance['permissions_parsed']['caneditothers'])
			{
				// We don't have permission to edit others' shouts
				$this->shoutbox->fetched['error'] = $this->app->phrase('dbtech_vbshout_may_not_edit_others');
				return false;
			}

			// Set the editor content
			$this->shoutbox->fetched['editor'] = $exists['message'];
		}

		if ($cleanedInput['type'] == 'activeusers')
		{
			// Array of all active users
			$this->shoutbox->fetchActiveUsers($instance, $chatroom, true);

			// Finally set the content
			$this->shoutbox->fetched['content'] = '<li>' . $this->shoutbox->fetched['activeusers']['usernames'] = (count($this->shoutbox->activeusers) ? implode(', ', $this->shoutbox->activeusers) : $this->app->phrase('dbtech_vbshout_no_active_users')) . '</li>';

			// Query for active users
			$this->shoutbox->fetched['activeusers']['count'] = count($this->shoutbox->activeusers);
		}
	}
}