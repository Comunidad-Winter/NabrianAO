<?php
class DBTech_Shout_Shoutbox
{
	protected static $_instance;

	/**
	* Whether we have the pro version or not
	*
	* @public	boolean
	*/
	public $isPro			= false;

	/**
	* List of shout types
	*
	* @private	array
	*/
	public $shouttypes 		= [
		'shout'		=> 1,
		'pm'		=> 2,
		'me'		=> 4,
		'notif'		=> 8,
		'custom'	=> 16,
		'system'	=> 32,
		'mention'	=> 64,
		'tag'		=> 128,
		'thanks'	=> 256,
		'quote'		=> 512,
	];

	/**
	* What chat tabs we want to create
	* [$instanceId] = array('$tabId' => array('text' => 'Tab Text', 'canclose' => '0', 'showfunc' => '', 'closefunc' => ''))
	*
	* @public	array
	*/
	public $tabs 			= [];

	/**
	* List of shout styles for the current user
	*
	* @private	array
	*/
	public $shoutstyle 		= [];

	/**
	* List of all info returned by the fetcher
	*
	* @public	array
	*/
	public $fetched 		= [];

	/**
	* The currently active users
	*
	* @public	array
	*/
	public $activeusers 	= NULL;

	/**
	* Whether we've auto displayed JS/CSS already
	*
	* @public	array
	*/
	public $hasIncludedJS 	= false;

	/**
	* The path to the data directory
	*
	* @public	string
	*/
	protected $dataDir 		= '';
	protected $prefix 		= '';

	protected $app;
	protected $cache;


	public function __construct()
	{
		// Get the instance
		$this->app = DBTech_Shout_Core::getInstance();
		$this->cache = DBTech_Shout_Cache::getInstance();

		

		if (!$this->app->getUserInfo('userid'))
		{
			// Sort this out
			$this->shoutstyle = array();

			// Default
			$this->app->setUserInfo('dbtech_vbshout_settings', 8191);
		}
		else
		{
			// Sort this out
			$this->shoutstyle = ($this->shoutstyle ? $this->shoutstyle : @unserialize($this->app->getUserInfo('dbtech_vbshout_shoutstyle')));
		}

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				if (!XenForo_Application::isRegistered('config'))
				{
					$dataDir = 'data';
				}
				else
				{
					$dataDir = XenForo_Application::get('config')->externalDataPath;
				}

				try
				{
					// Try to create the subdir
					XenForo_Helper_File::createDirectory($dataDir . '/dbtechShout', true);

					// We could make the subdirectory
					$this->dataDir = $dataDir . '/dbtechShout';
				}
				catch (Exception $e)
				{
					// Directory couldn't be created
					$this->dataDir = $dataDir;
					$this->prefix = 'dbtechShout-';
				}
				break;

			case 'vBulletin':
				$this->dataDir = 'dbtech/vbshout/aop';
				break;
		}
	}

	/**
	* Loads default instance options
	*
	* @param	array	The instance in question
	*/
	public function loadDefaultInstanceOptions(&$instance)
	{
		$instance['options']['logging'] 				= (isset($instance['options']['logging']) 					? $instance['options']['logging'] 					: ($this->isPro ? 31 	: 15));
		$instance['options']['editors'] 				= (isset($instance['options']['editors']) 					? $instance['options']['editors'] 					: ($this->isPro ? 511 	: 127));
		$instance['options']['notices'] 				= (isset($instance['options']['notices']) 					? $instance['options']['notices'] 					: ($this->isPro ? 255 	: 31));
		$instance['options']['optimisation'] 			= (isset($instance['options']['optimisation']) 				? $instance['options']['optimisation'] 				: 1);
		$instance['options']['allowsmilies'] 			= (isset($instance['options']['allowsmilies']) 				? $instance['options']['allowsmilies'] 				: 1);
		$instance['options']['activeusers'] 			= (isset($instance['options']['activeusers']) 				? $instance['options']['activeusers'] 				: 0);
		$instance['options']['sounds'] 					= (isset($instance['options']['sounds']) 					? $instance['options']['sounds'] 					: 1);
		$instance['options']['enableshoutsound'] 		= (isset($instance['options']['enableshoutsound']) 			? $instance['options']['enableshoutsound'] 			: 1);
		$instance['options']['enableinvitesound'] 		= (isset($instance['options']['enableinvitesound']) 		? $instance['options']['enableinvitesound'] 		: 1);
		$instance['options']['enablepmsound'] 			= (isset($instance['options']['enablepmsound']) 			? $instance['options']['enablepmsound'] 			: 1);
		$instance['options']['altshouts'] 				= (isset($instance['options']['altshouts']) 				? $instance['options']['altshouts'] 				: 0);
		$instance['options']['enableaccess'] 			= (isset($instance['options']['enableaccess']) 				? $instance['options']['enableaccess'] 				: 1);
		$instance['options']['anonymise'] 				= (isset($instance['options']['anonymise']) 				? $instance['options']['anonymise'] 				: 0);
		$instance['options']['allcaps'] 				= (isset($instance['options']['allcaps']) 					? $instance['options']['allcaps'] 					: 0);
		$instance['options']['invis'] 					= (isset($instance['options']['invis']) 					? $instance['options']['invis'] 					: 0);
		$instance['options']['maxshouts'] 				= (isset($instance['options']['maxshouts']) 				? $instance['options']['maxshouts'] 				: 20);
		$instance['options']['maxarchiveshouts'] 		= (isset($instance['options']['maxarchiveshouts']) 			? $instance['options']['maxarchiveshouts'] 			: 20);
		$instance['options']['height'] 					= (isset($instance['options']['height']) 					? $instance['options']['height'] 					: 150);
		$instance['options']['floodchecktime'] 			= (isset($instance['options']['floodchecktime']) 			? $instance['options']['floodchecktime'] 			: 3);
		$instance['options']['maxchars'] 				= (isset($instance['options']['maxchars']) 					? $instance['options']['maxchars'] 					: 256);
		$instance['options']['maximages'] 				= (isset($instance['options']['maximages']) 				? $instance['options']['maximages'] 				: 2);
		$instance['options']['idletimeout'] 			= (isset($instance['options']['idletimeout']) 				? $instance['options']['idletimeout'] 				: 180);
		$instance['options']['refresh'] 				= (isset($instance['options']['refresh']) 					? $instance['options']['refresh'] 					: 5);
		$instance['options']['maxchats'] 				= (isset($instance['options']['maxchats']) 					? $instance['options']['maxchats'] 					: 5);
		$instance['options']['shoutorder'] 				= (isset($instance['options']['shoutorder']) 				? $instance['options']['shoutorder'] 				: 'DESC');
		$instance['options']['maxsize'] 				= (isset($instance['options']['maxsize']) 					? $instance['options']['maxsize'] 					: 3);
		$instance['options']['postping_interval'] 		= (isset($instance['options']['postping_interval']) 		? $instance['options']['postping_interval'] 		: 50);
		$instance['options']['threadping_interval'] 	= (isset($instance['options']['threadping_interval']) 		? $instance['options']['threadping_interval'] 		: 50);
		$instance['options']['memberping_interval'] 	= (isset($instance['options']['memberping_interval']) 		? $instance['options']['memberping_interval'] 		: 50);
		$instance['options']['shoutboxtabs'] 			= (isset($instance['options']['shoutboxtabs']) 				? $instance['options']['shoutboxtabs'] 				: 7);
		$instance['options']['activitytriggers'] 		= (isset($instance['options']['activitytriggers']) 			? $instance['options']['activitytriggers'] 			: 0);
		$instance['options']['logging_deep'] 			= (isset($instance['options']['logging_deep']) 				? $instance['options']['logging_deep'] 				: 0);
		$instance['options']['logging_deep_system'] 	= (isset($instance['options']['logging_deep_system']) 		? $instance['options']['logging_deep_system'] 		: 0);
		$instance['options']['enablepms'] 				= (isset($instance['options']['enablepms']) 				? $instance['options']['enablepms'] 				: 1);
		$instance['options']['enablepmnotifs'] 			= (isset($instance['options']['enablepmnotifs']) 			? $instance['options']['enablepmnotifs'] 			: 1);
		$instance['options']['enable_sysmsg'] 			= (isset($instance['options']['enable_sysmsg']) 			? $instance['options']['enable_sysmsg'] 			: 1);
		$instance['options']['sounds_idle'] 			= (isset($instance['options']['sounds_idle']) 				? $instance['options']['sounds_idle'] 				: 0);
		$instance['options']['avatars_normal'] 			= (isset($instance['options']['avatars_normal']) 			? $instance['options']['avatars_normal'] 			: 0);
		$instance['options']['avatar_width_normal'] 	= (isset($instance['options']['avatar_width_normal']) 		? $instance['options']['avatar_width_normal'] 		: 11);
		$instance['options']['avatar_height_normal'] 	= (isset($instance['options']['avatar_height_normal']) 		? $instance['options']['avatar_height_normal'] 		: 11);
		$instance['options']['avatars_full'] 			= (isset($instance['options']['avatars_full']) 				? $instance['options']['avatars_full'] 				: 0);
		$instance['options']['avatar_width_full'] 		= (isset($instance['options']['avatar_width_full']) 		? $instance['options']['avatar_width_full'] 		: 22);
		$instance['options']['avatar_height_full'] 		= (isset($instance['options']['avatar_height_full']) 		? $instance['options']['avatar_height_full'] 		: 22);
		$instance['options']['maxshouts_detached'] 		= (isset($instance['options']['maxshouts_detached']) 		? $instance['options']['maxshouts_detached'] 		: 40);
		$instance['options']['height_detached'] 		= (isset($instance['options']['height_detached']) 			? $instance['options']['height_detached'] 			: 300);
		$instance['options']['refresh_idle'] 			= (isset($instance['options']['refresh_idle']) 				? $instance['options']['refresh_idle'] 				: 5);
		$instance['options']['archive_numtopshouters'] 	= (isset($instance['options']['archive_numtopshouters']) 	? $instance['options']['archive_numtopshouters'] 	: 10);
		$instance['options']['autodelete'] 				= (isset($instance['options']['autodelete']) 				? $instance['options']['autodelete'] 				: 0);
		$instance['options']['shoutarea'] 				= (isset($instance['options']['shoutarea']) 				? $instance['options']['shoutarea'] 				: 'below');
		$instance['options']['archive_link'] 			= (isset($instance['options']['archive_link']) 				? $instance['options']['archive_link'] 				: 0);
		$instance['options']['minposts'] 				= (isset($instance['options']['minposts']) 					? $instance['options']['minposts'] 					: 0);
		$instance['options']['minpostsperday'] 			= (isset($instance['options']['minpostsperday']) 			? $instance['options']['minpostsperday'] 			: 0);
		$instance['options']['timeformat'] 				= (isset($instance['options']['timeformat']) 				? $instance['options']['timeformat'] 				: 'H:i');
		$instance['options']['timeformat_old'] 			= (isset($instance['options']['timeformat_old']) 			? $instance['options']['timeformat_old'] 			: 'H:i, jS M Y');
		$instance['options']['blogping_interval'] 		= (isset($instance['options']['blogping_interval']) 		? $instance['options']['blogping_interval'] 		: 50);
		$instance['options']['shoutping_interval'] 		= (isset($instance['options']['shoutping_interval']) 		? $instance['options']['shoutping_interval'] 		: 50);
		$instance['options']['aptlping_interval'] 		= (isset($instance['options']['aptlping_interval']) 		? $instance['options']['aptlping_interval'] 		: 50);
		$instance['options']['tagping_interval'] 		= (isset($instance['options']['tagping_interval']) 			? $instance['options']['tagping_interval'] 			: 50);
		$instance['options']['mentionping_interval'] 	= (isset($instance['options']['mentionping_interval']) 		? $instance['options']['mentionping_interval'] 		: 50);
		$instance['options']['quoteping_interval'] 		= (isset($instance['options']['quoteping_interval']) 		? $instance['options']['quoteping_interval'] 		: 50);
		$instance['options']['quizmadeping_interval'] 	= (isset($instance['options']['quizmadeping_interval']) 	? $instance['options']['quizmadeping_interval'] 	: 50);
		$instance['options']['quiztakenping_interval'] 	= (isset($instance['options']['quiztakenping_interval']) 	? $instance['options']['quiztakenping_interval'] 	: 50);
	}

	/**
	* Sets up the permissions based on instance
	*
	* @param	array		The instance
	* @param	array|null	User Info to check (null = vBulletin Userinfo)
	*/
	public function loadInstancePermissions(&$instance, $userinfo = NULL)
	{
		// Set permissions shorthand
		$permarray = array();

		// Ensure we can fetch bitfields
		$permissions = $this->app->fetchBitfield('nocache|dbtech_vbshoutpermissions');

		if ($userinfo === NULL)
		{
			// We're using our own user info
			$userinfo = $this->app->getUserInfo();
		}
		else if ($userinfo['userid'] == $this->app->getUserInfo('userid') AND isset($instance['permissions_parsed']) AND is_array($instance['permissions_parsed']))
		{
			// Just return parsed
			return $instance['permissions_parsed'];
		}

		if (!isset($userinfo['usergroupid']))
		{
			foreach ($permissions as $permname => $bit)
			{
				// Default to false
				$permarray[$permname] = false;
			}

			return $permarray;
		}

		foreach (array_merge(array($userinfo['usergroupid']), explode(',', $userinfo['membergroupids'])) as $usergroupid)
		{
			if (!$usergroupid)
			{
				// Just skip it
				continue;
			}

			foreach ($permissions as $permname => $bit)
			{
				if (!isset($permarray[$permname]))
				{
					// Default to false
					$permarray[$permname] = false;
				}

				if (!$permarray[$permname] AND isset($instance['permissions'][$usergroupid]) AND ((int)$instance['permissions'][$usergroupid] & (int)$bit))
				{
					// Override to true
					$permarray[$permname] = true;
				}
			}
		}

		// Some hardcoded ones
		$permarray['ismanager'] 	= $this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager');
		$permarray['canpm']			= (isset($permarray['canpm']) ? $permarray['canpm'] : 1);

		if ($userinfo['userid'] == $this->app->getUserInfo('userid'))
		{
			// Set the completed permissions array
			$instance['permissions_parsed'] = $permarray;
		}

		return $permarray;
	}

	/**
	* Sets up the BBCode permissions based on instance
	*
	* @param	array		The instance
	* @param	array|null	User Info to check (null = vBulletin Userinfo)
	*/
	public function loadInstanceBbcodePermissions(&$instance, $userinfo = NULL)
	{
		// Set permissions shorthand
		$bitvalue 	= 0;
		$permarray = array();

		if ($userinfo === NULL)
		{
			// We're using our own user info
			$userinfo = $this->app->getUserInfo();
		}
		else if ($userinfo['userid'] == $this->app->getUserInfo('userid') AND isset($instance['bbcodepermissions_parsed']) AND is_array($instance['bbcodepermissions_parsed']))
		{
			// Just return parsed
			return $instance['bbcodepermissions_parsed'];
		}

		// Fetch all our usergroup ids
		$usergroupids = array_merge(array($userinfo['usergroupid']), explode(',', $userinfo['membergroupids']));

		// Ensure we can fetch bitfields
		$permissions = $this->app->fetchBitfield('nocache|allowedbbcodesfull');

		if ($permissions === NULL)
		{
			if ($userinfo['userid'] == $this->app->getUserInfo('userid'))
			{
				// Set the completed permissions array
				$instance['bbcodepermissions_parsed'] = array('bit' => 0, 'array' => array());
			}

			// Ignore this
			return;
		}

		foreach ($usergroupids as $usergroupid)
		{
			if (!$usergroupid)
			{
				// Just skip it
				continue;
			}

			foreach ($permissions as $permname => $bit)
			{
				if (!isset($permarray[$permname]))
				{
					// Default to false
					$permarray[$permname] = false;
				}

				if (!$permarray[$permname] AND isset($instance['bbcodepermissions'][$usergroupid]) AND ((int)$instance['bbcodepermissions'][$usergroupid] & (int)$bit))
				{
					// Override to true
					$permarray[$permname] = true;
					$bitvalue += $bit;
				}
			}
		}

		if ($userinfo['userid'] == $this->app->getUserInfo('userid'))
		{
			// Set the completed permissions array
			$instance['bbcodepermissions_parsed'] = array('bit' => $bitvalue, 'array' => $permarray);
		}

		return array('bit' => $bitvalue, 'array' => $permarray);
	}

	/**
	* Renders the main shoutbox template.
	* A method because this needs to happen on
	* multiple locations under different conditions.
	*/
	public function render(array $instance, $isDetached = false, $isArchive = false)
	{
		if (!isset($show) OR !is_array($show))
		{
			// Init
			$show = array();
		}

		// Create the template rendering engine
		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'isDetached', $isDetached);
		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'permissions', $instance['permissions_parsed']);
		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'title', $instance['name']);

		// Create the actual shoutbox variable
		$headerlink = $instance['name'];

		if ($instance['options']['archive_link'] AND $instance['permissions_parsed']['canviewarchive'])
		{
			// Reshape the archive link somewhat
			$headerlink .= ' [' .
				($instance['permissions_parsed']['canviewarchive'] ? '<a href="' . $this->app->link('archive', array(), array('id' => $instance['instanceid'], 'title' => $instance['name'])) . '">' : '') .
				$this->app->phrase('archive') .
				($instance['permissions_parsed']['canviewarchive'] ? '</a>' : '') .
			']';
		}

		// Register the header link variable
		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'headerlink', 	$headerlink);

		if ($this->app->getUserInfo('userid') AND $instance['permissions_parsed']['canshout'] AND $instance['options']['editors'])
		{
			// Create the template containing the Editor Tools
			$this->_getTemplate()->setParam('dbtech_shout_editortools', 'instance', $instance);
			$this->_getTemplate()->setParam('dbtech_shout_editortools', 'editorid', 'dbtech_shoutbox_editor_wrapper');
			$this->_getTemplate()->setParam('dbtech_shout_editortools', 'permissions', $instance['permissions_parsed']);

			
		}

		$size = '11px';
		

		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'shoutFontSize', $size);

		// Some important pre-register variables
		$direction = 'below';

		// Add to unsorted tabs
		$unsortedTabs = array();

		

		// Sanitation
		$direction = in_array($direction, array('above', 'below')) ? $direction : 'below';

		if ($this->app->getUserInfo('userid') AND $instance['permissions_parsed']['canshout'])
		{
			switch ($direction)
			{
				case 'above':
				case 'below':
					// Slim shout area above or below
					$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'shoutarea_' . $direction, (
						$this->_getTemplate()->renderTemplate('dbtech_shout_editortools', array(
							'direction' => $direction,
						))
					));
					break;
			}
		}

		// Register the shout area as being above or below
		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'direction', 'left');

		if ($instance['permissions_parsed']['canmodchat'])
		{
			/*
			$unsortedTabs['shoutreports'] = array(
				'text' 			=> $this->app->phrase('dbtech_vbshout_unhandled_reports') . ': <span name="dbtech_vbshout_shoutreports" data-instanceid="' . $instance['instanceid'] . '">0</span>',
				'canclose' 		=> '0',
				'extraparams' 	=> array(
					'loadurl' => $this->app->link('reportlist', array(), array('id' => $instance['instanceid'], 'title' => $instance['name']))
				)
			);
			*/
		}

		// Init this
		$chatroomCache = $this->cache->get('chatroom');

		foreach ($chatroomCache as $chatroomid => $chatroom)
		{
			if (!$chatroom['active'])
			{
				// Inactive chat room
				continue;
			}

			if ($chatroom['instanceid'] != $instance['instanceid'] AND $chatroom['instanceid'] != 0)
			{
				// Wrong instance id
				continue;
			}

			if ($chatroom['membergroupids'] AND $chatroom['autojoin'])
			{
				if (
					$chatroom['membergroupids'] == '-1'
					OR $this->app->isMemberOf($this->app->getUserInfo(), explode(',', $chatroom['membergroupids'])))
				{
					// Do join it
					$unsortedTabs['chatroom_' . $chatroomid . '_' . $chatroom['instanceid']] = [
						'text' 			=> str_replace('"', '&quot;', $chatroom['title']),
						'canclose' 		=> '0',
						'extraparams' 	=> [
							'chatroomid' => $chatroomid
						]
					];
				}
			}
			else if (
				isset($chatroom['members'][$this->app->getUserInfo('userid')])
				AND $chatroom['members'][$this->app->getUserInfo('userid')] == '1'
				AND (
					!$chatroom['membergroupids']
					OR $chatroom['membergroupids'] == '-1'
					OR $this->app->isMemberOf($this->app->getUserInfo(), explode(',', $chatroom['membergroupids']))
				)
			)
			{
				// Do join it
				$unsortedTabs['chatroom_' . $chatroomid . '_' . $chatroom['instanceid']] = [
					'text' 			=> str_replace('"', '&quot;', $chatroom['title']),
					'canclose' 		=> '1',
					'extraparams' 	=> [
						'chatroomid' => $chatroomid
					]
				];
			}
			else
			{
				// Make sure we're gone
				$this->leaveChatroom($chatroom, $this->app->getUserInfo('userid'));
			}
		}

		if ($this->app->getUserInfo('dbtech_vbshout_displayorder') === false)
		{
			// Only unserialize if it's not an array
			$this->app->setUserInfo('dbtech_vbshout_displayorder', []);
		}

		if (!is_array($this->app->getUserInfo('dbtech_vbshout_displayorder')))
		{
			// Only unserialize if it's not an array
			$this->app->setUserInfo('dbtech_vbshout_displayorder', @unserialize($this->app->getUserInfo('dbtech_vbshout_displayorder')));
		}

		$tabdisplayorder = $this->app->getUserInfo('dbtech_vbshout_displayorder');
		if (isset($tabdisplayorder[$instance['instanceid']]) AND is_array($tabdisplayorder[$instance['instanceid']]))
		{
			asort($tabdisplayorder[$instance['instanceid']]);
			foreach ($tabdisplayorder[$instance['instanceid']] as $tabid => $tab)
			{
				if (!$unsortedTabs[$tabid])
				{
					// Skip this tab
					continue;
				}

				// Add the tab
				$this->tabs[$instance['instanceid']][$tabid] = $unsortedTabs[$tabid];
				unset($unsortedTabs[$tabid]);
			}
		}

		foreach ($unsortedTabs as $tabid => $tab)
		{
			// Add remaining unsorted tabs
			$this->tabs[$instance['instanceid']][$tabid] = $tab;
		}

		if ($instance['options']['activeusers'])
		{
			// Register the active users frame
			// 	@TODO: Make it so people can choose active users on left or right
			$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'activeusers', (count($this->activeusers) ? implode('<br />', $this->activeusers) : $this->app->phrase('dbtech_vbshout_no_active_users')));
		}

		// Register template variables
		$show['canshout'] = ($this->app->getUserInfo('userid') AND $instance['permissions_parsed']['canshout']);

		// Set the instance
		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'instance', 	$instance);
		$this->_getTemplate()->setParam('dbtech_shout_shoutbox', 'show', 		$show);

		// Finally render the template
		return $this->_getTemplate()->renderTemplate('dbtech_shout_shoutbox');
	}

	/**
	* Sets up the surrounding wrapper to the render function
	*
	* @param	array		The instance
	* @param	array|null	User Info to check (null = vBulletin Userinfo)
	*/
	public function renderWrapper(array $instanceCache, $isDetached = false, $isArchive = false)
	{
		// Begin important arrays
		$retval = $phrases = $userOptions = [];
		$js = '';

		// Grab this
		$userInfo = $this->app->getUserInfo();

		$settingBits = array_merge(
			$this->app->fetchBitfield('nocache|dbtech_vbshout_general_settings'),
			$this->app->fetchBitfield('nocache|dbtech_vbshout_editor_settings')
		);
		foreach ($settingBits as $settingName => $bit)
		{
			// Shorthand
			$settingNameShort = substr($settingName, strlen('dbtech_vbshout_'));

			
			
			if (in_array($settingNameShort, [
				'enabledesktop'
			]))
			{
				// Take the true value from this
				$userOptions[$settingNameShort] = ((int)$userInfo['dbtech_vbshout_settings'] & (int)$bit) ? 1 : 0;
			}
			else
			{
				// Auto set
				$userOptions[$settingNameShort] = (!in_array($settingName, array(
					'dbtech_vbshout_hidealtcolours',
					'dbtech_vbshout_hideavatars',
					'dbtech_vbshout_enableoverride',
					'dbtech_vbshout_disableshoutbox'
				)) ? 1 : 0);
			}
			
		}

		

		// Do detached check
		$userOptions['is_detached'] = intval($isDetached);
		$userOptions['pmtime'] = $userInfo['userid'] ? $userInfo['dbtech_vbshout_pm'] : 0;

		
		// Ensure this is on
		$userInfo['dbtech_vbshout_settings'] |= 16384;
		$userInfo['dbtech_vbshout_settings'] |= 32768;
		$userInfo['dbtech_vbshout_settings'] |= 65536;

		// Set this back
		$this->app->setUserInfo('dbtech_vbshout_settings', $userInfo['dbtech_vbshout_settings']);

		// Make sure we read the true value from this
		$userOptions['enabledesktop'] = $userInfo['dbtech_vbshout_settings'] & $settingBits['dbtech_vbshout_enabledesktop'];
		

		

		// Attempt unserialize if needed
		$userInfo['dbtech_vbshout_invisiblesettings'] = (
			isset($userInfo['dbtech_vbshout_invisiblesettings']) ?
			$userInfo['dbtech_vbshout_invisiblesettings'] :
			[]
		);
		$userInfo['dbtech_vbshout_invisiblesettings'] = (
			is_array($userInfo['dbtech_vbshout_invisiblesettings']) ?
			$userInfo['dbtech_vbshout_invisiblesettings'] :
			@unserialize($userInfo['dbtech_vbshout_invisiblesettings'])
		);
		$userInfo['dbtech_vbshout_invisiblesettings'] = (
			is_array($userInfo['dbtech_vbshout_invisiblesettings']) ?
			$userInfo['dbtech_vbshout_invisiblesettings'] :
			[]
		);
		$this->app->setUserInfo('dbtech_vbshout_invisiblesettings', $userInfo['dbtech_vbshout_invisiblesettings']);

		// Check for archive
		$userOptions['archive'] = intval($isArchive);

		// Set vB version
		//$userOptions['vbversion'] = intval($vbulletin->versionnumber);

		// Do posts per day
		$jointime = ($this->app->getTime() - $this->app->getUserInfo($this->_getDb()->lookup('user', 'joindate'))) / 86400;
		$postsPerDay = ($jointime <= 1 ? $this->app->getUserInfo($this->_getDb()->lookup('user', 'posts')) : round($this->app->getUserInfo($this->_getDb()->lookup('user', 'posts')) / $jointime, 2));

		// Set our phrases
		$phrases = array(
			'dbtech_vbshout_idle' 							=> $this->app->phrase('dbtech_vbshout_idle'),
			'dbtech_vbshout_flagged_idle'					=> $this->app->phrase('dbtech_vbshout_flagged_idle'),
			'dbtech_vbshout_saving_shout' 					=> $this->app->phrase('dbtech_vbshout_saving_shout'),
			'dbtech_vbshout_editing_shout' 					=> $this->app->phrase('dbtech_vbshout_editing_shout'),
			'dbtech_vbshout_editing_sticky' 				=> $this->app->phrase('dbtech_vbshout_editing_sticky'),
			'dbtech_vbshout_deleting_shout' 				=> $this->app->phrase('dbtech_vbshout_deleting_shout'),
			'dbtech_vbshout_fetching_shouts' 				=> $this->app->phrase('dbtech_vbshout_fetching_shouts'),
			'dbtech_vbshout_fetching_shouts_in_x_seconds'	=> $this->app->phrase('dbtech_vbshout_fetching_shouts_in_x_seconds'),
			'dbtech_vbshout_no_active_users'				=> $this->app->phrase('dbtech_vbshout_no_active_users'),
			'dbtech_vbshout_saving_shout_styles'			=> $this->app->phrase('dbtech_vbshout_saving_shout_styles'),
			'dbtech_vbshout_ajax_disabled'					=> $this->app->phrase('dbtech_vbshout_ajax_disabled'),
			'dbtech_vbshout_must_wait_x_seconds'			=> $this->app->phrase('dbtech_vbshout_must_wait_x_seconds'),
			'dbtech_vbshout_are_you_sure_banunban'			=> $this->app->phrase('dbtech_vbshout_are_you_sure_banunban'),
			'dbtech_vbshout_are_you_sure_silenceunsilence'	=> $this->app->phrase('dbtech_vbshout_are_you_sure_silenceunsilence'),
			'dbtech_vbshout_are_you_sure_ignoreunignore'	=> $this->app->phrase('dbtech_vbshout_are_you_sure_ignoreunignore'),
			'dbtech_vbshout_are_you_sure_pruneshouts'		=> $this->app->phrase('dbtech_vbshout_are_you_sure_pruneshouts'),
			'dbtech_vbshout_are_you_sure_chatremove'		=> $this->app->phrase('dbtech_vbshout_are_you_sure_chatremove'),
			'dbtech_vbshout_are_you_sure_chatjoin'			=> $this->app->phrase('dbtech_vbshout_are_you_sure_chatjoin'),
			'dbtech_vbshout_are_you_sure_chatleave'			=> $this->app->phrase('dbtech_vbshout_are_you_sure_chatleave'),
			'dbtech_vbshout_are_you_sure_shoutdelete' 		=> $this->app->phrase('dbtech_vbshout_are_you_sure_shoutdelete'),
			'dbtech_vbshout_everyone'						=> $this->app->phrase('dbtech_vbshout_everyone'),
			'dbtech_vbshout_none' 							=> $this->app->phrase('dbtech_vbshout_none'),
		);

		foreach ($instanceCache as $instanceid => $instance)
		{
			if (!$instance['active'])
			{
				// Inactive instance
				continue;
			}

			if (!$instance['permissions_parsed']['canviewshoutbox'])
			{
				// Can't view this instance
				continue;
			}

			if ($this->app->getUserInfo($this->_getDb()->lookup('user', 'posts')) < $instance['options']['minposts'] AND !$this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
			{
				// Too few posts
				continue;
			}

			if ($postsPerDay < $instance['options']['minpostsperday'] AND !$this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager'))
			{
				// Too few posts
				continue;
			}

			// Init per-instance settings
			$editorOptions = $instanceOptions = $instancePermissions =
				$bbcodePermissions = array();

			$soundSettings = isset($userInfo['dbtech_vbshout_soundsettings']) ? $userInfo['dbtech_vbshout_soundsettings'] : [];
			

			$invisibleSettings = isset($userInfo['dbtech_vbshout_invisiblesettings']) ? $userInfo['dbtech_vbshout_invisiblesettings'] : [];
			if (!isset($invisibleSettings[$instanceid]) OR $instance['options']['invis'])
			{
				// Set default invisibility
				$invisibleSettings[$instanceid] = 0;
			}

			// Set invis options
			$instance['options']['invisible'] = intval($invisibleSettings[$instanceid]);

			// To avoid JS hass
			$instance['options']['unIdle'] = false;
			$instance['options']['unPause'] = false;

			// ######################## Start Value Fallback #########################
			// Maximum Characters Per Shout
			$instance['options']['maxchars'] 		= ($instance['options']['maxchars'] 	> 0 	? $instance['options']['maxchars'] 	: 256);
			$instance['options']['maxchars'] 		= ($this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager') 	> 0 	? 0 								: $instance['options']['maxchars']);

			// Maximum Images Per Shout
			$instance['options']['maximages'] 		= ($instance['options']['maximages'] 	> 0 	? $instance['options']['maximages'] : 4);

			// Flood check time
			$instance['options']['floodchecktime'] 	= ($this->app->usergroupPermission('dbtech_vbshoutpermissions', 'ismanager') 	> 0 	? 0 								: $instance['options']['floodchecktime']);

			if ($userOptions['is_detached'])
			{
				$instance['options']['height'] 		= $instance['options']['height_detached'];
				$instance['options']['maxshouts'] 	= $instance['options']['maxshouts_detached'];

				if (isset($userInfo['dbtech_vbshout_shoutboxsize_detached']) AND $userInfo['dbtech_vbshout_shoutboxsize_detached'])
				{
					// Override detached height
					$instance['options']['height'] = $userInfo['dbtech_vbshout_shoutboxsize_detached'];
				}
			}
			else
			{

				if (isset($userInfo['dbtech_vbshout_shoutboxsize']) AND $userInfo['dbtech_vbshout_shoutboxsize'])
				{
					// Override height
					$instance['options']['height'] = $userInfo['dbtech_vbshout_shoutboxsize'];
				}
			}
			//$instance['options']['maxchars'] 		= 256;

			if (!$userOptions['archive'])
			{
				// Render the shoutbox
				$rendered = $this->render($instance, $isDetached, $isArchive);
			}

			if ($userInfo['userid'] AND $instance['permissions_parsed']['canshout'] AND $instance['options']['editors'])
			{
				if ($instance['options']['editors'] & 1)
				{
					// Bold
					$editorOptions['bold'] = $this->shoutstyle[$instanceid]['bold'];
				}

				if ($instance['options']['editors'] & 2)
				{
					// Italic
					$editorOptions['italic'] = $this->shoutstyle[$instanceid]['italic'];
				}

				if ($instance['options']['editors'] & 4)
				{
					// Underline
					$editorOptions['underline'] = $this->shoutstyle[$instanceid]['underline'];
				}

				if ($instance['options']['editors'] & 8)
				{
					// Color
					$editorOptions['color'] = $this->shoutstyle[$instanceid]['color'];
				}

				if ($instance['options']['editors'] & 16)
				{
					// Font
					$editorOptions['font'] = $this->shoutstyle[$instanceid]['font'];
				}

				$size = '11px';
				

				if ($instance['options']['editors'] & 256 AND $this->isPro)
				{
					// Font
					$editorOptions['size'] = $size;
				}
			}

			

			// Set these per-instance arrays
			$instanceOptions 		= $instance['options'];
			$instancePermissions 	= $instance['permissions_parsed'];
			$bbcodePermissions 		= $instance['bbcodepermissions_parsed'];

			// Append title to instance options
			$instanceOptions['_title'] = $instance['name'];

			// Append userid to user options
			$userOptions['_userid'] = $userInfo['userid'];

			// Add this to the output
			$retval[$instanceid] = $rendered;

			if (!isset($this->tabs[$instanceid]))
			{
				// Make sure this is an array
				$this->tabs[$instanceid] = [];
			}

			$js .= "\$('.shoutbox" . $instance['instanceid'] . "').DBTechShout({
				phrases: " . $this->app->encodeJSON($phrases) . ",
				editorOptions: " . $this->app->encodeJSON($editorOptions) . ",
				instanceOptions: " . $this->app->encodeJSON($instanceOptions) . ",
				instancePermissions: " . $this->app->encodeJSON($instancePermissions) . ",
				bbcodePermissions: " . $this->app->encodeJSON($bbcodePermissions) . ",
				userOptions: " . $this->app->encodeJSON($userOptions) . ",
				soundSettings: " . $this->app->encodeJSON($soundSettings) . ",
				tabs: " . $this->app->encodeJSON($this->tabs[$instanceid]) . ",
				link: '" . $this->app->link('') . "',
				dataDir: '" . $this->dataDir . "',
				prefix: '" . $this->prefix . "',
			});";
		}

		$params = array();
		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$params['link'] = urldecode(XenForo_Link::buildPublicLink('dbtech-shout-profile', array(), array(
					'shoutid' => '${shoutid}',
					'userid' => '${userid}',
					'instanceid' => '${instanceid}'
				)));
				break;
		}

		// We can see at least 1 instance
		return array(
			'instances' => $retval,
			'js' => '<script>' . $js . '</script>' . $this->_getTemplate()->renderTemplate('dbtech_shout_jquery_templates', $params)
		);
	}

	/**
	* Logs a specified command.
	*
	* @param	string	The executed command.
	* @param	mixed	(Optional) Additional comments.
	*/
	public function logCommand($command, $comment = NULL, $instance = NULL)
	{
		$bit = 0;
		switch ($command)
		{
			case 'shoutedit':
			case 'shoutdelete':
				$bit = 8;
				break;

			case 'prune':
				$bit = 1;
				break;

			case 'setsticky':
			case 'removesticky':
				$bit = 2;
				break;

			case 'ban':
			case 'unban':
				$bit = 4;
				break;

			case 'resetshouts':
				$bit = 32;
				break;

			
		}

		if (!$bit OR ($instance !== NULL AND !($instance['options']['logging'] & $bit)))
		{
			// We didn't have this option on
			return;
		}

		// Unban all the users
		$this->_getDb()->insert('dbtech_vbshout_log', array(
			'userid' 	=> $this->app->getUserInfo('userid'),
			'username' 	=> $this->app->getUserInfo('username'),
			'dateline' 	=> $this->app->getTime(),
			'ipaddress' => $_SERVER['REMOTE_ADDR'],
			'command' 	=> $command,
			'comment' 	=> $comment,
		));
	}

	/**
	* Rebuilds the shout counter for every user.
	*/
	public function buildShoutsCounter()
	{
		// update the user table
		$this->_getDb()->query('
			UPDATE $user AS user
			SET dbtech_vbshout_shouts = (
				SELECT COUNT(*)
				FROM $dbtech_vbshout_shout
				WHERE userid = user.=user:userid=
			)
		', array(), 'query_write');
	}

	/**
	* Processes an AJAX fetching request using AOP.
	*
	* @param	string	When we last fetched shouts
	*/
	public function fetchAop($tabid, $instanceid)
	{
		if ($tabid == 'activeusers')
		{
			// Shouldn't happen
			return false;
		}

		if (!is_writable($this->dataDir))
		{
			// Fall back to database
			throw new Exception($this->app->phrase('dbtech_vbshout_aop_error'));
		}

		// File system
		$mtime = $this->fetchAopRaw($tabid, $instanceid);

		if (!$mtime)
		{
			$mtime = 0;
		}

		if (($this->app->getTime() - $mtime) >= 60)
		{
			// Reset AOP
			$this->setAop($tabid, $instanceid, false, true);
			return false;
		}

		if (!isset($this->fetched['aoptimes']) OR !is_array($this->fetched['aoptimes']))
		{
			// Ensure this is set
			$this->fetched['aoptimes'] = array();
		}

		foreach ($this->fetched['aoptimes'] as $key => $info)
		{
			if ($info['tabid'] == $tabid)
			{
				// Already fetched
				$this->fetched['aoptimes'][$key]['aoptime'] = $mtime;
				$this->fetched['aoptimes'][$key]['tabid'] = $tabid;
				return true;
			}
		}

		//if ($mtime > $aoptime)
		//{
			// Include the new AOP time
			$this->fetched['aoptimes'][] = array(
				'aoptime' 	=> $mtime,
				'tabid' 	=> $tabid,
				'nosound' 	=> 0
			);
		//}
	}

	/**
	* Grabs the raw AOP time
	*
	* @param	string	When we last fetched shouts
	*/
	public function fetchAopRaw($tabid, $instanceid)
	{
		return intval(@file_get_contents($this->dataDir . '/' . $this->prefix . $tabid . $instanceid . '.txt'));
	}

	/**
	* Sets the new AOP time.
	*/
	public function setAop($tabid, $instanceid = 0, $markread = true, $nosound = false)
	{
		if ($tabid == 'activeusers')
		{
			// Shouldn't happen
			return false;
		}

		// Ensure this is taken into account
		clearstatcache();

		if (!is_writable($this->dataDir))
		{
			// Fall back to database
			throw new Exception($this->app->phrase('dbtech_vbshout_aop_error'));
			return false;
		}

		// Touch the files
		@file_put_contents($this->dataDir . '/' . $this->prefix . $tabid . $instanceid . '.txt', $this->app->getTime());

		if ($markread)
		{
			// Duplicate this
			@file_put_contents($this->dataDir . '/' . $this->prefix . 'markread-' . $tabid . $instanceid . '.txt', $this->app->getTime());
		}

		if (!isset($this->fetched['aoptimes']) OR !is_array($this->fetched['aoptimes']))
		{
			// Ensure this is set
			$this->fetched['aoptimes'] = array();
		}

		foreach ($this->fetched['aoptimes'] as $key => $info)
		{
			if ($info['tabid'] == $tabid)
			{
				// Already fetched
				$this->fetched['aoptimes'][$key]['aoptime'] 	= $this->app->getTime();
				$this->fetched['aoptimes'][$key]['tabid'] 		= $tabid;
				$this->fetched['aoptimes'][$key]['nosound'] 	= (int)$nosound;
				return true;
			}
		}

		// Include the new AOP time
		$this->fetched['aoptimes'][] = array(
			'aoptime' 	=> $this->app->getTime(),
			'tabid' 	=> $tabid,
			'nosound' 	=> (int)$nosound
		);
	}

	/**
	* Un-idles us
	*/
	public function unIdle(array $instance, array $chatroom = array())
	{
		if (!$this->app->getUserInfo('userid'))
		{
			// Guests shouldn't be flagged as active
			return false;
		}

		$this->app->setUserInfo('dbtech_vbshout_invisiblesettings', (
			is_array($this->app->getUserInfo('dbtech_vbshout_invisiblesettings')) ?
			$this->app->getUserInfo('dbtech_vbshout_invisiblesettings') :
			@unserialize($this->app->getUserInfo('dbtech_vbshout_invisiblesettings'))
		));
		$this->app->setUserInfo('dbtech_vbshout_invisiblesettings', (
			is_array($this->app->getUserInfo('dbtech_vbshout_invisiblesettings')) ?
			$this->app->getUserInfo('dbtech_vbshout_invisiblesettings') :
			array()
		));

		$invisibleSettings = $this->app->getUserInfo('dbtech_vbshout_invisiblesettings');
		if (!$instance['options']['invis'] AND isset($invisibleSettings[$instance['instanceid']]) AND $invisibleSettings[$instance['instanceid']])
		{
			// We're stealthing
			return false;
		}

		// Set us as active
		$this->_getDb()->replace('dbtech_vbshout_session', array(
			'userid' => $this->app->getUserInfo('userid'),
			'lastactivity' => $this->app->getTime(),
			'instanceid' => $instance['instanceid'],
			'chatroomid' => ($chatroom ? $chatroom['chatroomid'] : 0),
		));

		// Set timeout to twice that of the actual idle timeout, so that we don't needlessly purge sessions
		$timeout = $this->app->getTime() - (($instance['options']['idletimeout'] ? $instance['options']['idletimeout'] : 600) * 2);

		// Get rid of old sessions
		$this->_getDb()->delete('dbtech_vbshout_session', 'lastactivity < ' . intval($timeout));
	}

	/**
	* Fetches shouts based on parameters.
	*
	* @param	array		(Optional) Additional arguments
	*/
	public function fetchShouts(array $instance = array(), array $chatroom = array(), array $args = array())
	{
		$cleanedInput = $this->app->filter(array(
			'shoutorder' => TYPE_STR
		));

		$args = array_merge(array(
			'type' 			=> 0,
			'types' 		=> 0,
			'excludetypes' 	=> NULL,
			'onlyuser' 		=> false,
			'archive' 		=> false,
			'chatroomid' 	=> 0,
			'chatroomids' 	=> '',
			'message' 		=> '',
			'dateline_from' => 0,
			'dateline_end' 	=> 0,
			'username' 		=> '',
			'hours' 		=> 0,
			'orderby' 		=> 'DESC',
		), $args);

		// Cache array for markup username
		$shoutusers = array();

		// Various SQL hooks
		$hook_query_select = $hook_query_join = $hook_query_and = '';

		if ($args['type'] == -1 OR !$args['types'])
		{
			// Everything
			$hook_query_and .= 'AND (
				vbshout.userid IN(-1, ' . $this->app->getUserInfo('userid') . ') OR
				vbshout.id IN(0, ' . $this->app->getUserInfo('userid') . ')
			)';				// That either system or us posted, or was a message to us/anybody

			if (is_array($args['excludetypes']))
			{
				// Exclude types
				$hook_query_and .= 'AND vbshout.type NOT IN(' . implode(',', $args['excludetypes']) . ')';
			}
		}
		else
		{
			$types = array();
			foreach ($this->shouttypes as $key => $val)
			{
				// Go through all shout types
				if ($args['types'] & $this->shouttypes[$key])
				{
					switch ($key)
					{
						case 'shout':
							if ($args['onlyuser'])
							{
								// Every PM posted by us to the user
								// or to us
								$hook_query_and .= 'AND vbshout.userid = ' . intval($args['onlyuser']);
							}
							break;

						case 'pm':
							if ($args['onlyuser'])
							{
								// Every PM posted by us to the user
								// or to us
								$hook_query_and .= 'AND (
									vbshout.userid = ' . $this->app->getUserInfo('userid') . ' AND
										vbshout.id = ' . intval($args['onlyuser']) . '
								) OR (
									vbshout.id = ' . $this->app->getUserInfo('userid') . ' AND
										vbshout.userid = ' . intval($args['onlyuser']) . '
								)';
							}
							break;
					}

					// Set the type
					$types[] = $this->shouttypes[$key];
				}
			}

			// Include all our types
			$hook_query_and .= 'AND vbshout.type IN(' . implode(',', $types) . ')';
		}

		// Fetch the shout order
		$cleanedInput['shoutorder'] = (in_array($cleanedInput['shoutorder'], array('ASC', 'DESC')) ? $cleanedInput['shoutorder'] : $instance['options']['shoutorder']);

		if ($args['chatroomids'])
		{
			$hook_query_and .= ' AND vbshout.chatroomid IN(' . intval($args['chatroomid']) . ')';
		}
		else
		{
			$hook_query_and .= ' AND vbshout.chatroomid = ' . intval($args['chatroomid']);
		}

		if (!$args['archive'] AND $instance['options']['activeusers'])
		{
			$this->fetchActiveUsers($instance, $chatroom, true);
			$this->fetched['activeusers']['count'] = count($this->activeusers);

			if ($args['chatroomid'])
			{
				// Array of all active users
				$this->fetched['activeusers']['usernames'] = (count($this->activeusers) ? implode('<br />', $this->activeusers) : $this->app->phrase('dbtech_vbshout_no_chat_users'));
				if ($instance['options']['enableaccess'])
				{
					//$this->fetched['activeusers']['usernames'] .= '<br /><br /><a href="' . $this->app->link('chataccess', array('chatroomid' => $args['chatroomid']), array('id' => $instance['instanceid'], 'title' => $instance['name'])) . '" target="_blank"><b>' . $this->app->phrase('dbtech_vbshout_chat_access') . '</b></a>';
				}
			}
			else
			{
				// Array of all active users
				$this->fetched['activeusers']['usernames'] = (count($this->activeusers) ? implode('<br />', $this->activeusers) : $this->app->phrase('dbtech_vbshout_no_active_users'));
			}
		}

		

		if ($args['archive'])
		{
			$this->fetched['totalshouts'] = $this->_getDb()->fetchOne('
				SELECT COUNT(*)
				FROM $dbtech_vbshout_shout AS vbshout
				LEFT JOIN $user AS user ON(user.=user:userid= = vbshout.userid)
				' . $hook_query_join . '
				WHERE vbshout.instanceid IN(-1, 0, ?)
					AND vbshout.userid NOT IN(
						SELECT ignoreuserid
						FROM $dbtech_vbshout_ignorelist AS ignorelist
						WHERE userid = ?
					)
					AND vbshout.forumid IN(' . implode(',', $this->getForumIds()) . ')
					AND (
						vbshout.forumid = 0
						OR vbshout.userid = ?
						OR vbshout.forumid NOT IN(' . implode(',', $this->getForumIds2()) . ')
					)
					AND (
						user.dbtech_vbshout_banned = 0 OR
						vbshout.userid = -1
					)
					' . $hook_query_and . '
			', array(
				$instance['instanceid'],
				$this->app->getUserInfo('userid'),
				$this->app->getUserInfo('userid')
			));

			if ($args['message'])
			{
				// Limit by message
				$hook_query_and .= " AND vbshout.message LIKE " . $this->_getDb()->quoteLike($args['message'], 'lr');
			}

			
		}

		switch ($this->app->getSystem())
		{
			case 'vBulletin':
				if (
					$this->app->option('avatarenabled')
					AND $instance['options']['avatars_normal']
					AND !((int)$this->app->getUserInfo('dbtech_vbshout_settings') & 262144)
				)
				{
					$hook_query_select .= ', avatar.avatarpath, NOT ISNULL(customavatar.userid) AS hascustomavatar, customavatar.dateline AS avatardateline, customavatar.width AS avwidth, customavatar.height AS avheight, customavatar.height_thumb AS avheight_thumb, customavatar.width_thumb AS avwidth_thumb, customavatar.filedata_thumb';
					$hook_query_join .= ' LEFT JOIN $avatar AS avatar ON (avatar.avatarid = user.avatarid) LEFT JOIN $customavatar AS customavatar ON (customavatar.userid = user.userid)';
				}
				break;
		}

		// Query the shouts
		$shouts = $this->_getDb()->fetchAll('
			SELECT
				user.*,
				vbshout.*,
				pmuser.username AS pmusername
				' . $hook_query_select . '
			FROM $dbtech_vbshout_shout AS vbshout
			LEFT JOIN $user AS user ON(user.=user:userid= = vbshout.userid)
			LEFT JOIN $user AS pmuser ON(pmuser.=user:userid= = vbshout.id)
			' . $hook_query_join . '
			WHERE vbshout.instanceid IN(-1, 0, ?)
				AND vbshout.userid NOT IN(
					SELECT ignoreuserid
					FROM $dbtech_vbshout_ignorelist AS ignorelist
					WHERE userid = ?
				)
				AND vbshout.forumid IN(' . implode(',', $this->getForumIds()) . ')
				AND (
					vbshout.forumid = 0
					OR vbshout.userid = ?
					OR vbshout.forumid NOT IN(' . implode(',', $this->getForumIds2()) . ')
				)
				AND (
					user.dbtech_vbshout_banned = 0 OR
					vbshout.userid = -1
				)
				' . $hook_query_and . '
			ORDER BY dateline ' . $args['orderby'] . '
			LIMIT ' . (isset($args['startat']) ? ($args['startat'] . ',') : '') . (isset($args['perpage']) ? $args['perpage'] : ($instance['options']['maxshouts'] ? $instance['options']['maxshouts'] : 20)) . '
		', array(
			$instance['instanceid'],
			$this->app->getUserInfo('userid'),
			$this->app->getUserInfo('userid')
		));

		if (!isset($this->fetched['sticky']) OR !$this->fetched['sticky'])
		{
			// Set sticky
			$this->fetched['sticky'] = $instance['sticky'];
		}

		if (!count($shouts))
		{
			// We have no shouts
			$this->fetched['content'] = '<li>' . $this->app->phrase('dbtech_vbshout_nothing_to_display') . '</li>';
			return false;
		}

		if (!$args['archive'])
		{
			// Fetch active users without menu or force
			$this->fetchActiveUsers($instance, $chatroom);

			$this->fetched['activeusers']['count'] = count($this->activeusers);
		}

		// Re-add this, lol
		$this->shoutstyle = ($this->shoutstyle ? $this->shoutstyle : @unserialize($this->app->getUserInfo('dbtech_vbshout_shoutstyle')));

		$i = 1;
		foreach ($shouts as $shout)
		{
			if ($shout['userid'] == 0)
			{
				// Save some resources
				continue;
			}

			// Parses action codes like /me
			$this->parseActionCodes($shout['message'], $shout['type']);

			// By default, we can't pm or edit
			$canpm = $canedit = false;

			if ($shout['userid'] > -1)
			{
				if (!isset($shoutusers[$shout['userid']]))
				{
					// Uncached user
					$shoutusers[$shout['userid']] = $shout;
				}

				switch ($this->app->getSystem())
				{
					case 'XenForo':
						$shoutusers[$shout['userid']]['musername'] = XenForo_Template_Helper_Core::callHelper('richusername', array($shoutusers[$shout['userid']]));
						break;

					case 'vBulletin':
						// fetch the markup-enabled username
						fetch_musername($shoutusers[$shout['userid']]);
						break;
				}

				if ($shout['userid'] != $this->app->getUserInfo('userid'))
				{
					// We can PM this user
					$canpm = true;
				}
			}
			else
			{
				// This was the SYSTEM
				$shoutusers[$shout['userid']] = array(
					'userid' 	=> 0,
					'username' 	=> $this->app->phrase('dbtech_vbshout_system'),
					'musername' => $this->app->phrase('dbtech_vbshout_system'),
				);

				// We can't PM the system
				$canpm = false;
			}

			// Only registered users can have shoutbox styles
			if (!$shout['dbtech_vbshout_shoutstyle'] = @unserialize($shout['dbtech_vbshout_shoutstyle']))
			{
				// This shouldn't be false
				$shout['dbtech_vbshout_shoutstyle'] = array();
			}

			// Ensure it's an array for the sake of bugfix
			$shout['dbtech_vbshout_shoutstyle'] = (!isset($shout['dbtech_vbshout_shoutstyle'][$instance['instanceid']]) ? array('bold' => 0, 'italic' => 0, 'underline' => 0, 'font' => '', 'color' => '') : $shout['dbtech_vbshout_shoutstyle'][$instance['instanceid']]);

			// Init the styleprops
			$styleprops = array();

			if ($this->app->getUserInfo('dbtech_vbshout_settings') & 8192)
			{
				// Override!
				$shout['dbtech_vbshout_shoutstyle'] = $this->shoutstyle[$instance['instanceid']];
			}

			if ($instance['options']['editors'] & 1 AND $shout['dbtech_vbshout_shoutstyle']['bold'])
			{
				// Bold
				$styleprops[] = 'font-weight:bold;';
			}

			if ($instance['options']['editors'] & 2 AND $shout['dbtech_vbshout_shoutstyle']['italic'])
			{
				// Italic
				$styleprops[] = 'font-style:italic;';
			}

			if ($instance['options']['editors'] & 4 AND $shout['dbtech_vbshout_shoutstyle']['underline'])
			{
				// Underline
				$styleprops[] = 'text-decoration:underline;';
			}

			if ($instance['options']['editors'] & 16 AND $shout['dbtech_vbshout_shoutstyle']['font'])
			{
				// Font
				$styleprops[] = 'font-family:' . $shout['dbtech_vbshout_shoutstyle']['font'] . ';';
			}

			if ($instance['options']['editors'] & 8 AND $shout['dbtech_vbshout_shoutstyle']['color'])
			{
				// Color
				$styleprops[] = 'color:' . $shout['dbtech_vbshout_shoutstyle']['color'] . ';';
			}

			if (($shout['userid'] == $this->app->getUserInfo('userid') AND $instance['permissions_parsed']['caneditown']) OR
				($shout['userid'] != $this->app->getUserInfo('userid') AND $instance['permissions_parsed']['caneditothers']))
			{
				// We got the perms, give it to us
				$canedit = true;
			}

			switch ($shout['type'])
			{
				case $this->shouttypes['me']:
				case $this->shouttypes['notif']:
					// slash me or notification
					$time = $this->app->time($shout['dateline']);
					break;

				default:
					// Everything else
					$time = '[' . $this->app->dateTime($shout['dateline']) . ']';
					break;
			}

			// Default
			$shout['avatarurl'] = '';

			

			$shout['message'] = str_replace(array("\r", "\n", "\r\n"), '', $shout['message']);

			switch ($shout['type'])
			{
				case $this->shouttypes['shout']:
					// Normal shout
					$template = 'Shout';
					break;

				case $this->shouttypes['pm']:
					// PM
					$template = 'Pm';
					break;

				case $this->shouttypes['me']:
				case $this->shouttypes['notif']:
					// slash me or a notification
					$template = 'Me';
					break;

				default:
					// Error handler
					$template = 'Shout';
					break;
			}

			if ($shout['userid'] == -1)
			{
				// System message
				$template = 'System';
			}

			$altclass = 'alt1';
			if ($instance['options']['altshouts'] AND !((int)$this->app->getUserInfo('dbtech_vbshout_settings') & 131072))
			{
				$altclass = ($i % 2 == 0 ? ' alt2' : ' alt1');
			}

			if ($shout['message_raw'] == '/silencelist' OR $shout['message_raw'] == '/banlist')
			{
				// Special cases, allow HTML
				$shout['message'] = str_replace(array('&lt;', '&gt;', '&quot;', '&amp;'), array('<', '>', '"', '&'), $shout['message']);
			}

			// Set PM stuff
			$pmUserParsed = $this->app->phrase('dbtech_vbshout_pm');
			

			$isProtected = false;
			try
			{
				$this->checkProtectedUserGroup($instance, $shout);
			}
			catch (Exception $e)
			{
				// Yeah
				$isProtected = true;
			}

			$this->fetched['shouts'][] = array(
				'template'				=> $template,
				'shoutid' 				=> $shout['shoutid'],
				'userid' 				=> $shoutusers[$shout['userid']]['userid'],
				'user_id' 				=> $shoutusers[$shout['userid']]['userid'],
				'avatar_date' 			=> isset($shout['avatar_date']) ? $shout['avatar_date'] : '',
				'gravatar' 				=> isset($shout['gravatar']) ? $shout['gravatar'] : '',
				'instanceid' 			=> $instance['instanceid'],
				'message_raw'			=> str_replace('\\\\', '\\', str_replace(array("%", "$", "\\"), array("&#37;", "&#36;", "\\\\"), htmlspecialchars($shout['message_raw']))),
				'canedit'				=> $canedit,
				'time'					=> $time,
				'fullDate'				=> $this->app->dateTime($shout['dateline']),
				'musername'				=> str_replace(array("%", "$"), array("&#37;", "&#36;"), $shoutusers[$shout['userid']]['musername']),
				'jsusername'			=> str_replace('"', '\"', $shoutusers[$shout['userid']]['username']),
				'username'				=> $shoutusers[$shout['userid']]['username'],
				'styleprops' 			=> implode(' ', $styleprops),
				'message'				=> str_replace('\\\\', '\\', str_replace(array("%", "$", "\\"), array("&#37;", "&#36;", "\\\\"), $shout['message'])),
				'pmuserParsed'			=> $pmUserParsed,
				'pmusername'			=> $shout['pmusername'],
				'altclass'				=> $altclass,
				'enableAvatarsNormal'	=> $instance['options']['avatars_normal'],
				'enableAvatarsFull'		=> $instance['options']['avatars_full'],
				'avatarHeightNormal'	=> $instance['options']['avatar_height_normal'],
				'avatarHeightFull'		=> $instance['options']['avatar_height_full'],
				'avatarWidthNormal'		=> $instance['options']['avatar_width_normal'],
				'avatarWidthFull'		=> $instance['options']['avatar_width_full'],
				'avatarpath'			=> $shout['avatarurl'],
				'type'					=> $shout['type'],
				'showNotification' 		=> ($shout['type'] == $this->shouttypes['pm'] AND ($this->app->getUserInfo('dbtech_vbshout_settings') & 1048576)),
				'notificationMessage' 	=> $this->app->stripBbCode(str_replace('\\\\', '\\', str_replace(array("%", "$", "\\"), array("&#37;", "&#36;", "\\\\"), htmlspecialchars($shout['message_raw'])))),
				'permissions'			=> json_encode(array(
					'canpm' 		=> $canpm,
					'isprotected' 	=> (!$isProtected AND $shout['userid'] != $this->app->getUserInfo('userid') AND $shout['shoutid']),
					'canban' 		=> $instance['permissions_parsed']['canban'],
					'cankick' 		=> (array_key_exists('creator', $chatroom) AND $chatroom['creator'] == $this->app->getUserInfo('userid') AND $shout['userid'] != $this->app->getUserInfo('userid')),
					
				)),
			);

			$i++;
		}

		if (!$args['archive'] AND $cleanedInput['shoutorder'] == 'ASC')
		{
			// Reverse sort order
			$this->fetched['shouts'] = array_reverse($this->fetched['shouts']);
		}

		if (!$this->fetched['shouts'])
		{
			// Show no content
			$this->fetched['content'] = '<li>' . $this->app->phrase('dbtech_vbshout_nothing_to_display') . '</li>';
		}

		// No longer needed
		unset($shoutusers, $shout);
	}

	/**
	* Checks for action codes, and executes their meaning.
	*
	* @param	string	The shout.
	* @param	string	The default shout type.
	* @param	integer	(Optional) The default id.
	* @param	integer	(Optional) The default userid.
	*
	* @return	mixed	Any new information we may have.
	*/
	public function parseActionCodes(&$message, &$type)
	{
		$retval = array(
			'type' 		=> '',
			'id' 		=> '',
			'userid' 	=> '',
		);

		if (preg_match("#^(\/[a-z]*?)\s(.+?)$#i", $message, $matches))
		{
			// 2-stage command
			switch ($matches[1])
			{
				case '/me':
					// A slash me
					$message 	= trim($matches[2]);
					$type 		= $this->shouttypes['me'];
					break;
			}
		}

		return array($retval['type'], $retval['id'], $retval['userid']);
	}

	/**
	* Checks for a protected usergroup
	*
	* @param	array	Usergroup information
	* @param	boolean	(Optional) Whether we should just return boolean
	*/
	public function checkProtectedUserGroup(array $instance, array $userInfo)
	{
		// Loads instance permissions
		$permarray = $this->loadInstancePermissions($instance, $userInfo);

		if (isset($permarray['isprotected']) AND $permarray['isprotected'])
		{
			throw new Exception($this->app->phrase('dbtech_vbshout_x_is_protected', array('param1' => $userInfo['username'])));
		}

		return false;
	}

	/**
	* Fetch all currently active users.
	*/
	public function fetchActiveUsers(array $instance, array $chatroom = array(), $force = false)
	{
		if ($this->activeusers === NULL OR $force)
		{
			// Array of all active users
			$this->activeusers = array();
			$userids = array();

			// Query active users
			$activeusers = $this->_getDb()->fetchAll('
				SELECT user.*, user.=user:userid= AS userid
				FROM $dbtech_vbshout_session AS session
				LEFT JOIN $user AS user ON(user.=user:userid= = session.userid)
				WHERE session.lastactivity >= ?
				' . (!$chatroom ? ' AND session.instanceid = ' . intval($instance['instanceid']) : '') .
					($chatroom ? ' AND session.chatroomid = ' . intval($chatroom['chatroomid']) : ' AND session.chatroomid = 0') . '
			', array(
				($this->app->getTime() - ($instance['options']['idletimeout'] ? $instance['options']['idletimeout'] : 600))
			));
			foreach ($activeusers as $activeuser)
			{
				if (in_array($activeuser['userid'], $userids))
				{
					// Skip this user
					continue;
				}

				// Add this
				$userids[] = $activeuser['userid'];

				switch ($this->app->getSystem())
				{
					case 'XenForo':
						$str = '';
						

						$this->activeusers[] = $str . '<a class="username" href="' . $this->app->profileLink($activeuser) . '" target="_blank">' . XenForo_Template_Helper_Core::callHelper('richusername', array($activeuser)) . '</a>';
						break;

					case 'vBulletin':
						// fetch the markup-enabled username
						fetch_musername($activeuser);

						// Fetch the SEO'd URL to a member's profile
						$this->activeusers[] = '<a href="' . $this->app->profileLink($activeuser) . '" target="_blank">' . $activeuser['musername'] . '</a>';
						break;
				}
			}
		}
	}

	/**
	* Leaves the chatroom
	*
	* @param	array	The chat room being left
	* @param	integer	The userid leaving the chat
	*/
	public function leaveChatroom(array &$chatroom, $userid)
	{
		if ($chatroom['membergroupids'] AND $chatroom['autojoin'])
		{
			// We're not doing this
			return false;
		}

		$whereCond = '';
		if ($chatroom['creator'] == $userid AND !$chatroom['membergroupids'])
		{
			// init data manager
			$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_ARRAY);
				$chatroomDm->setExistingData($chatroom);
				$chatroomDm->bulkSet([
					'active' => 0,
					'members' => []
				]);
			$chatroomDm->save();
			unset($chatroomDm);
		}
		else
		{
			// We weren't the creator, only we should abandon ship
			$whereCond = ' AND userid = ' . intval($userid);
		}

		// Join the chat room
		$this->_getDb()->delete('dbtech_vbshout_chatroommember', 'chatroomid = ' . intval($chatroom['chatroomid']) . $whereCond);

		if ($whereCond)
		{
			// init data manager
			$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_ARRAY);
				$chatroomDm->setExistingData($chatroom);

			// We're now fully joined
			unset($chatroom['members'][$userid]);

				$chatroomDm->set('members', 	$chatroom['members']);
			$chatroomDm->save();
			unset($chatroomDm);
		}
	}

	/**
	* Joins the chatroom
	*
	* @param	array	The chat room being left
	* @param	integer	The userid leaving the chat
	*/
	public function joinChatroom(array &$chatroom, $userid)
	{
		if ($chatroom['membergroupids'] AND $chatroom['autojoin'])
		{
			// We're not doing this
			return false;
		}

		// Join the chat room
		$affectedRows = $this->_getDb()->update('dbtech_vbshout_chatroommember', [
			'status' 		=> 1,
		], 'chatroomid = ' . intval($chatroom['chatroomid']) . ' AND userid = ' . intval($userid));

		if (!$affectedRows)
		{
			$this->_getDb()->insertIgnore('dbtech_vbshout_chatroommember', [
				'status' 		=> 1,
				'chatroomid'  	=> $chatroom['chatroomid'],
				'userid'  		=> $userid
			]);
		}

		// init data manager
		$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_ARRAY);
			$chatroomDm->setExistingData($chatroom);

		// We're now fully joined
		$chatroom['members'][$userid] = '1';

			$chatroomDm->set('members', 	$chatroom['members']);
		$chatroomDm->save();
		unset($chatroomDm);
	}

	/**
	* Creates the chatroom
	*
	* @param	array	The chat room being left
	* @param	integer	The userid leaving the chat
	*/
	public function chatInvite(array &$chatroom, $userid, $invitedby)
	{
		// Invite to join the chat room
		if ($this->_getDb()->insertIgnore('dbtech_vbshout_chatroommember', array(
			'chatroomid' 	=> $chatroom['chatroomid'],
			'userid' 		=> $userid,
			'status' 		=> 0,
			'invitedby' 	=> $this->app->getUserInfo('userid')
		)))
		{
			// init data manager
			$chatroomDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Chatroom', DBTech_Shout_DataManager::ERROR_ARRAY);
				$chatroomDm->setExistingData($chatroom);

			// We're now fully joined
			$chatroom['members'][$userid] = '0';

				$chatroomDm->set('members', 	$chatroom['members']);
			$chatroomDm->save();
			unset($chatroomDm);
		}
	}

	/**
	* Fetches what chatrooms we're a member of
	*
	* @param	array	The user info we're checking membership of
	* @param	mixed	Whether we're checking a status or not
	* @param	mixed	Whether we're checking an instanceid or not
	*/
	public function fetchChatroomMemberships(array $userinfo, $status = NULL, $instanceid = NULL)
	{
		// Init this
		$chatroomCache = $this->cache->get('chatroom');

		$memberof = array();
		foreach ($chatroomCache as $chatroomid => $chatroom)
		{
			if (!$chatroom['active'])
			{
				// Inactive chatroom
				continue;
			}

			if ($instanceid !== NULL)
			{
				if ($chatroom['instanceid'] != $instanceid AND $chatroom['instanceid'] != 0)
				{
					// Skip this instance id
					continue;
				}
			}

			if ($chatroom['membergroupids'] AND $chatroom['autojoin'])
			{
				if ($chatroom['membergroupids'] == '-1' OR $this->app->isMemberOf($userinfo, explode(',', $chatroom['membergroupids'])))
				{
					// Do join it
					$memberof[] = $chatroomid;
				}
			}
			else
			{
				if (!isset($chatroom['members'][$userinfo['userid']]))
				{
					// We're not a part this
					continue;
				}

				if ($status !== NULL AND $chatroom['members'][$userinfo['userid']] !== $status)
				{
					// Wrong status
					continue;
				}

				// We're a member
				$memberof[] = $chatroomid;
			}
		}

		return $memberof;
	}

	/**
	* Sets the sticky note for a specific instance
	*
	* @param	string	The new sticky note.
	* @param	array	The instance to set the sticky note for
	*/
	public function setSticky($sticky, array &$instance)
	{
		// Store raw sticky
		$sticky_raw = $sticky;

		// Parse the BBCode
		$this->parseBbCode($sticky, $instance);

		// init data manager
		$instanceDm = DBTech_Shout_DataManager::create('DBTech_Shout_DataManager_Instance', DBTech_Shout_DataManager::ERROR_ARRAY);
			$instanceDm->setExistingData($instance);
			$instanceDm->bulkSet(array(
				'sticky' => $sticky,
				'sticky_raw' => $sticky_raw
			));
		$instanceDm->save();
		unset($instanceDm);

		// Set new sticky
		$instance['sticky'] = $sticky;
		$instance['sticky_raw'] = $sticky_raw;

		// Add to fetched
		$this->fetched['sticky'] = $sticky;
	}

	public function parseBbCode(&$message, array $instance = NULL, array $permarray = NULL)
	{
		if ($permarray === NULL AND $instance !== NULL)
		{
			// Initialise BBCode Permissions
			$permarray = array(
				'permissions_parsed' 		=> $instance['permissions_parsed'],
				'bbcodepermissions_parsed' 	=> $instance['bbcodepermissions_parsed']
			);
		}

		// Store the unparsed message also
		$message = trim($message);

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				// Convert URLs to links
				$message = XenForo_Helper_String::autoLinkBbCode($message, false);

				// Setup formatter
				$formatter = XenForo_BbCode_Formatter_Base::create('XenForo_BbCode_Formatter_Base');
				$parser = XenForo_BbCode_Parser::create($formatter);

				if ($instance !== NULL)
				{
					if ($instance['options']['anonymise'])
					{
						// Convert to anon
						$message = $this->anonymiseLinks($message);
					}
				}

				// parse BBCode
				$message = $parser->render($message);
				break;

			case 'vBulletin':
				// Ensure we got BBCode Parser
				require_once(DIR . '/includes/class_bbcode.php');
				if (!function_exists('convert_url_to_bbcode'))
				{
					require_once(DIR . '/includes/functions_newpost.php');
				}

				if ($instance !== NULL)
				{
					// Store these settings
					$backup = array(
						'allowedbbcodes' 	=> $GLOBALS['vbulletin']->options['allowedbbcodes'],
						'allowhtml' 		=> $GLOBALS['vbulletin']->options['allowhtml'],
						'allowbbcode' 		=> $GLOBALS['vbulletin']->options['allowbbcode'],
						'allowsmilies' 		=> $GLOBALS['vbulletin']->options['allowsmilies'],
						'allowbbimagecode' 	=> $GLOBALS['vbulletin']->options['allowbbimagecode']
					);

					// Override allowed bbcodes
					$GLOBALS['vbulletin']->options['allowedbbcodes'] 	= $permaray['bbcodepermissions_parsed']['bit'];

					// Initialise the parser (use proper BBCode)
					$parser = new vB_BbCodeParser($GLOBALS['vbulletin'], fetch_tag_list());

					// Override the BBCode list
					$GLOBALS['vbulletin']->options['allowhtml'] 		= false;
					$GLOBALS['vbulletin']->options['allowbbcode'] 		= true;
					$GLOBALS['vbulletin']->options['allowsmilies'] 		= $instance['options']['allowsmilies'];
					$GLOBALS['vbulletin']->options['allowbbimagecode'] 	= ($permaray['bbcodepermissions_parsed']['bit'] & 1024);

					if ($permarray['bbcodepermissions_parsed']['bit'] & 64)
					{
						// We can use the URL BBCode, so convert links
						$message = convert_url_to_bbcode($message);
					}

					if ($instance['options']['anonymise'])
					{
						// Convert to anon
						$message = $this->anonymiseLinks($message);
					}

					// BBCode parsing
					$message = $parser->parse($message, 'nonforum');

					foreach ($backup as $vbopt => $val)
					{
						// Reset the settings
						$GLOBALS['vbulletin']->options[$vbopt] = $val;
					}
				}
				else
				{
					// Initialise the parser (use proper BBCode)
					$parser = new vB_BbCodeParser($GLOBALS['vbulletin'], fetch_tag_list());

					if ($this->app->option('allowedbbcodes') & 64)
					{
						// We can use the URL BBCode, so convert links
						$message = convert_url_to_bbcode($message);
					}

					// BBCode parsing
					$message = $parser->parse($message, 'nonforum');
				}

				break;
		}

		return $message;
	}

	/**
	* Anonymises links if needed
	*
	* @return	string
	*/
	public function anonymiseLinks($message)
	{
		// Call the replacement
		return preg_replace_callback(array(
			'#\[url="([a-zA-Z]+[://]+[A-Za-z0-9\-_]+\\.+[A-Za-z0-9\./%&=\?\-_]+)"\](.*)\[/url\]#isU',
			'#\[url=([a-zA-Z]+[://]+[A-Za-z0-9\-_]+\\.+[A-Za-z0-9\./%&=\?\-_]+)\](.*)\[/url\]#isU',
			'#\[url\](.*)\[/url\]#isU'
		), function($match)
		{
			if (
				strpos($match[1], 'anonym.to') === false AND
				strpos($match[1], $_SERVER['HTTP_HOST']) === false
			)
			{
				// Do the replacement
				$match[0] = str_ireplace($match[1], 'http://www.anonym.to/?' . $match[1], $match[0]);
			}

			return $match[0];
		}, $message);
	}

	/**
	* Fetches all valid forum ids
	*
	* @return	array	List of forum ids we can access
	*/
	public function getForumIds()
	{
		$forumcache = $this->app->getForumCache();
		$forumids = array_keys($forumcache);

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$forumModel = XenForo_Model::create('XenForo_Model_Forum');
				break;
		}

		$userInfo = $this->app->getUserInfo();

		// get forum ids for all forums user is allowed to view
		foreach ($forumids AS $key => $forumid)
		{
			$forum =& $forumcache[$forumid];

			// Debug fix
			$forumPermissions = NULL;

			switch ($this->app->getSystem())
			{
				case 'XenForo':
					$forumModel->standardizeViewingUserReferenceForNode($forum['node_id'], $userInfo, $forumPermissions);
					break;

				case 'vBulletin':
					$forumPermissions = $this->app->getUserInfo('forumpermissions');
					$forumPermissions = $forumPermissions[$forumid];
					break;
			}

			if (
				!$this->app->forumPermission($forum, 'canview', $forumPermissions, $userInfo)
				OR !$this->app->forumPermission($forum, 'canviewthreads', $forumPermissions, $userInfo)
			)
			{
				// User did not have permission to view this thread
				unset($forumids[$key]);
			}
		}

		// Those shouts with 0 as their forumid
		$forumids[] = 0;

		return $forumids;
	}

	/**
	* Fetches all forum IDs the user can't view others' threads in
	*
	* @return	array	List of forum ids we can access
	*/
	public function getForumIds2()
	{
		$forumcache = $this->app->getForumCache();
		$forumids = array('-1');

		switch ($this->app->getSystem())
		{
			case 'XenForo':
				$forumModel = XenForo_Model::create('XenForo_Model_Forum');
				break;
		}

		$userInfo = $this->app->getUserInfo();

		// get forum ids for all forums user is allowed to view
		foreach ($forumcache AS $forumid => $forum)
		{
			$forum =& $forumcache[$forumid];

			// Debug fix
			$forumPermissions = NULL;

			switch ($this->app->getSystem())
			{
				case 'XenForo':
					$forumModel->standardizeViewingUserReferenceForNode($forum['node_id'], $userInfo, $forumPermissions);
					break;

				case 'vBulletin':
					$forumPermissions = $this->app->getUserInfo('forumpermissions');
					$forumPermissions = $forumPermissions[$forumid];
					break;
			}

			if (
				!$this->app->forumPermission($forum, 'canview', $forumPermissions, $userInfo)
				OR !$this->app->forumPermission($forum, 'canviewthreads', $forumPermissions, $userInfo)
			)
			{
				// User did not have permission to view this thread
				continue;
			}

			if (
				!$this->app->forumPermission($forum, 'canviewothers', $forumPermissions, $userInfo)
			)
			{
				// We can't view others' threads
				$forumids[] = $forumid;
			}
		}

		return $forumids;
	}

	protected function _getDb()
	{
		return DBTech_Shout_Core::getInstance()->_getDb();
	}

	protected function _getTemplate()
	{
		return DBTech_Shout_Template::getInstance();
	}

	public static final function getInstance()
	{
		if (!self::$_instance)
		{
			self::$_instance = new static();
		}

		return self::$_instance;
	}
}