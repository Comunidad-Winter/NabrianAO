<?php
/*======================================================================*\
|| #################################################################### ||
|| # ---------------------------------------------------------------- # ||
|| # Copyright ©2014 DragonByte Technologies					 	  # ||
|| # All Rights Reserved. 											  # ||
|| # This file may not be redistributed in whole or significant part. # ||
|| # ---------------------------------------------------------------- # ||
|| # You are not allowed to use this on your server unless the files  # ||
|| # you downloaded were done so with permission.					  # ||
|| # ---------------------------------------------------------------- # ||
|| #################################################################### ||
\*======================================================================*/

$md5_sums = array (
  '/js/DBTech/Shout' => 
  array (
    'core.js' => '5631e0af7017e254958ad00bc84ec29c',
    'jquery.tmpl.min.js' => '2b26540d6761fa6eb1e66d97ec176364',
    'jquery.xml2json.js' => '0fdc78089e769594f0c924a7fd3a91af',
    'notify.js' => '6a20a30a7c98a42eabf3f60e668dfc44',
  ),
  '/library/DBTech/Shout' => 
  array (
    'Action.php' => '30f4aee23892a8f1c9f24acec4f0a4e1',
    'ActionAdmin.php' => 'efeda585fa6d44e5e67db47840bfa2f9',
    'Application.php' => 'ae41200f4153e14e1a16b912e5cbf3a5',
    'Autoloader.php' => 'bc17560016582edc6fc4fee6be71f9ac',
    'Cache.php' => 'f07be3215a41eee763d05c87159124df',
    'Core.php' => '792a455429ea2985e5b03dc22ba90ed3',
    'DataManager.php' => '07885cc69e4c415d4987615b2148ee26',
    'Database.php' => 'e5e3cf6a15b60c3730a6a04d6c0dd633',
    'Model.php' => '11ef0f98d560500fbf0b462252047a77',
    'Shoutbox.php' => '8d6190f57628885de30b2b78489e6181',
    'Template.php' => 'cf03a9cd3d792aedfbbe4dd4cd65b1e6',
  ),
  '/library/DBTech/Shout/Action' => 
  array (
    'Ajax.php' => 'a8b69e890ecd8f4f497df5f7e88f024f',
    'Archive.php' => 'f1086561fa2ec851e0ca952b33015b96',
    'Main.php' => '3d30058a24757198e39283112d6d560a',
  ),
  '/library/DBTech/Shout/Action/Ajax' => 
  array (
    'Createchat.php' => '2c1911b3edcfd4d208b44333ff44239c',
    'Delete.php' => '3177516681ed0ff9cb7107219c38188b',
    'Fetch.php' => '02e6afc383b64583d37ecb2d3af4f38e',
    'Fetchsticky.php' => 'c2d7c972c565e1efedcfdac9a72f68d3',
    'Invisible.php' => '7158f1092d531096c945af036cb84f15',
    'Joinchat.php' => 'd2529c1ae51b75469b289b1a743e1126',
    'Leavechat.php' => '63cac4e808f8df8eec09152ff30be893',
    'Lookup.php' => '407f5b813a4f2b4877763ec543306340',
    'Save.php' => 'c74f33f6562ebf0b75a9fe38e42203bd',
    'Savesettings.php' => '4f95161875e7c971726ffde85f4a5ab7',
    'Sounds.php' => 'd8b6e7f7e0bf92b769b8e68bb7857830',
    'Styleprops.php' => '54954fa674663f70b3a12e080fb2d625',
    'Unidle.php' => 'dba7d77fa0ab53da76e7be7eb2579134',
    'Usermanage.php' => '61ec0e3edddd8541d5067a28c6d8a013',
  ),
  '/library/DBTech/Shout/ActionAdmin' => 
  array (
    'Banned.php' => '8ef7d7d4b14a76ed16493d6130fb277b',
    'Chatroom.php' => '5984fe23b1a6c442457ad10f4ec2c794',
    'Commandlog.php' => 'e4894b2779f48127c8d996a4557f7926',
    'Download.php' => '26330d4548215df2bd1ba1031e3aca5c',
    'Instance.php' => '20801bc88364cf5d57742c7beba565d9',
    'Main.php' => '3e45b2ef6b16384189301ee98dce1212',
    'Notifications.php' => '1d653959d0b9b3d67d0c4549e643bccb',
    'Options.php' => '66649a6b81bc3b05d763ef62728e279e',
    'Repaircache.php' => '4178274befa3e4e52707237628e94d73',
  ),
  '/library/DBTech/Shout/Application' => 
  array (
    'Cache.php' => '8bf8be2ea03bba871d0c5270f386f84e',
    'Charset.php' => '213bd7602d88aa3b3aa9d02c081c565f',
    'Core.php' => '67b414904f98cf220517e5caa215c1cc',
    'DataManager.php' => 'b7134d9b689618275e4248caa2711e7e',
    'Database.php' => '860e1546667dac2bc3063c07b8788630',
    'Model.php' => '54fe5831560c768327be870e08eddac4',
    'ResponseErrorException.php' => 'e527e1270120df5cbf4005f1865f48ec',
    'ResponseMessageException.php' => '81fbb71a24976c4563077f4ec30f58b8',
    'ResponseRedirectException.php' => '70a2bbe8cf97fb7690732c44ce98f7e6',
    'Template.php' => '04c2de21676675a6a9cebd72b476054a',
    'Upload.php' => '5b806835db20022ad1c27338a6c142a2',
  ),
  '/library/DBTech/Shout/Application/Core' => 
  array (
    'Admin.php' => 'e8a4bbeb45642beb7dc686bbf08dc927',
  ),
  '/library/DBTech/Shout/Application/includes' => 
  array (
    'adminfunctions_vbulletin.php' => '5ffd61c48e9d0e532986764ce1527f6a',
    'adminfunctions_xenforo.php' => '182a580988d98502c55c614295c2f507',
  ),
  '/library/DBTech/Shout/Core' => 
  array (
    'Admin.php' => '97c7b5d33c0363feef6e5071d1d030ca',
  ),
  '/library/DBTech/Shout/DataManager' => 
  array (
    'Chatroom.php' => '45745bbfb64fd204da168726f49a7418',
    'Instance.php' => 'aa67a071aab77a04a5dd16f9dce15e1f',
    'Shout.php' => '8c31d797d38dc0ad6767e316d17defe1',
  ),
  '/library/DBTech/Shout/DataManager/Helper' => 
  array (
    'Chatroom.php' => '59846dce4de742c98e177799c0cd4d5c',
    'Instance.php' => '954f1cbe8ad2402d89c4089fc1224c0c',
    'Shout.php' => 'ebeff6626002d44efc87ea2e09a84002',
  ),
  '/library/DBTech/Shout/XenForo' => 
  array (
    'Install.php' => '827247686e4ad468652aa9c3a8dc91a9',
  ),
  '/library/DBTech/Shout/XenForo/ControllerAdmin' => 
  array (
    'Option.php' => '91fb0c262b75176ce68c0d43896ccaf0',
    'Shout.php' => 'f04e1ba27c143def489e4379892cdcbf',
  ),
  '/library/DBTech/Shout/XenForo/ControllerPublic' => 
  array (
    'Profile.php' => 'cf19bf3cc44a73a2081cb36ea54a1699',
    'Shout.php' => 'e76b22e645b6e66a1a63b5897168693e',
  ),
  '/library/DBTech/Shout/XenForo/DataWriter/Discussion' => 
  array (
    'Thread.php' => 'dc616dc8b7aa062ef82941d5a3a57601',
  ),
  '/library/DBTech/Shout/XenForo/DataWriter/DiscussionMessage' => 
  array (
    'Post.php' => 'a22ce68d439c7b0b818e125bdb0c126f',
  ),
  '/library/DBTech/Shout/XenForo/EventListener' => 
  array (
    'FrontControllerPostView.php' => 'cc514bcb2f5f550aeb0cc5d8a576c55d',
    'LoadClass.php' => 'f5cd2ea519ce86cbcd2d55d6e857c868',
    'TemplateHook.php' => 'ec56c5cda94e847a9aa5cd9411308232',
  ),
  '/library/DBTech/Shout/XenForo/Install' => 
  array (
    '20160328.php' => 'd838d78c999af74218c6339cd0f80ced',
    '20160406.php' => '4bd505767de86753f91b68a8764b9ddd',
    '20160703.php' => '2a59e440cbe85d09d98e7cd5bc8fcf81',
    'Uninstall.php' => 'bcf9ad9853f85cbf3869f5b5f22a547f',
  ),
  '/library/DBTech/Shout/XenForo/Model' => 
  array (
    'Option.php' => 'c0f444a8cbceeaef98c924050177e685',
  ),
  '/library/DBTech/Shout/XenForo/Option' => 
  array (
    'BrandingFree.php' => '2af7ef550af08ddedc9f235d17d5bcfc',
    'UserGroupChooser.php' => '3b79c964718bdeeba7bb9ce238962504',
  ),
  '/library/DBTech/Shout/XenForo/Route/Prefix' => 
  array (
    'Profile.php' => '81cde58ea18494075e0c8ada26a736a2',
    'Shout.php' => '7a8c7d553ae525e39c8998a526a2551c',
  ),
  '/library/DBTech/Shout/XenForo/Route/PrefixAdmin' => 
  array (
    'Shout.php' => '40678f16314ec47faa221836ba1d071c',
  ),
);

$md5_sum_softwareid = '%VARNAME%';
$md5_sum_versions['%VARNAME%'] = '%VERSION%';



?>